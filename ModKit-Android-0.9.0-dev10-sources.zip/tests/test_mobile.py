"""Independent standard-layout fixture, not the original custom metadata format."""
import hashlib
import json
import struct
import zipfile
import pytest
from modkit.mobile.engine import analyze, analyze_rodroid, export, export_apk_unsigned, export_dump, patch_bytes, _symbol_tokens, _semantic_tags, _dump_field_discoveries, Cancelled


def test_semantic_search_tokens_do_not_match_smooth_path():
    assert 'hp' not in _symbol_tokens('SmoothPath')
    assert 'hp' in _symbol_tokens('Player_HP')
    assert 'health' in _semantic_tags('Player::get_HitPoints')


def test_dump_fields_are_discovered_but_not_marked_patchable():
    dump='''namespace Game\npublic class Player\n{\n    private float currentHealth; // 0x34\n    public int Damage { get; set; }\n}\n'''
    rows=_dump_field_discoveries(dump,100)
    assert [r['semantic'] for r in rows] == [['health'], ['damage']]
    assert rows[0]['field_offset']==0x34
    assert all(not r['selectable'] for r in rows)


def fixture(tmp_path, version=29, relocated=False, shared=False):
    meta=bytearray(0x800)
    struct.pack_into('<II',meta,0,0xFAB11BAF,version)
    strings=bytearray()
    def string(s):
        i=len(strings);strings.extend(s.encode()+b'\0');return i
    image=string('Assembly-CSharp.dll');cls=string('Player');ns=string('Example')
    names=[string('get_Health'),string('get_Speed'),string('get_Alive')]
    def region(i,off,size):struct.pack_into('<II',meta,8+i*8,off,size)
    region(2,0x100,len(strings));meta[0x100:0x100+len(strings)]=strings
    stride=36 if version==31 else 32
    region(5,0x200,3*stride);region(19,0x300,88);region(20,0x400,40)
    for i,name in enumerate(names):
        p=0x200+i*stride
        struct.pack_into('<Iii',meta,p,name,0,i)
        shift=4 if version==31 else 0
        struct.pack_into('<iiIHHHH',meta,p+12+shift,0,-1,0x06000001+i,6,0,0,0)
    struct.pack_into('<II',meta,0x300,cls,ns)
    struct.pack_into('<i',meta,0x300+24,-1)
    struct.pack_into('<i',meta,0x300+36,0)
    struct.pack_into('<H',meta,0x300+64,3)
    struct.pack_into('<IiII',meta,0x400,image,0,0,1)
    mp=tmp_path/'global-metadata.dat';mp.write_bytes(meta)
    elf=bytearray(0x5000);elf[:6]=b'\x7fELF\x02\x01'
    struct.pack_into('<HHI',elf,16,3,183,1)
    struct.pack_into('<Q',elf,32,64)
    struct.pack_into('<HHH',elf,52,64,56,3 if relocated else 2)
    base=0x10000
    struct.pack_into('<IIQQQQQQ',elf,64,1,5,0x1000,base+0x1000,0,0x1000,0x1000,0x1000)
    struct.pack_into('<IIQQQQQQ',elf,120,1,6,0x3000,base+0x3000,0,0x2000,0x2000,0x1000)
    for p in range(0x1000,0x1100,4):struct.pack_into('<I',elf,p,0xd503201f)
    name=b'Assembly-CSharp.dll\0';elf[0x3100:0x3100+len(name)]=name
    rel=[]
    def ptr(off,value):
        if relocated:rel.append((off+base,1027,value))
        else:struct.pack_into('<Q',elf,off,value)
    ptr(0x3200,base+0x3100);struct.pack_into('<Q',elf,0x3208,3);ptr(0x3210,base+0x3300)
    for i,p in enumerate((0x1000,0x1000 if shared else 0x1040,0x1080)):ptr(0x3300+i*8,base+p)
    struct.pack_into('<Q',elf,0x3400+48,3);ptr(0x3400+56,base+0x3500)
    struct.pack_into('<Q',elf,0x3400+80,1);ptr(0x3400+88,base+0x3540)
    struct.pack_into('<Q',elf,0x3400+96,1);ptr(0x3400+104,base+0x3550)
    for i,kind in enumerate((8,12,2)):
        ptr(0x3500+i*8,base+0x3600+i*16)
        struct.pack_into('<I',elf,0x3600+i*16+8,kind<<16)
    if relocated:
        struct.pack_into('<IIQQQQQQ',elf,176,2,6,0x3700,base+0x3700,0,64,64,8)
        for i,(tag,val) in enumerate(((7,base+0x3800),(8,len(rel)*24),(9,24),(0,0))):struct.pack_into('<qQ',elf,0x3700+i*16,tag,val)
        for i,row in enumerate(rel):struct.pack_into('<QQq',elf,0x3800+i*24,*row)
    ep=tmp_path/'libil2cpp.so';ep.write_bytes(elf)
    return mp,ep


@pytest.mark.parametrize('version',[27,29,31])
@pytest.mark.parametrize('relocated',[False,True])
def test_two_files_to_modified_library(tmp_path,version,relocated):
    m,e=fixture(tmp_path,version,relocated)
    original=e.read_bytes();report=tmp_path/'analysis.json'
    result=json.loads(analyze(m,e,report))
    assert result['methods']==3 and result['resolved']==3 and result['type_table_found']
    assert [r['kind'] for r in result['candidates']]==['int32','float']
    assert result['candidates'][0]['offset']==0x1000
    out=tmp_path/'mod.zip'
    receipt=json.loads(export(report,e,json.dumps([{'id':0,'value':'777'},{'id':1,'value':'2.5'}]),out))
    with zipfile.ZipFile(out) as z:
        patched=z.read('libil2cpp.so')
        assert set(z.namelist())=={'libil2cpp.so','changes.json','analysis.json','README-RU.txt'}
        expected=bytearray(original)
        for p in receipt['changes']:
            data=bytes.fromhex(p['patch']);expected[p['offset']:p['offset']+len(data)]=data
        assert patched==bytes(expected)
        assert receipt['result_sha256']==hashlib.sha256(patched).hexdigest()
    assert e.read_bytes()==original


def test_shared_method_addresses_not_offered(tmp_path):
    m,e=fixture(tmp_path,shared=True)
    r=json.loads(analyze(m,e,tmp_path/'report.json'))
    assert r['candidates']==[]
    assert r['unavailable']['Общий адрес у нескольких методов']==2


def test_library_changed_after_analysis(tmp_path):
    m,e=fixture(tmp_path);report=tmp_path/'report.json';analyze(m,e,report)
    with e.open('r+b') as f:f.seek(0x1000);f.write(b'bad!')
    with pytest.raises(ValueError,match='изменилась'):
        export(report,e,'[{"id":0,"value":"2"}]',tmp_path/'result.zip')
    assert not (tmp_path/'result.zip').exists()


def test_invalid_and_unsupported_metadata(tmp_path):
    m,e=fixture(tmp_path);m.write_bytes(b'invalid')
    with pytest.raises(ValueError):analyze(m,e,tmp_path/'a.json')
    m,e=fixture(tmp_path,version=24)
    with pytest.raises(ValueError,match='v24'):analyze(m,e,tmp_path/'a.json')


def test_cancel_does_not_publish_partial_zip(tmp_path):
    m,e=fixture(tmp_path);report=tmp_path/'report.json';analyze(m,e,report)
    class Callback:
        def isCancelled(self):return True
        def progress(self,s):pass
    with pytest.raises(Cancelled):export(report,e,'[{"id":0,"value":"2"}]',tmp_path/'result.zip',Callback())
    assert not (tmp_path/'result.zip').exists()


@pytest.mark.parametrize('kind,value',[('bool','2'),('int8','128'),('uint32','-1'),('float','nan'),('double','inf'),('int64','1.5')])
def test_invalid_values(kind,value):
    with pytest.raises((ValueError,OverflowError)):patch_bytes(kind,value)


def test_float_instructions():
    assert patch_bytes('float','2.5')[-8:]==bytes.fromhex('0000271ec0035fd6')
    assert patch_bytes('double','2.5')[-8:]==bytes.fromhex('0000679ec0035fd6')


def test_relr_bitmaps(tmp_path):
    m,e=fixture(tmp_path,relocated=True)
    b=bytearray(e.read_bytes());size=struct.unpack_from('<Q',b,0x3718)[0]
    addresses=[]
    for pos in range(0x3800,0x3800+size,24):
        address,info,value=struct.unpack_from('<QQq',b,pos)
        struct.pack_into('<Q',b,address-0x10000,value);addresses.append(address)
    addresses.sort();words=[]
    while addresses:
        start=addresses.pop(0);words.append(start);bitmap=1
        while addresses and addresses[0] <= start+63*8:
            address=addresses.pop(0);bitmap |= 1 << ((address-start)//8)
        if bitmap!=1:words.append(bitmap)
    for i,(tag,val) in enumerate(((36,0x13800),(35,len(words)*8),(37,8),(0,0))):struct.pack_into('<qQ',b,0x3700+i*16,tag,val)
    for i,word in enumerate(words):struct.pack_into('<Q',b,0x3800+i*8,word)
    e.write_bytes(b)
    result=json.loads(analyze(m,e,tmp_path/'a.json'))
    assert len(result['candidates'])==2


def test_bti_landing_instruction_preserved(tmp_path):
    m,e=fixture(tmp_path);b=bytearray(e.read_bytes());struct.pack_into('<I',b,0x1000,0xd503245f);e.write_bytes(b)
    report=tmp_path/'a.json';analyze(m,e,report)
    export(report,e,'[{"id":0,"value":"10"}]',tmp_path/'a.zip')
    with zipfile.ZipFile(tmp_path/'a.zip') as z:
        assert z.read('libil2cpp.so')[0x1000:0x1004]==bytes.fromhex('5f2403d5')


def test_mismatched_module_count(tmp_path):
    m,e=fixture(tmp_path);b=bytearray(e.read_bytes());struct.pack_into('<Q',b,0x3208,4);e.write_bytes(b)
    result=json.loads(analyze(m,e,tmp_path/'a.json'))
    assert result['resolved']==0 and result['candidates']==[]


def test_no_type_registration_no_guessing(tmp_path):
    m,e=fixture(tmp_path);b=bytearray(e.read_bytes());struct.pack_into('<Q',b,0x3460,0);e.write_bytes(b)
    result=json.loads(analyze(m,e,tmp_path/'a.json'))
    assert result['resolved']==3 and not result['type_table_found'] and result['candidates']==[]


def test_rodroid_dump_is_source_of_truth_and_rebuilds_apk(tmp_path):
    metadata,library=fixture(tmp_path)
    dump=tmp_path/'rodroid'/'Dump0';dump.mkdir(parents=True)
    script={
        'ScriptMethod':[
            {'Address':0x11000,'Name':'Player$$get_Health','Signature':'int32_t Player$$get_Health (Player_o* __this, const MethodInfo* method);','TypeSignature':'iii','DotNetSignature':'Example.Player::get_Health()','Group':'Assembly-CSharp/Example/Player'},
            {'Address':0,'Name':'Player$$get_Missing','Signature':'int32_t Player$$get_Missing (Player_o* __this, const MethodInfo* method);','TypeSignature':'iii','DotNetSignature':'Example.Player::get_Missing()','Group':'Assembly-CSharp/Example/Player'},
        ],
        'Addresses':[0x11000,0x11040]
    }
    (dump/'script.json').write_text(json.dumps(script),encoding='utf-8')
    (dump/'dump.cs').write_text('// TypeDefIndex: 0\n// RVA: -1\n',encoding='utf-8')
    report=tmp_path/'analysis.json'
    result=json.loads(analyze_rodroid(dump,metadata,library,report))
    assert result['engine']=='Rodroid Il2CppDumper'
    assert result['source_of_truth']==['dump.cs','script.json','global-metadata+CodeRegistration']
    assert len(result['candidates'])==1 and result['unresolved']==1
    source=tmp_path/'game.apk'
    with zipfile.ZipFile(source,'w') as z:
        z.writestr('AndroidManifest.xml',b'manifest')
        z.writestr('META-INF/CERT.SF',b'old signature')
        info=zipfile.ZipInfo('lib/arm64-v8a/libil2cpp.so');info.compress_type=zipfile.ZIP_STORED
        z.writestr(info,library.read_bytes())
    unsigned=tmp_path/'rebuilt.apk'
    export_apk_unsigned(report,library,'[{"id":0,"value":"777"}]',source,unsigned)
    with zipfile.ZipFile(unsigned) as z:
        assert 'META-INF/CERT.SF' not in z.namelist()
        assert 'assets/modkit-build-receipt.json' in z.namelist()
        patched=z.read('lib/arm64-v8a/libil2cpp.so')
        assert patched != library.read_bytes()
        info=z.getinfo('lib/arm64-v8a/libil2cpp.so')
        data_offset=info.header_offset+30+len(info.filename.encode())+len(info.extra)
        assert data_offset % 16384 == 0


def test_full_rodroid_dump_export_needs_no_selections(tmp_path):
    root=tmp_path/'rodroid';dump=root/'Dump0';dump.mkdir(parents=True)
    (dump/'dump.cs').write_text('class Player {}',encoding='utf-8')
    (dump/'script.json').write_text('{"ScriptMethod":[]}',encoding='utf-8')
    (dump/'stringliteral.json').write_text('[]',encoding='utf-8')
    (dump/'generics_dump.txt').write_text('generic',encoding='utf-8')
    report=tmp_path/'analysis.json';report.write_text('{"engine":"Rodroid"}',encoding='utf-8')
    output=tmp_path/'full-dump.zip'
    result=json.loads(export_dump(root,report,output))
    assert result['files']==5
    with zipfile.ZipFile(output) as z:
        assert {'rodroid/Dump0/dump.cs','rodroid/Dump0/script.json',
                'rodroid/Dump0/stringliteral.json','rodroid/Dump0/generics_dump.txt',
                'analysis.json','dump-manifest.json','README-RU.txt'} <= set(z.namelist())
        manifest=json.loads(z.read('dump-manifest.json'))
        assert all(len(item['sha256'])==64 for item in manifest['files'])


def test_rodroid_rva_minus_one_can_be_resolved_uniquely_from_metadata(tmp_path):
    metadata,library=fixture(tmp_path)
    dump=tmp_path/'rodroid'/'Dump0';dump.mkdir(parents=True)
    script={
        'ScriptMethod':[
            {'Address':0x11000,'Name':'Player$$get_Health','Signature':'int32_t Player$$get_Health (Player_o* __this, const MethodInfo* method);','TypeSignature':'iii','DotNetSignature':'Example.Player::get_Health()','Group':'Assembly-CSharp/Example/Player'},
        ],
        'Addresses':[0x11000,0x11080]
    }
    (dump/'script.json').write_text(json.dumps(script),encoding='utf-8')
    (dump/'dump.cs').write_text('''// Dll : Assembly-CSharp.dll
// Namespace: Example
public class Player // TypeDefIndex: 0
{
    // RVA: -1 Offset: -1 VA: -1
    public float get_Speed() { }
}
''',encoding='utf-8')
    result=json.loads(analyze_rodroid(dump,metadata,library,tmp_path/'analysis.json'))
    assert result['resolved_metadata']==1
    assert result['unresolved']==0
    meta=[c for c in result['candidates'] if c.get('source')=='global-metadata+CodeRegistration']
    assert len(meta)==1 and meta[0]['label']=='Example.Player::get_Speed'
    assert meta[0]['rva']==0x11040


def test_rodroid_signature_contract_distinguishes_instance_setter_and_action():
    from modkit.mobile.engine import _rodroid_signature_contract
    setter = _rodroid_signature_contract(
        'void Drova_CheatGameHandler__EnableCheatMode (Drova_CheatGameHandler_o* __this, bool value, const MethodInfo* method);'
    )
    assert setter['isStatic'] is False
    assert setter['managedParamCount'] == 1
    assert setter['bindingSuggestion'] == 'bool_setter'
    assert setter['bindingBlocker'] == 'instance-method-needs-confirmed-instance-resolver'

    action = _rodroid_signature_contract(
        'void Example__ToggleConsoleWindow (const MethodInfo* method);'
    )
    assert action['isStatic'] is True
    assert action['managedParamCount'] == 0
    assert action['bindingSuggestion'] == 'action'
    assert action['bindingBlocker'] is None


def test_menu_auto_prepare_from_re_promotes_structurally_proven_candidate(tmp_path):
    from modkit.mobile.engine import menu_auto_prepare_from_re
    from modkit.selftest import fixtures

    apk = tmp_path / 'game.apk'
    with zipfile.ZipFile(apk, 'w') as z:
        z.writestr('lib/arm64-v8a/libil2cpp.so', fixtures.so_blob())
    re_report = tmp_path / 're-analysis.json'
    re_report.write_text(json.dumps({'controlCandidates': [{
        'id': 'candidate.cheat', 'title': 'Enable Cheat', 'suggestedType': 'toggle',
        'source': 'Drova.dll', 'kind': 'rodroid-discovery', 'location': 'RVA 0x1040',
        'evidenceRva': 0x1040, 'confidence': 0.97,
        'bindingSuggestion': 'bool_setter', 'isStatic': False,
        'bindingBlocker': 'instance-resolver-review-required',
        'signatureContract': {
            'signature': 'void X__EnableCheat (X_o* __this, bool value, const MethodInfo* method);',
            'bindingSuggestion': 'bool_setter', 'isStatic': False,
        },
        'resolverRva': 0x1044, 'resolverKind': 'out_ptr_bool',
        'instanceResolver': {'rva': 0x1044, 'kind': 'out_ptr_bool', 'label': 'X::TryGet', 'source': 'Drova.dll'},
    }], 'findings': []}), encoding='utf-8')
    menu_json = tmp_path / 'menu.json'
    out_report = tmp_path / 'auto.json'
    out_preflight = tmp_path / 'preflight.json'
    result = json.loads(menu_auto_prepare_from_re(
        re_report, menu_json, apk, tmp_path / 'project', out_report, out_preflight
    ))
    assert result['confirm']['promoted']
    assert result['preflight']['readyForPayload'] is True
    assert result['project']['runtimeMode'] == 'built-in-generic-config'
    saved = json.loads(menu_json.read_text(encoding='utf-8'))['controls'][0]
    assert saved['binding'] == 'bool_setter'
    assert saved['rva'] == 0x1040 and saved['resolver_rva'] == 0x1044


def test_rodroid_signature_contract_preserves_numeric_value_shape():
    from modkit.mobile.engine import _rodroid_signature_contract

    f = _rodroid_signature_contract(
        'void Example__SetSpeed (Example_o* __this, float value, const MethodInfo* method);'
    )
    assert f['bindingSuggestion'] == 'number_setter'
    assert f['suggestedControlType'] == 'slider_float'
    assert f['valueKind'] == 'float'
    assert f['managedValueType'] == 'System.Single'
    assert f['isStatic'] is False

    i = _rodroid_signature_contract(
        'void Example__SetLevel (int32_t value, const MethodInfo* method);'
    )
    assert i['bindingSuggestion'] == 'number_setter'
    assert i['suggestedControlType'] == 'slider_int'
    assert i['valueKind'] == 'int'
    assert i['managedValueType'] == 'System.Int32'


def test_rodroid_signature_contract_rejects_constructor_and_update_as_auto_bindings():
    from modkit.mobile.engine import _rodroid_signature_contract
    ctor = _rodroid_signature_contract('void X___ctor (int32_t value, const MethodInfo* method);')
    update = _rodroid_signature_contract('void X__Update (X_o* __this, float dt, const MethodInfo* method);')
    assert ctor['bindingSuggestion'] is None and ctor['autoBindingSafe'] is False
    assert update['bindingSuggestion'] is None and update['autoBindingSafe'] is False


def test_numeric_signature_contract_keeps_unsupported_widths_review_only():
    from modkit.mobile.engine import _rodroid_signature_contract
    i64 = _rodroid_signature_contract('void X__SetBig (int64_t value, const MethodInfo* method);')
    dbl = _rodroid_signature_contract('void X__SetScale (double value, const MethodInfo* method);')
    assert i64['suggestedControlType'] == 'slider_int' and i64['managedValueType'] == 'System.Int64'
    assert dbl['suggestedControlType'] == 'slider_float' and dbl['managedValueType'] == 'System.Double'
    for c in (i64, dbl):
        assert c['bindingSuggestion'] is None
        assert c['autoBindingSafe'] is False
        assert c['runtimeValueSupported'] is False
        assert c['bindingBlocker'] == 'generic-runtime-value-abi-unsupported'
