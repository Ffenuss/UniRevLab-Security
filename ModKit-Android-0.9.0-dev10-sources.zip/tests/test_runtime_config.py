import pytest
from modkit.menu import MenuControl, MenuSpec
from modkit.menu.runtime_config import (
    encode_runtime_config, decode_runtime_config, HEADER, ENTRY, MAX_CONTROLS,
    K_ACTION, K_BOOL, K_INT, K_FLOAT,
)


def test_runtime_config_roundtrip_and_transliterates_labels():
    spec = MenuSpec("Тестовое меню", controls=[
        MenuControl("god", "Бессмертие", "toggle", rva=0x1234, binding="bool_setter", default=True),
        MenuControl("weather", "Погода", "button", rva=0x2340, binding="action"),
        MenuControl("level", "Уровень", "slider_int", rva=0x3450, binding="number_setter", min_value=1, max_value=50, default=10),
        MenuControl("speed", "Скорость", "slider_float", rva=0x4560, binding="number_setter", min_value=0.5, max_value=3.0, default=1.0),
    ])
    blob = encode_runtime_config(spec)
    decoded = decode_runtime_config(blob)
    assert decoded["targetSo"] == "libil2cpp.so"
    assert decoded["title"] == "Testovoe menyu"
    assert [c["kind"] for c in decoded["controls"]] == [K_BOOL, K_ACTION, K_INT, K_FLOAT]
    assert decoded["controls"][0]["label"] == "Bessmertie"
    assert decoded["controls"][0]["rva"] == 0x1234
    assert decoded["bytesUsed"] == HEADER.size + 4 * ENTRY.size


def test_runtime_config_refuses_instance_binding_without_resolver():
    with pytest.raises(ValueError, match="instance binding requires a confirmed out_ptr_bool resolver RVA"):
        MenuSpec("X", controls=[MenuControl(
            "x", "X", "button", rva=0x1000, binding="action", is_static=False,
            call_abi="il2cpp"
        )]).validate()


def test_runtime_config_roundtrips_il2cpp_instance_resolver():
    spec = MenuSpec("X", controls=[MenuControl(
        "cheat", "Cheat", "toggle", rva=0x2000, binding="bool_setter",
        is_static=False, call_abi="il2cpp", resolver_rva=0x3000,
        resolver_kind="out_ptr_bool"
    )])
    decoded = decode_runtime_config(encode_runtime_config(spec))
    row = decoded["controls"][0]
    assert decoded["version"] == 2
    assert row["rva"] == 0x2000
    assert row["resolverRva"] == 0x3000
    assert row["resolverKind"] == "out_ptr_bool"
    assert row["callAbi"] == "il2cpp"
    assert row["isStatic"] is False


def test_runtime_config_roundtrips_static_il2cpp_action():
    spec = MenuSpec("X", controls=[MenuControl(
        "run", "Run", "button", rva=0x4444, binding="action",
        call_abi="il2cpp", is_static=True
    )])
    row = decode_runtime_config(encode_runtime_config(spec))["controls"][0]
    assert row["callAbi"] == "il2cpp"
    assert row["isStatic"] is True
    assert row["resolverRva"] is None


def test_runtime_config_limit():
    controls = [MenuControl(f"x{i}", f"X{i}", "button", rva=0x1000 + i * 4, binding="action")
                for i in range(MAX_CONTROLS + 1)]
    with pytest.raises(ValueError, match="at most"):
        encode_runtime_config(MenuSpec("X", controls=controls))


def test_patch_runtime_blob_writes_mapped_modkitcfg_section():
    from modkit.menu.runtime_config import patch_runtime_blob
    from modkit.selftest import fixtures
    spec = MenuSpec("Меню", controls=[MenuControl(
        "god", "Бессмертие", "toggle", rva=0x1234, binding="bool_setter", default=False
    )])
    config = encode_runtime_config(spec, render_host="libunity.so")
    patched, report = patch_runtime_blob(fixtures.runtime_so_blob(), config)
    assert report["location"] == ".modkitcfg"
    assert report["config"]["controls"][0]["id"] == "god"
    from modkit.elf.reader import ElfFile
    sec = ElfFile(patched).section(".modkitcfg")
    assert sec is not None and sec.size >= 16 * 1024
    decoded = decode_runtime_config(patched[sec.offset: sec.offset + len(config)])
    assert decoded["title"] == "Menyu"


def test_generic_runtime_rejects_numeric_value_abi_mismatch():
    with pytest.raises(ValueError, match='requires System.Int32'):
        encode_runtime_config(MenuSpec('X', controls=[MenuControl(
            'wide', 'Wide', 'slider_int', rva=0x1000, binding='number_setter',
            min_value=0, max_value=10, value_type='System.Int64'
        )]))
    with pytest.raises(ValueError, match='requires System.Single'):
        encode_runtime_config(MenuSpec('X', controls=[MenuControl(
            'double', 'Double', 'slider_float', rva=0x1000, binding='number_setter',
            min_value=0, max_value=10, value_type='System.Double'
        )]))
