"""README-level checks: the documented commands and layout must exist."""

from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
README = (ROOT / "README.md").read_text(encoding="utf-8")


def test_readme_documents_every_subcommand():
    from modkit.cli import build_parser
    subs = [a for a in build_parser()._subparsers._group_actions[0].choices]  # noqa: SLF001
    for cmd in subs:
        assert re.search(rf"modkit {cmd}\b", README), f"`modkit {cmd}` is not documented"


def test_readme_pipeline_section_exists():
    assert "## Как это работает" in README or "## How it works" in README


def test_repo_layout_matches_the_readme():
    for rel in ("modkit/cli.py", "modkit/metadata/reader.py", "modkit/dumper/dumpcs.py",
                "modkit/elf/reader.py", "modkit/analyze/features.py", "modkit/codegen/gen.py",
                "modkit/codegen/runtime_src.py", "modkit/selftest/fixtures.py",
                "rules/default.json", "pyproject.toml"):
        assert (ROOT / rel).exists(), rel


def test_runtime_sources_have_no_unresolved_placeholders():
    from modkit.codegen import runtime_src, templates
    for name in dir(runtime_src):
        if name.isupper():
            body = getattr(runtime_src, name)
            assert "###PKG_JNI###" not in body or name == "JNI_MAIN", name
    for name in dir(templates):
        if name.isupper() and isinstance(getattr(templates, name), str):
            leftovers = re.findall(r"\{\{(\w+)\}\}", getattr(templates, name))
            assert set(leftovers) <= {"app_name", "package", "abi", "count", "project", "target_so",
                                      "overlay", "imgui", "dobby", "autoload", "tag", "app", "lib", "keys",
                                      "version", "source", "nfeat", "nhooks", "rows", "notes",
                                      "classes", "methods", "so"}, (name, leftovers)


def test_android_menu_builder_does_not_invent_slider_range():
    src = (ROOT / 'android/app/src/main/java/dev/modkit/mobile/MenuBuilderActivity.java').read_text(encoding='utf-8')
    assert 'Min и Max явно' in src
    assert 'Slider Min (обязательно для slider)' in src
    assert 'c.put("min_value",0)' not in src
    assert 'c.put("max_value",100)' not in src


def test_android_auto_apk_uses_strict_ready_gate():
    worker = (ROOT / 'android/app/src/main/java/dev/modkit/mobile/WorkerService.java').read_text(encoding='utf-8')
    menu = (ROOT / 'android/app/src/main/java/dev/modkit/mobile/MenuBuilderActivity.java').read_text(encoding='utf-8')
    assert 'readyForAutoBuild' in worker
    assert 'actionableReview' in menu
    assert 'autoAPK:' in menu


def test_re_workspace_surfaces_native_relationship_counts():
    src = (ROOT / 'android/app/src/main/java/dev/modkit/mobile/ReWorkspaceActivity.java').read_text(encoding='utf-8')
    for token in ('nativeRelations', 'relationshipGraph', 'completeChains', 'partialLoaderChains', 'gaps', 'dependencyEdges', 'dexNativeLinks', 'embeddedLibraryStringEdges', 'symbolEdges', 'dynamicSymbolEdges', 'jniSurfaces', 'jniDirectCallRefs', 'il2cppDirectCallRefs', 'dynamicLoadingSurfaces', 'renderInputSurfaces'):
        assert token in src


def test_native_workspace_surfaces_static_xrefs():
    src = (ROOT / 'android/app/src/main/java/dev/modkit/mobile/NativeWorkspaceActivity.java').read_text(encoding='utf-8')
    worker = (ROOT / 'android/app/src/main/java/dev/modkit/mobile/WorkerService.java').read_text(encoding='utf-8')
    assert 'native_xrefs' in src
    assert 'native-xrefs.json' in src
    assert 'native_workspace_xrefs' in worker
