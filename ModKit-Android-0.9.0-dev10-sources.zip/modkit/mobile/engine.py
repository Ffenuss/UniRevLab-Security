"""Standard IL2CPP metadata + ELF64 offline workflow, no target code execution.

Layouts: https://github.com/Perfare/Il2CppDumper/blob/master/Il2CppDumper/Il2Cpp/MetadataClass.cs
and Il2CppClass.cs. Supports standard metadata 27, 29, 31 and AArch64 ELF.
Original synthetic demo reader remains separate; it is not used here.
"""
from __future__ import annotations
import bisect
import collections
import copy
import hashlib
import json
import math
import mmap
import os
from pathlib import Path
import struct
import zipfile
from modkit.arch.arm64 import mov_imm, ret


class Cancelled(Exception):
    pass


def check(cb=None, stage=None):
    if cb is not None:
        if cb.isCancelled():
            raise Cancelled('Операция отменена')
        if stage:
            cb.progress(stage)


def digest(path, cb=None):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        while chunk := f.read(1024 * 1024):
            check(cb)
            h.update(chunk)
    return h.hexdigest()


class Binary:
    def __init__(self, path):
        self.f = open(path, 'rb')
        try:
            self.b = mmap.mmap(self.f.fileno(), 0, access=mmap.ACCESS_READ)
        except Exception:
            self.f.close()
            raise ValueError('Файл пуст или недоступен')

    def close(self):
        self.b.close()
        self.f.close()

    def unpack(self, fmt, off):
        size = struct.calcsize(fmt)
        if off < 0 or off + size > len(self.b):
            raise ValueError('Повреждённый файл: выход за границы таблицы')
        return struct.unpack_from(fmt, self.b, off)


class Metadata(Binary):
    def __init__(self, path):
        super().__init__(path)
        try:
            magic, self.version = self.unpack('<II', 0)
            if magic != 0xFAB11BAF:
                raise ValueError('Нет стандартного заголовка IL2CPP. Файл повреждён, зашифрован или имеет иной формат.')
            if self.version not in (27, 29, 31):
                raise ValueError(f'Метаданные v{self.version}: автоматический разбор этой версии пока не реализован. Поддержаны v27, v29, v31.')
            self.strings = self.region(2)
            self.types = self.region(19, 88)
            self.methods = self.region(5, 36 if self.version == 31 else 32)
            self.images = self.region(20, 40)
            if not self.types[1] or not self.images[1]:
                raise ValueError('В метаданных отсутствуют таблицы типов или сборок')
            self.type_count = self.types[1] // 88
            self.method_size = 36 if self.version == 31 else 32
            self.method_count = self.methods[1] // self.method_size
        except Exception:
            self.close()
            raise

    def region(self, index, stride=1):
        off, size = self.unpack('<II', 8 + index * 8)
        if off + size > len(self.b) or size % stride or (size and off < 176):
            raise ValueError('Некорректные границы/размер таблицы метаданных')
        return off, size

    def string(self, i):
        start, size = self.strings
        if i >= size:
            raise ValueError('Индекс строки вне таблицы метаданных')
        end = self.b.find(b'\0', start + i, start + size)
        if end < 0:
            raise ValueError('Строка метаданных не завершена')
        return self.b[start + i:end].decode('utf-8', 'strict')

    def rows(self, cb=None):
        result = []
        occupied = set()
        for pos in range(self.images[0], sum(self.images), 40):
            check(cb)
            ni, _, first, count = self.unpack('<IiII', pos)
            if count == 0:
                continue
            if first + count > self.type_count:
                raise ValueError('Диапазон типов сборки повреждён')
            image = self.string(ni)
            for ti in range(first, first + count):
                if ti % 256 == 0:
                    check(cb)
                if ti in occupied:
                    raise ValueError('Пересекающиеся диапазоны типов')
                occupied.add(ti)
                p = self.types[0] + ti * 88
                name, namespace = self.unpack('<II', p)
                generic = self.unpack('<i', p + 24)[0]
                method_start = self.unpack('<i', p + 36)[0]
                method_count = self.unpack('<H', p + 64)[0]
                if method_count and (method_start < 0 or method_start + method_count > self.method_count):
                    raise ValueError('Диапазон методов повреждён')
                cls = '.'.join(filter(None, (self.string(namespace), self.string(name))))
                for mi in range(method_start, method_start + method_count):
                    if mi % 1024 == 0:
                        check(cb)
                    p = self.methods[0] + mi * self.method_size
                    ni, declaring, rt = self.unpack('<Iii', p)
                    shift = 4 if self.version == 31 else 0
                    mg = self.unpack('<i', p + 16 + shift)[0]
                    token, flags, iflags, slot, argc = self.unpack('<IHHHH', p + 20 + shift)
                    if declaring != ti or token >> 24 != 6:
                        raise ValueError('Токен или владелец метода не соответствует таблице')
                    result.append(dict(id=mi, image=image, cls=cls, name=self.string(ni),
                                       type_index=rt, token=token, args=argc,
                                       generic=generic >= 0 or mg >= 0, abstract=bool(flags & 0x400)))
        return result


class Elf(Binary):
    def __init__(self, path, cb=None):
        super().__init__(path)
        self.cb = cb
        try:
            if self.b[:6] != b'\x7fELF\x02\x01' or self.unpack('<H', 18)[0] != 183:
                raise ValueError('Нужна ELF-библиотека ARM64 (arm64-v8a), little-endian')
            if self.unpack('<H', 16)[0] != 3:
                raise ValueError('Ожидается shared library ET_DYN')
            phoff = self.unpack('<Q', 32)[0]
            entsize, count = self.unpack('<HH', 54)
            if entsize < 56 or phoff + entsize * count > len(self.b):
                raise ValueError('Таблица сегментов ELF повреждена')
            self.segments = []
            dynamic = None
            for i in range(count):
                kind, flags, off, va, _, size, mem, _ = self.unpack('<IIQQQQQQ', phoff + i * entsize)
                if off + size > len(self.b) or size > mem:
                    raise ValueError('Сегмент ELF выходит за границы файла')
                if kind == 1:
                    self.segments.append((va, off, size, flags))
                if kind == 2:
                    dynamic = (off, size)
            self.reloc = {}
            self.refs = collections.defaultdict(list)
            tags = {}
            if dynamic:
                for p in range(dynamic[0], sum(dynamic), 16):
                    tag, val = self.unpack('<qQ', p)
                    if tag == 0:
                        break
                    tags[tag] = val
            if 0x60000011 in tags:  # Android APS2 packed relocation format
                raise ValueError('ELF содержит упакованные Android-релокации APS2: этот формат пока не поддержан')
            if 7 in tags:
                size = tags.get(8, 0)
                stride = tags.get(9, 24)
                if stride != 24 or size % 24:
                    raise ValueError('Некорректная таблица RELA')
                base = self.offset(tags[7], size)
                for i, p in enumerate(range(base, base + size, 24)):
                    if i % 16384 == 0:
                        check(cb)
                    address, info, addend = self.unpack('<QQq', p)
                    if info & 0xffffffff == 1027:  # R_AARCH64_RELATIVE, base=0
                        self.add_reloc(address, addend)
            # Standard DT_RELR and Android's earlier RELR tag numbers.
            relr = tags.get(36, tags.get(0x6fffe000))
            if relr is not None:
                size = tags.get(35, tags.get(0x6fffe001, 0))
                if size % 8:
                    raise ValueError('Некорректная таблица RELR')
                start = self.offset(relr, size)
                cursor = 0
                for i, p in enumerate(range(start, start + size, 8)):
                    if i % 16384 == 0:
                        check(cb)
                    word = self.unpack('<Q', p)[0]
                    if not word & 1:
                        cursor = word
                        self.add_reloc(cursor, self.unpack('<Q', self.offset(cursor, 8))[0])
                        cursor += 8
                    else:
                        for bit in range(1, 64):
                            if word & (1 << bit):
                                addr = cursor + (bit - 1) * 8
                                self.add_reloc(addr, self.unpack('<Q', self.offset(addr, 8))[0])
                        cursor += 63 * 8
        except Exception:
            self.close()
            raise

    def add_reloc(self, address, value):
        try:
            off = self.offset(address, 8)
        except ValueError:
            return  # zero-filled tail of a load segment has no on-disk bytes
        self.reloc[off] = value
        self.refs[value].append(off)

    def offset(self, va, length=1, executable=False):
        for v, off, size, flags in self.segments:
            if v <= va and va + length <= v + size and (not executable or flags & 1):
                return off + va - v
        raise ValueError('Адрес не принадлежит нужному файловому сегменту ELF')

    def virtual(self, off):
        for v, o, size, _ in self.segments:
            if o <= off < o + size:
                return v + off - o
        raise ValueError('Нет виртуального адреса для смещения')

    def ptr(self, off):
        return self.reloc.get(off, self.unpack('<Q', off)[0])

    def finds(self, pattern):
        pos = 0
        while True:
            check(self.cb)
            pos = self.b.find(pattern, pos)
            if pos < 0:
                return
            yield pos
            pos += 1

    def modules(self, image_names):
        out = {}
        for n, name in enumerate(sorted(image_names)):
            check(self.cb, f'Поиск таблиц методов: {n + 1}/{len(image_names)} — {name}')
            candidates = set()
            for pos in self.finds(name.encode() + b'\0'):
                try:
                    va = self.virtual(pos)
                except ValueError:
                    continue
                refs = set(self.refs.get(va, []))
                refs.update(p for p in self.finds(struct.pack('<Q', va)) if p % 8 == 0)
                for p in refs:
                    try:
                        count = self.unpack('<Q', p + 8)[0]
                        if not 0 < count <= 2_000_000:
                            continue
                        table = self.offset(self.ptr(p + 16), count * 8)
                        samples = [self.ptr(table + i * 8) for i in range(min(count, 64))]
                        nonzero = [a for a in samples if a]
                        if not nonzero:
                            continue
                        for a in nonzero:
                            self.offset(a, 4, True)
                        candidates.add((count, table))
                    except (ValueError, struct.error):
                        continue
            if len(candidates) == 1:
                out[name] = candidates.pop()
        return out

    def type_table(self, type_count, max_index):
        matches = set()
        for p in self.finds(struct.pack('<Q', type_count)):
            base = p - 96
            if base < 0 or base % 8:
                continue
            try:
                if self.unpack('<Q', base + 80)[0] != type_count:
                    continue
                count = self.unpack('<Q', base + 48)[0]
                if not max_index < count <= 4_000_000:
                    continue
                table = self.offset(self.ptr(base + 56), count * 8)
                self.offset(self.ptr(base + 88), type_count * 8)
                self.offset(self.ptr(base + 104), type_count * 8)
                for i in {0, max_index, count - 1}:
                    addr = self.offset(self.ptr(table + i * 8), 12)
                    bits = self.unpack('<I', addr + 8)[0]
                    if not 1 <= ((bits >> 16) & 255) <= 0x55:
                        raise ValueError('Неверный тип')
                matches.add((count, table))
            except (ValueError, struct.error):
                continue
        return matches.pop() if len(matches) == 1 else None

    def primitive(self, table, index):
        if table is None or not 0 <= index < table[0]:
            return None
        try:
            off = self.offset(self.ptr(table[1] + index * 8), 12)
            bits = self.unpack('<I', off + 8)[0]
            # Both old and new by-ref bit positions are rejected conservatively.
            if bits & 0x60000000:
                return None
            return {2:'bool', 4:'int8', 5:'uint8', 6:'int16', 7:'uint16',
                    8:'int32', 9:'uint32', 10:'int64', 11:'uint64',
                    12:'float', 13:'double'}.get((bits >> 16) & 255)
        except ValueError:
            return None


def analyze(metadata_path, library_path, output_path, cb=None):
    check(cb, 'Проверка метаданных')
    m = Metadata(metadata_path)
    e = None
    try:
        rows = m.rows(cb)
        check(cb, 'Чтение сегментов и релокаций библиотеки')
        e = Elf(library_path, cb)
        modules = e.modules({r['image'] for r in rows})
        token_max = collections.defaultdict(int)
        token_seen = set()
        for row in rows:
            key = (row['image'], row['token'])
            if key in token_seen:
                raise ValueError('Повторяющиеся токены методов в одной сборке')
            token_seen.add(key)
            token_max[row['image']] = max(token_max[row['image']], row['token'] & 0xffffff)
        # Reject structurally mismatched assembly tables instead of silently using them.
        modules = {name: table for name, table in modules.items() if table[0] == token_max[name]}
        check(cb, 'Определение типов результатов')
        types = e.type_table(m.type_count, max((r['type_index'] for r in rows), default=0))
        address_counts = collections.Counter()
        for count, table in modules.values():
            for i in range(count):
                if i % 16384 == 0:
                    check(cb)
                addr = e.ptr(table + i * 8)
                if addr:
                    address_counts[addr] += 1
        addresses = sorted(address_counts)
        ready = []
        resolved = 0
        reasons = collections.Counter()
        for i, row in enumerate(rows):
            if i % 1024 == 0:
                check(cb)
            module = modules.get(row['image'])
            rid = row['token'] & 0xffffff
            addr = 0
            if module and 0 < rid <= module[0]:
                addr = e.ptr(module[1] + (rid - 1) * 8)
            try:
                off = e.offset(addr, 4, True) if addr else None
            except ValueError:
                off = None
            row['rva'] = addr if off is not None else None
            resolved += off is not None
            kind = e.primitive(types, row['type_index'])
            row['return_type'] = kind
            reason = None
            if off is None:
                reason = 'Нет проверенного адреса'
            elif row['generic'] or row['abstract']:
                reason = 'Обобщённый или абстрактный метод'
            elif not kind or row['args']:
                reason = 'Не числовой/булевый метод без аргументов'
            elif not row['name'].startswith(('get_', 'Get', 'Is', 'Has')):
                reason = 'Метод не распознан как получение значения'
            elif address_counts[addr] != 1:
                reason = 'Общий адрес у нескольких методов'
            else:
                ix = bisect.bisect_right(addresses, addr)
                span = addresses[ix] - addr if ix < len(addresses) else 0
                if span < 8 or addr % 4:
                    reason = 'Недостаточно данных о границе метода'
                else:
                    # Snapshot enough space for the longest supported constant stub.
                    capacity = min(span, 24)
                    try:
                        e.offset(addr, capacity, True)
                    except ValueError:
                        reason = 'Граница метода выходит за сегмент'
                    if reason is None:
                        ready.append(dict(id=row['id'], label=row['cls']+'::'+row['name'],
                                          image=row['image'], kind=kind, rva=addr, offset=off,
                                          capacity=capacity, original=e.b[off:off+capacity].hex()))
            row['unavailable_reason'] = reason
            if reason:
                reasons[reason] += 1
        check(cb, 'Контрольные суммы файлов')
        result = dict(schema=1, metadata_version=m.version, types=m.type_count,
                      methods=len(rows), resolved=resolved, modules=len(modules),
                      type_table_found=types is not None, candidates=ready, method_details=rows,
                      unavailable=dict(reasons), metadata_sha256=digest(metadata_path, cb),
                      library_sha256=digest(library_path, cb),
                      warning='Соответствие файлов проверено по структурам. Поведение изменений требует проверки в игре; это не подтверждение совместимости всех методов.')
        check(cb, f'Анализ завершён: {len(ready)} доступных методов')
        temp = str(output_path)+'.tmp'
        Path(temp).write_text(json.dumps(result, ensure_ascii=False), encoding='utf-8')
        os.replace(temp, output_path)
        return json.dumps({k:v for k,v in result.items() if k != 'method_details'}, ensure_ascii=False)
    finally:
        m.close()
        if e:
            e.close()


_RODROID_TYPES = {
    'bool': 'bool', 'int8_t': 'int8', 'uint8_t': 'uint8',
    'int16_t': 'int16', 'uint16_t': 'uint16', 'int32_t': 'int32',
    'uint32_t': 'uint32', 'int64_t': 'int64', 'uint64_t': 'uint64',
    'float': 'float', 'double': 'double',
}

_SEMANTIC_WORDS = {
    'health': {'health', 'hp', 'hitpoint', 'hitpoints', 'life', 'lives', 'vitality'},
    'damage': {'damage', 'dmg', 'attack', 'hurt', 'hit', 'wound'},
    'money': {'money', 'coin', 'coins', 'gold', 'cash', 'currency', 'gem', 'gems'},
    'cheat': {'cheat', 'godmode', 'god', 'noclip', 'invincible', 'debug', 'trainer'},
    'inventory': {'inventory', 'item', 'items', 'ammo', 'weapon', 'weapons'},
    'movement': {'speed', 'movespeed', 'movement', 'jump', 'stamina'},
}


def _symbol_tokens(text):
    """Split namespaces, snake_case and CamelCase without substring matches."""
    import re
    text = re.sub(r'([a-z0-9])([A-Z])', r'\1 \2', str(text))
    return [x.lower() for x in re.findall(r'[A-Za-z][A-Za-z0-9]*', text)]


def _semantic_tags(text):
    ordered = _symbol_tokens(text)
    tokens = set(ordered)
    tokens.update(a+b for a, b in zip(ordered, ordered[1:]))
    compact = {''.join(_symbol_tokens(x)) for x in str(text).replace('::', '.').split('.')}
    return [name for name, words in _SEMANTIC_WORDS.items()
            if tokens.intersection(words) or compact.intersection(words)]


def _rodroid_signature_contract(signature):
    # Backwards-compatible private name used by the Android engine/tests.
    from modkit.reworkspace.signature import rodroid_signature_contract
    return rodroid_signature_contract(signature)


def _dump_field_discoveries(raw_dump, start_id):
    """Extract interesting fields/properties from dump.cs as search-only evidence."""
    import re
    result, namespace, owner = [], '', ''
    class_re = re.compile(r'\b(?:class|struct)\s+([A-Za-z_$][\w$]*)')
    field_re = re.compile(r'^\s*(?:public|private|protected|internal|static|readonly|const|\s)+\s*([\w.<>,\[\]?]+)\s+([A-Za-z_$][\w$]*)\s*(?:;|\{)')
    for line in raw_dump.splitlines():
        stripped = line.strip()
        if stripped.startswith('namespace '):
            namespace = stripped[10:].strip()
        found = class_re.search(stripped)
        if found:
            owner = found.group(1)
        if re.search(r'\b(class|struct|interface|enum)\b', stripped):
            continue
        match = field_re.match(line)
        if not match or '(' in line:
            continue
        type_name, name = match.groups()
        label = '.'.join(x for x in (namespace, owner, name) if x)
        tags = _semantic_tags(label)
        if not tags:
            continue
        offset_match = re.search(r'//\s*0x([0-9A-Fa-f]+)', line)
        result.append(dict(id=start_id+len(result), label=label, image='dump.cs',
                           kind=type_name, item_type='field/property', semantic=tags,
                           field_offset=int(offset_match.group(1), 16) if offset_match else None,
                           selectable=False,
                           unavailable_reason='Поле/свойство найдено, но постоянный патч метода к нему неприменим'))
        if len(result) >= 5000:
            break
    return result




_CSHARP_PRIMITIVES = {
    'bool':'bool','sbyte':'int8','byte':'uint8','short':'int16','ushort':'uint16',
    'int':'int32','uint':'uint32','long':'int64','ulong':'uint64','float':'float','double':'double',
    'System.Boolean':'bool','System.SByte':'int8','System.Byte':'uint8','System.Int16':'int16',
    'System.UInt16':'uint16','System.Int32':'int32','System.UInt32':'uint32','System.Int64':'int64',
    'System.UInt64':'uint64','System.Single':'float','System.Double':'double',
}


def _metadata_resolution_index(metadata_path, elf, cb=None):
    """Resolve metadata method rows through the IL2CPP module tables already
    validated by the legacy structural analyzer. Only unique method keys and
    unique native addresses are returned.
    """
    meta = Metadata(metadata_path)
    try:
        rows = meta.rows(cb)
        modules = elf.modules({r['image'] for r in rows})
        token_max = collections.defaultdict(int)
        token_seen = set()
        for row in rows:
            key=(row['image'],row['token'])
            if key in token_seen:
                continue
            token_seen.add(key); token_max[row['image']]=max(token_max[row['image']],row['token'] & 0xffffff)
        modules={name:table for name,table in modules.items() if table[0]==token_max[name]}
        raw=[]; address_counts=collections.Counter()
        for row in rows:
            module=modules.get(row['image']); rid=row['token'] & 0xffffff; addr=0
            if module and 0 < rid <= module[0]:
                addr=elf.ptr(module[1]+(rid-1)*8)
            try:
                elf.offset(addr,4,True) if addr else None
            except ValueError:
                addr=0
            if addr:
                address_counts[addr]+=1
            raw.append((row,addr))
        grouped=collections.defaultdict(list)
        for row,addr in raw:
            if not addr or address_counts[addr] != 1:
                continue
            grouped[(row['image'],row['cls'],row['name'],row['args'])].append((row,addr))
        index={k:v[0] for k,v in grouped.items() if len(v)==1}
        return index, sorted(address_counts), dict(modules=len(modules), metadata_methods=len(rows), resolved_unique=len(index))
    finally:
        meta.close()


def _param_count_csharp(text):
    text=str(text).strip()
    if not text:
        return 0
    depth=0; count=1
    for ch in text:
        if ch in '<[(': depth+=1
        elif ch in '>])': depth=max(0,depth-1)
        elif ch==',' and depth==0: count+=1
    return count


def _dump_unresolved_declarations(raw_dump):
    """Yield unresolved dump.cs method declarations with exact DLL/class/arity."""
    import re
    dll=namespace=owner=''
    pending=False
    class_re=re.compile(r'\b(?:class|struct|interface)\s+([A-Za-z_$][\w$<>`]*)')
    method_re=re.compile(r'^\s*(?:(?:public|private|protected|internal|static|virtual|override|sealed|abstract|extern|unsafe|async|new)\s+)*(?P<ret>[\w.<>,\[\]?`]+)\s+(?P<name>[^\s(]+)\((?P<params>.*)\)\s*\{')
    for line in raw_dump.splitlines():
        stripped=line.strip()
        if stripped.startswith('// Dll :'):
            dll=stripped.split(':',1)[1].strip(); continue
        if stripped.startswith('// Namespace:'):
            namespace=stripped.split(':',1)[1].strip(); continue
        cm=class_re.search(stripped)
        if cm and not stripped.startswith('//'):
            owner=cm.group(1).split('<',1)[0]
        if stripped.startswith('// RVA:'):
            value=stripped.split('RVA:',1)[1].split()[0]
            pending=value in ('-1','0','0x0','0x00000000')
            continue
        if not pending:
            continue
        if not stripped or stripped.startswith('[') or stripped.startswith('//'):
            continue
        mm=method_re.match(line)
        pending=False
        if not mm:
            continue
        cls='.'.join(x for x in (namespace,owner) if x)
        yield dict(image=dll, cls=cls, name=mm.group('name'), args=_param_count_csharp(mm.group('params')),
                   return_decl=mm.group('ret'), declaration=stripped)


def analyze_rodroid(dump_dir, metadata_path, library_path, output_path, cb=None):
    """Build the patch model strictly from Rodroid's script.json/dump.cs output."""
    dump_dir = Path(dump_dir)
    script_path, dump_path = dump_dir / 'script.json', dump_dir / 'dump.cs'
    if not script_path.is_file() or not dump_path.is_file():
        raise ValueError('Rodroid не создал обязательные dump.cs и script.json')
    check(cb, 'Чтение script.json Rodroid')
    script = json.loads(script_path.read_text(encoding='utf-8'))
    methods = script.get('ScriptMethod')
    addresses = sorted({int(x) for x in script.get('Addresses', []) if int(x) > 0})
    if not isinstance(methods, list):
        raise ValueError('Некорректный script.json: нет ScriptMethod')
    e = Elf(library_path, cb)
    try:
        address_counts = collections.Counter(int(m.get('Address', 0)) for m in methods)
        ready, details, discoveries, reasons = [], [], [], collections.Counter()
        for i, method in enumerate(methods):
            if i % 1024 == 0:
                check(cb, f'Проверка методов Rodroid: {i}/{len(methods)}')
            address = int(method.get('Address', 0))
            signature = str(method.get('Signature', ''))
            dotnet = str(method.get('DotNetSignature') or method.get('Name') or '')
            group = str(method.get('Group') or '')
            method_name = dotnet.rsplit('::', 1)[-1].split('(', 1)[0]
            semantic = _semantic_tags(dotnet+' '+group)
            return_c = signature.split(None, 1)[0] if signature else ''
            kind = _RODROID_TYPES.get(return_c)
            params = signature.rsplit('(', 1)[-1].rsplit(')', 1)[0] if '(' in signature else ''
            real_params = [p.strip() for p in params.split(',') if p.strip() and 'MethodInfo' not in p]
            contract = _rodroid_signature_contract(signature)
            reason = None
            try:
                offset = e.offset(address, 4, True) if address > 0 else None
            except ValueError:
                offset = None
            if offset is None:
                reason = 'Нет положительного RVA в исполняемом сегменте'
            elif address_counts[address] != 1:
                reason = 'Общий адрес у нескольких методов'
            elif not kind:
                reason = 'Неподдерживаемый тип результата'
            elif len(real_params) > 1:
                reason = 'Метод принимает аргументы'
            elif not method_name.startswith(('get_', 'Get', 'Is', 'Has')):
                reason = 'Метод не распознан как получение значения'
            else:
                ix = bisect.bisect_right(addresses, address)
                span = addresses[ix] - address if ix < len(addresses) else 0
                if span < 8 or address % 4:
                    reason = 'Недостаточно данных о границе метода'
                else:
                    capacity = min(span, 24)
                    try:
                        e.offset(address, capacity, True)
                    except ValueError:
                        reason = 'Граница метода выходит за сегмент'
                    if reason is None:
                        ready.append(dict(id=i, label=dotnet, image=group.split('/', 1)[0],
                                          kind=kind, rva=address, offset=offset, capacity=capacity,
                                          original=e.b[offset:offset+capacity].hex(), source='rodroid-script.json',
                                          semantic=semantic, selectable=True, item_type='method', signature_contract=contract))
            details.append(dict(id=i, label=dotnet, signature=signature, group=group,
                                rva=address if address > 0 else None, return_type=kind,
                                signature_contract=contract, unavailable_reason=reason))
            if semantic and reason:
                discoveries.append(dict(id=i, label=dotnet, image=group.split('/', 1)[0],
                                        kind=kind or return_c or '?', rva=address if address > 0 else None,
                                        semantic=semantic, selectable=False, item_type='method',
                                        signature_contract=contract, unavailable_reason=reason))
            if reason:
                reasons[reason] += 1
        raw_dump = dump_path.read_text(encoding='utf-8', errors='replace')
        discoveries.extend(_dump_field_discoveries(raw_dump, len(methods)))
        unresolved = len(__import__('re').findall(r'RVA:\s*(?:-1|0x0+)(?![0-9A-Fa-f])', raw_dump))

        # Rodroid may leave a direct dump.cs declaration at RVA -1 even when the
        # standard IL2CPP module table can resolve the same metadata token. Resolve
        # those declarations conservatively: exact DLL + class + method + arity,
        # unique metadata key, unique native address, no collision with a Rodroid
        # ScriptMethod address. This is evidence-based fallback, not name guessing.
        metadata_resolved = []
        metadata_stats = {"available": False}
        try:
            check(cb, 'Разрешение RVA=-1 через global-metadata + CodeRegistration')
            meta_index, meta_addresses, meta_stats = _metadata_resolution_index(metadata_path, e, cb)
            metadata_stats = {"available": True, **meta_stats}
            fallback_id = len(methods) + len(discoveries)
            for decl in _dump_unresolved_declarations(raw_dump):
                hit = meta_index.get((decl['image'], decl['cls'], decl['name'], decl['args']))
                if not hit:
                    continue
                row, addr = hit
                reason = None
                try:
                    off = e.offset(addr, 4, True)
                except ValueError:
                    off = None
                if off is None:
                    reason = 'Metadata RVA вне исполняемого сегмента'
                elif address_counts.get(addr, 0):
                    reason = 'Metadata RVA уже принадлежит Rodroid ScriptMethod'
                kind = _CSHARP_PRIMITIVES.get(decl['return_decl'])
                if reason is None and not kind:
                    reason = 'Metadata разрешила RVA, но тип результата не поддержан для патча'
                if reason is None and decl['args']:
                    reason = 'Metadata разрешила RVA, но метод принимает аргументы'
                if reason is None and not decl['name'].startswith(('get_', 'Get', 'Is', 'Has')):
                    reason = 'Metadata разрешила RVA, но метод не распознан как getter'
                capacity = 0
                if reason is None:
                    ix = bisect.bisect_right(meta_addresses, addr)
                    span = meta_addresses[ix] - addr if ix < len(meta_addresses) else 0
                    if span < 8 or addr % 4:
                        reason = 'Metadata разрешила RVA, но граница метода недостаточно надёжна'
                    else:
                        capacity = min(span, 24)
                        try:
                            e.offset(addr, capacity, True)
                        except ValueError:
                            reason = 'Metadata разрешила RVA, но граница выходит за сегмент'
                entry = dict(id=fallback_id + len(metadata_resolved), label=decl['cls']+'::'+decl['name'],
                             image=decl['image'], kind=kind or decl['return_decl'], rva=addr, offset=off,
                             semantic=_semantic_tags(decl['cls']+' '+decl['name']), item_type='method',
                             source='global-metadata+CodeRegistration', resolution='confirmed-unique',
                             selectable=reason is None, unavailable_reason=reason)
                metadata_resolved.append(entry)
                discoveries.append(entry.copy())
                if reason is None:
                    ready.append(dict(id=entry['id'], label=entry['label'], image=entry['image'], kind=kind,
                                      rva=addr, offset=off, capacity=capacity,
                                      original=e.b[off:off+capacity].hex(), source=entry['source'],
                                      semantic=entry['semantic'], selectable=True, item_type='method',
                                      resolution=entry['resolution']))
        except Exception as exc:
            metadata_stats = {"available": False, "error": str(exc)}

        with open(metadata_path, 'rb') as f:
            head = f.read(8)
        metadata_version = struct.unpack('<II', head)[1] if len(head) == 8 and struct.unpack('<I', head[:4])[0] == 0xFAB11BAF else 0
        script_resolved = sum(1 for m in methods if int(m.get('Address', 0)) > 0)
        result = dict(schema=3, engine='Rodroid Il2CppDumper', engine_version='0.7.0',
                      engine_commit='8bfb90229539833999e725c5cf6402a435b47f15',
                      source_of_truth=['dump.cs', 'script.json', 'global-metadata+CodeRegistration'], metadata_version=metadata_version,
                      types=raw_dump.count('// TypeDefIndex:'), methods=len(methods),
                      resolved=script_resolved+len(metadata_resolved), resolved_script=script_resolved,
                      resolved_metadata=len(metadata_resolved), unresolved=max(0, unresolved-len(metadata_resolved)),
                      metadata_resolution=metadata_stats, metadata_resolved_methods=metadata_resolved,
                      modules=len({d['group'].split('/', 1)[0] for d in details if d['group']}),
                      type_table_found=True, candidates=ready, method_details=details,
                      discoveries=discoveries,
                      semantic_categories={k: sorted(v) for k, v in _SEMANTIC_WORDS.items()},
                      deobfuscation=dict(mode='semantic-heuristic',
                          note='Смысл восстанавливается по контексту класса, сигнатуре и связанным именам; зашифрованные имена без контекста нельзя достоверно восстановить.'),
                      unavailable=dict(reasons), metadata_sha256=digest(metadata_path, cb),
                      library_sha256=digest(library_path, cb),
                      dump_files=sorted(p.name for p in dump_dir.iterdir() if p.is_file()),
                      warning='Положительные RVA Rodroid считаются основным источником. RVA=-1 может быть повышен до confirmed только через однозначное DLL+class+method+arity сопоставление с global-metadata и уникальный CodeRegistration address; неоднозначные методы не патчатся.')
        check(cb, f'Rodroid-анализ завершён: {len(ready)} доступных методов')
        temp = str(output_path)+'.tmp'
        Path(temp).write_text(json.dumps(result, ensure_ascii=False), encoding='utf-8')
        os.replace(temp, output_path)
        return json.dumps({k:v for k,v in result.items() if k != 'method_details'}, ensure_ascii=False)
    finally:
        e.close()


def patch_bytes(kind, value):
    if kind == 'bool':
        if str(value).lower() not in ('0', '1', 'true', 'false'):
            raise ValueError('Для bool допустимы только 0 или 1')
        return mov_imm(value=int(str(value).lower() in ('1', 'true')), wide=False) + ret()
    if kind in ('float', 'double'):
        number = float(value)
        if not math.isfinite(number):
            raise ValueError('Нужно конечное число')
        if kind == 'float':
            bits = struct.unpack('<I', struct.pack('<f', number))[0]
            return mov_imm(value=bits, wide=False) + struct.pack('<I', 0x1E270000) + ret()
        bits = struct.unpack('<Q', struct.pack('<d', number))[0]
        return mov_imm(value=bits) + struct.pack('<I', 0x9E670000) + ret()
    if kind not in ('int8','uint8','int16','uint16','int32','uint32','int64','uint64'):
        raise ValueError('Неподдерживаемый тип результата')
    number = int(str(value), 10)
    unsigned = kind.startswith('u')
    width = int(kind[4:] if unsigned else kind[3:])
    low, high = (0, (1 << width)-1) if unsigned else (-(1 << (width-1)), (1 << (width-1))-1)
    if not low <= number <= high:
        raise ValueError(f'Число вне диапазона {kind}: {low} … {high}')
    return mov_imm(value=number, wide=width == 64) + ret()


def export(report_path, library_path, selections_json, output_zip, cb=None):
    report = json.loads(Path(report_path).read_text(encoding='utf-8'))
    selections = json.loads(selections_json)
    if not selections:
        raise ValueError('Выберите хотя бы одно изменение')
    check(cb, 'Проверка исходной библиотеки')
    if digest(library_path, cb) != report['library_sha256']:
        raise ValueError('Библиотека изменилась после анализа. Запустите анализ заново.')
    candidates = {c['id']: c for c in report['candidates']}
    patches = []
    seen = set()
    for s in selections:
        if s['id'] in seen or s['id'] not in candidates:
            raise ValueError('Недопустимый или повторный метод')
        seen.add(s['id'])
        c = candidates[s['id']]
        patch = patch_bytes(c['kind'], s['value'])
        original = bytes.fromhex(c['original'])
        if len(original) >= 4 and struct.unpack_from('<I', original)[0] in (0xd503245f, 0xd503249f, 0xd50324df):
            patch = original[:4] + patch  # Preserve ARM branch target identification landing pad.
        if len(patch) > c['capacity']:
            raise ValueError(c['label']+': выбранное число требует больше места, чем доступно в методе')
        patches.append({**c, 'value':s['value'], 'patch':patch.hex()})
    patches.sort(key=lambda p:p['offset'])
    for a,b in zip(patches, patches[1:]):
        if a['offset'] + len(bytes.fromhex(a['patch'])) > b['offset']:
            raise ValueError('Изменения пересекаются')
    size = os.path.getsize(library_path)
    with open(library_path, 'rb') as f:
        for p in patches:
            old = bytes.fromhex(p['original'])
            if p['offset'] < 0 or p['offset'] + len(old) > size:
                raise ValueError('Некорректные границы патча')
            f.seek(p['offset'])
            if f.read(len(old)) != old:
                raise ValueError('Исходные байты не совпадают с анализом')
    temp = str(output_zip) + '.tmp'
    try:
        h = hashlib.sha256()
        with zipfile.ZipFile(temp, 'w', zipfile.ZIP_DEFLATED, compresslevel=1) as z, open(library_path, 'rb') as src:
            with z.open('libil2cpp.so', 'w', force_zip64=True) as dst:
                position = 0
                def copy_until(end):
                    nonlocal position
                    while position < end:
                        check(cb, f'Создание библиотеки: {position * 100 // max(size,1)}%')
                        chunk = src.read(min(1024*1024, end-position))
                        if not chunk:
                            raise ValueError('Неожиданный конец библиотеки')
                        dst.write(chunk)
                        h.update(chunk)
                        position += len(chunk)
                for p in patches:
                    copy_until(p['offset'])
                    data = bytes.fromhex(p['patch'])
                    dst.write(data)
                    h.update(data)
                    src.seek(len(data), 1)
                    position += len(data)
                copy_until(size)
            receipt = dict(source_sha256=report['library_sha256'], result_sha256=h.hexdigest(),
                           metadata_sha256=report['metadata_sha256'], changes=patches,
                           verified='Файловые границы и исходные байты проверены; в игре не проверено')
            z.writestr('changes.json', json.dumps(receipt, ensure_ascii=False, indent=2))
            z.write(report_path, 'analysis.json')
            dump_dir = Path(report_path).parent / 'rodroid' / 'Dump0'
            for name in ('dump.cs','script.json','stringliteral.json','generics_dump.txt','static_metadata.json','il2cpp.h'):
                artifact = dump_dir / name
                if artifact.is_file():
                    z.write(artifact, 'rodroid/'+name)
            z.writestr('README-RU.txt', 'Результат ModKit\n\nlibil2cpp.so — изменённая копия выбранной библиотеки ARM64.\n'
                       'changes.json — изменения, исходные байты для отката и SHA-256.\n'
                       'analysis.json — результаты анализа.\n\n'
                       'Это не установочный APK и не плавающее меню. Изменения постоянны в этой копии.\n'
                       'Оригинальные выбранные файлы не изменены. Для сборки APK нужны остальные файлы приложения и подпись.\n'
                       'Каждый выбранный метод возвращает указанную константу вместо выполнения исходного тела. '
                       'Побочные действия исходного метода также пропускаются. Проверяйте копию приложения.\n')
        check(cb)
        os.replace(temp, output_zip)
        return json.dumps(receipt, ensure_ascii=False)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)


def _aligned_extra(output_zip, filename, alignment):
    position = output_zip.fp.tell()
    base = position + 30 + len(filename.encode('utf-8'))
    padding = (-base) % alignment
    if padding and padding < 4:
        padding += alignment
    return b'' if not padding else struct.pack('<HH', 0xCAFE, padding-4) + bytes(padding-4)


def export_apk_unsigned(report_path, library_path, selections_json, source_apk, output_apk, cb=None):
    """Rebuild an unsigned APK with the patched arm64-v8a IL2CPP library."""
    temp_mod = str(output_apk) + '.mod.zip'
    patched_library = str(output_apk) + '.libil2cpp.so'
    temp_apk = str(output_apk) + '.tmp'
    try:
        export(report_path, library_path, selections_json, temp_mod, cb)
        with zipfile.ZipFile(temp_mod) as mod, mod.open('libil2cpp.so') as src, open(patched_library, 'wb') as dst:
            while chunk := src.read(1024*1024):
                check(cb, 'Подготовка изменённой библиотеки')
                dst.write(chunk)
        target = 'lib/arm64-v8a/libil2cpp.so'
        with zipfile.ZipFile(source_apk, 'r') as source:
            try:
                original_info = source.getinfo(target)
            except KeyError:
                raise ValueError('В исходном APK нет lib/arm64-v8a/libil2cpp.so')
            h = hashlib.sha256()
            with source.open(original_info) as entry:
                while chunk := entry.read(1024*1024):
                    check(cb, 'Проверка библиотеки внутри APK')
                    h.update(chunk)
            report = json.loads(Path(report_path).read_text(encoding='utf-8'))
            if h.hexdigest() != report['library_sha256']:
                raise ValueError('Выбранная libil2cpp.so не совпадает с ARM64-библиотекой исходного APK')
            with zipfile.ZipFile(temp_apk, 'w', allowZip64=True) as output:
                entries = source.infolist()
                for index, info in enumerate(entries):
                    check(cb, f'Сборка APK: {index*100//max(1,len(entries))}%')
                    upper = info.filename.upper()
                    if upper.startswith('META-INF/') and upper.endswith(('.RSA','.DSA','.EC','.SF','/MANIFEST.MF')):
                        continue
                    zi = copy.copy(info)
                    zi.extra = b''
                    zi.flag_bits &= ~0x08
                    if info.filename == target:
                        zi.file_size = zi.compress_size = os.path.getsize(patched_library)
                        zi.CRC = 0
                        zi.compress_type = zipfile.ZIP_STORED
                        zi.extra = _aligned_extra(output, zi.filename, 16384)
                        with output.open(zi, 'w', force_zip64=True) as dst, open(patched_library, 'rb') as src:
                            while chunk := src.read(1024*1024):
                                check(cb)
                                dst.write(chunk)
                    else:
                        if zi.compress_type == zipfile.ZIP_STORED:
                            alignment = 16384 if zi.filename.endswith('.so') else 4
                            zi.extra = _aligned_extra(output, zi.filename, alignment)
                        with source.open(info) as src, output.open(zi, 'w', force_zip64=info.file_size >= 0xffffffff) as dst:
                            while chunk := src.read(1024*1024):
                                check(cb)
                                dst.write(chunk)
                receipt = json.loads(zipfile.ZipFile(temp_mod).read('changes.json'))
                receipt.update(dict(source_apk_sha256=digest(source_apk, cb), signature='unsigned; Android layer signs after alignment'))
                data = json.dumps(receipt, ensure_ascii=False, indent=2).encode('utf-8')
                zi = zipfile.ZipInfo('assets/modkit-build-receipt.json')
                zi.compress_type = zipfile.ZIP_DEFLATED
                output.writestr(zi, data)
        os.replace(temp_apk, output_apk)
        return json.dumps(dict(apk_sha256=digest(output_apk, cb), replaced_entry=target), ensure_ascii=False)
    finally:
        for path in (temp_mod, patched_library, temp_apk):
            if os.path.exists(path):
                os.unlink(path)


def export_dump(rodroid_root, report_path, output_zip, cb=None):
    """Export every regular Rodroid artifact without requiring patch selections."""
    root = Path(rodroid_root)
    report = Path(report_path)
    if not root.is_dir() or not report.is_file():
        raise ValueError('Сначала выполните полный анализ Rodroid')
    files = sorted(p for p in root.rglob('*') if p.is_file() and not p.is_symlink())
    required = {p.name for p in files}
    if not {'dump.cs', 'script.json'} <= required:
        raise ValueError('Дамп неполный: отсутствует dump.cs или script.json')
    manifest = {
        'schema': 1,
        'engine': 'Rodroid Il2CppDumper 0.7.0',
        'engine_commit': '8bfb90229539833999e725c5cf6402a435b47f15',
        'files': [],
    }
    temp = str(output_zip)+'.tmp'
    try:
        with zipfile.ZipFile(temp, 'w', zipfile.ZIP_DEFLATED, compresslevel=1, allowZip64=True) as z:
            for index, path in enumerate(files):
                check(cb, f'Упаковка дампа: {index+1}/{len(files)} — {path.name}')
                relative = path.relative_to(root).as_posix()
                manifest['files'].append({'path':'rodroid/'+relative,
                                          'size':path.stat().st_size,
                                          'sha256':digest(path, cb)})
                z.write(path, 'rodroid/'+relative)
            manifest['files'].append({'path':'analysis.json','size':report.stat().st_size,
                                      'sha256':digest(report, cb)})
            z.write(report, 'analysis.json')
            z.writestr('dump-manifest.json', json.dumps(manifest, ensure_ascii=False, indent=2))
            z.writestr('README-RU.txt', 'Полный дамп Rodroid Il2CppDumper 0.7.0.\n\n'
                       'rodroid/ — все файлы, созданные движком.\n'
                       'analysis.json — результаты ModKit на основе dump.cs/script.json.\n'
                       'dump-manifest.json — размеры и SHA-256 каждого файла.\n')
        check(cb)
        os.replace(temp, output_zip)
        return json.dumps({'files':len(manifest['files']), 'sha256':digest(output_zip, cb)}, ensure_ascii=False)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)

# ---------------------------------------------------------------------------
# 0.9 RE / Native Workspace / Patch Pack bridge

def re_analyze_apk(apk_path, output_path, metadata_path=None, library_path=None,
                   rodroid_dir=None, unity_report_path=None, il2cpp_report_path=None, cb=None):
    """Cross-correlate DEX, all native libraries and available IL2CPP/Unity evidence."""
    from modkit.reworkspace import correlate_apk
    check(cb, "RE: инвентаризация APK, DEX и native…")
    extras = []
    for p in (metadata_path, library_path):
        if p and os.path.isfile(p):
            extras.append(p)
    if rodroid_dir and os.path.isdir(rodroid_dir):
        for name in ("dump.cs", "script.json", "stringliteral.json"):
            p = os.path.join(rodroid_dir, name)
            if os.path.isfile(p):
                extras.append(p)
    result = correlate_apk(apk_path, extras)
    for key, path in (("unity", unity_report_path), ("il2cpp", il2cpp_report_path)):
        if path and os.path.isfile(path):
            try:
                result[key] = json.loads(Path(path).read_text(encoding="utf-8"))
            except Exception as exc:
                result[key] = {"parseError": str(exc), "path": path}
    from modkit.reworkspace import augment_structured_findings, augment_function_correlations, derive_control_candidates, build_static_relationship_graph
    augment_structured_findings(result)
    check(cb, "RE: статические function/xref связи…")
    augment_function_correlations(result, apk_path=apk_path, library_path=library_path)
    result["controlCandidates"] = derive_control_candidates(result)
    check(cb, "RE: построение статического relationship graph…")
    build_static_relationship_graph(result)
    check(cb, "RE: сохранение корреляционного отчёта…")
    Path(output_path).write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    return json.dumps(result, ensure_ascii=False)


def native_workspace_create(source_path, working_path, state_path, cb=None):
    from shutil import copyfile
    from modkit.reworkspace import NativeWorkspace
    check(cb, "Native Workspace: подготовка рабочей копии…")
    copyfile(source_path, working_path)
    ws = NativeWorkspace(working_path)
    state = {"schema": "modkit-native-state-1.0", "source": source_path,
             "sourceSha256": digest(source_path), "changes": []}
    Path(state_path).write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
    return json.dumps({"summary": ws.summary(), "sections": ws.sections()[:256]}, ensure_ascii=False)


def _native_state(state_path):
    p = Path(state_path)
    if not p.is_file():
        return {"schema": "modkit-native-state-1.0", "changes": []}
    return json.loads(p.read_text(encoding="utf-8"))


def native_workspace_info(working_path, state_path):
    from modkit.reworkspace import NativeWorkspace
    ws = NativeWorkspace(working_path)
    state = _native_state(state_path)
    return json.dumps({"summary": ws.summary(), "sections": ws.sections(),
                       "changes": state.get("changes", [])}, ensure_ascii=False)


def native_workspace_search(working_path, query, limit=200):
    from modkit.reworkspace import NativeWorkspace
    ws = NativeWorkspace(working_path)
    result = {"symbols": ws.symbols(query, int(limit)), "strings": ws.strings(query, limit=int(limit))}
    return json.dumps(result, ensure_ascii=False)


def native_workspace_xrefs(working_path, rva, limit=200):
    from modkit.reworkspace import NativeWorkspace
    ws = NativeWorkspace(working_path)
    value = int(str(rva), 0)
    return json.dumps(ws.direct_calls({value}, limit=int(limit)), ensure_ascii=False)


def native_workspace_disasm(working_path, rva, size=128):
    from modkit.reworkspace import NativeWorkspace
    ws = NativeWorkspace(working_path)
    value = int(str(rva), 0)
    return json.dumps(ws.disassemble(value, int(size)), ensure_ascii=False)


def native_workspace_patch(working_path, state_path, rva, mode, payload, note="", cb=None):
    from modkit.reworkspace import NativeWorkspace
    value = int(str(rva), 0)
    ws = NativeWorkspace(working_path)
    check(cb, f"Native Workspace: изменение RVA 0x{value:x}…")
    if str(mode).lower() == "asm":
        change = ws.patch_asm(value, str(payload), str(note))
    elif str(mode).lower() == "hex":
        change = ws.patch_hex(value, str(payload), str(note))
    else:
        raise ValueError("mode must be asm or hex")
    Path(working_path).write_bytes(ws.elf.blob)
    state = _native_state(state_path)
    state.setdefault("changes", []).append(change)
    Path(state_path).write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
    return json.dumps(change, ensure_ascii=False)


def native_workspace_undo(working_path, state_path):
    from modkit.elf.reader import ElfFile
    state = _native_state(state_path)
    changes = state.setdefault("changes", [])
    if not changes:
        return json.dumps({"undone": False}, ensure_ascii=False)
    change = changes.pop()
    elf = ElfFile.open(working_path)
    elf.write_at_rva(int(change["rva"]), bytes.fromhex(change["old_hex"]))
    Path(working_path).write_bytes(elf.blob)
    Path(state_path).write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
    return json.dumps({"undone": True, "change": change}, ensure_ascii=False)


def native_workspace_save(working_path, output_path):
    from shutil import copyfile
    copyfile(working_path, output_path)
    return json.dumps({"path": output_path, "sha256": digest(output_path)}, ensure_ascii=False)


def patchpack_inspect(source_apk, patch_zip, output_report=None, cb=None):
    from modkit.patchpack import inspect_pack
    check(cb, "Patch Pack: проверка DEX, ABI и native-зависимостей…")
    result = inspect_pack(source_apk, patch_zip)
    if output_report:
        Path(output_report).write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    return json.dumps(result, ensure_ascii=False)


def patchpack_apply_unsigned(source_apk, patch_zip, output_apk, output_report=None, cb=None):
    from modkit.patchpack import apply_pack
    check(cb, "Patch Pack: применение к копии APK…")
    result = apply_pack(source_apk, patch_zip, output_apk)
    if output_report:
        Path(output_report).write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    return json.dumps(result, ensure_ascii=False)


def menu_seed_from_re(re_report_path, menu_json_path, project_dir, title="ModKit Menu", cb=None):
    from modkit.menu import spec_from_analysis, write_project
    check(cb, "Menu Builder: формирование элементов из подтверждённых находок…")
    analysis = json.loads(Path(re_report_path).read_text(encoding="utf-8"))
    spec = spec_from_analysis(analysis, title)
    Path(menu_json_path).write_text(json.dumps(spec.json(), ensure_ascii=False, indent=2), encoding="utf-8")
    result = write_project(spec, project_dir)
    return json.dumps({"spec": spec.json(), "project": result}, ensure_ascii=False)


def _menu_spec_from_json_path(menu_json_path):
    from modkit.menu import MenuControl, MenuSpec
    raw = json.loads(Path(menu_json_path).read_text(encoding="utf-8"))
    controls = []
    for item in raw.get("controls", []):
        controls.append(MenuControl(
            id=str(item.get("id", "")), title=str(item.get("title", "")),
            type=str(item.get("type", "label")), category=str(item.get("category", "General")),
            finding_id=item.get("finding_id"), rva=item.get("rva"),
            min_value=item.get("min_value"), max_value=item.get("max_value"),
            default=item.get("default"), note=str(item.get("note", "")),
            binding=item.get("binding"), target_so=str(item.get("target_so", "libil2cpp.so")),
            is_static=bool(item.get("is_static", True)), value_type=str(item.get("value_type") or "auto"),
            suggested_type=item.get("suggested_type"), evidence_rva=item.get("evidence_rva"),
            evidence_source=str(item.get("evidence_source", "")), evidence_kind=str(item.get("evidence_kind", "")),
            evidence_location=str(item.get("evidence_location", "")),
            evidence_confidence=item.get("evidence_confidence"), evidence_status=str(item.get("evidence_status", "")),
            evidence_count=int(item.get("evidence_count", 0) or 0), corroborating_evidence=list(item.get("corroborating_evidence") or [])[:24],
            suggested_target_so=item.get("suggested_target_so"),
            suggested_binding=item.get("suggested_binding"), evidence_is_static=item.get("evidence_is_static"),
            binding_blocker=item.get("binding_blocker"), evidence_signature=str(item.get("evidence_signature", "")),
            call_abi=str(item.get("call_abi", "native")), resolver_rva=item.get("resolver_rva"),
            resolver_kind=item.get("resolver_kind"), resolver_label=str(item.get("resolver_label", "")),
            resolver_source=str(item.get("resolver_source", "")),
        ))
    return MenuSpec(title=str(raw.get("title", "ModKit Menu")), icon_text=str(raw.get("iconText", "MK")), controls=controls)


def menu_project_from_spec(menu_json_path, project_dir, cb=None):
    from modkit.menu import write_project
    check(cb, "Menu Builder: генерация проекта…")
    spec = _menu_spec_from_json_path(menu_json_path)
    return json.dumps(write_project(spec, project_dir), ensure_ascii=False)


def menu_auto_prepare_from_re(re_report_path, menu_json_path, source_apk, project_dir,
                              output_report=None, output_preflight=None, title="ModKit Menu", cb=None):
    from modkit.menu import spec_from_analysis, auto_confirm_bindings, review_preflight, write_project
    check(cb, "Menu Builder: RE → candidates → signature/ELF auto-confirm…")
    analysis = json.loads(Path(re_report_path).read_text(encoding="utf-8"))
    spec = spec_from_analysis(analysis, title)
    confirm = auto_confirm_bindings(spec, source_apk)
    Path(menu_json_path).write_text(json.dumps(spec.json(), ensure_ascii=False, indent=2), encoding="utf-8")
    project = write_project(spec, project_dir)
    preflight = review_preflight(spec, source_apk)
    result = {"schema": "modkit-menu-auto-prepare-1.0", "confirm": confirm,
              "preflight": preflight, "project": project, "spec": spec.json()}
    if output_report:
        Path(output_report).write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    if output_preflight:
        Path(output_preflight).write_text(json.dumps(preflight, ensure_ascii=False, indent=2), encoding="utf-8")
    return json.dumps(result, ensure_ascii=False)


def menu_auto_confirm(menu_json_path, source_apk, project_dir, output_report=None, cb=None):
    from modkit.menu import auto_confirm_bindings, write_project
    check(cb, "Menu Builder: автоподтверждение сигнатур/RVA по исходному APK…")
    spec = _menu_spec_from_json_path(menu_json_path)
    result = auto_confirm_bindings(spec, source_apk)
    Path(menu_json_path).write_text(json.dumps(spec.json(), ensure_ascii=False, indent=2), encoding="utf-8")
    result["project"] = write_project(spec, project_dir)
    if output_report:
        Path(output_report).write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    return json.dumps(result, ensure_ascii=False)


def menu_review_preflight(menu_json_path, source_apk, output_report=None, cb=None):
    from modkit.menu import review_preflight
    check(cb, "Menu Builder: сводная проверка готовности к payload…")
    spec = _menu_spec_from_json_path(menu_json_path)
    result = review_preflight(spec, source_apk)
    if output_report:
        Path(output_report).write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    return json.dumps(result, ensure_ascii=False)


def menu_validate_spec(menu_json_path, source_apk, output_report=None, cb=None):
    from modkit.menu import validate_bindings
    check(cb, "Menu Builder: проверка RVA по исходному APK…")
    spec = _menu_spec_from_json_path(menu_json_path)
    result = validate_bindings(spec, source_apk)
    if output_report:
        Path(output_report).write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    return json.dumps(result, ensure_ascii=False)



def menu_payload_from_runtime(menu_json_path, source_apk, runtime_so, output_zip, output_report=None, cb=None):
    from modkit.menu import write_patch_payload
    check(cb, "Menu Builder: упаковка native runtime в DEX-free Patch Pack…")
    spec = _menu_spec_from_json_path(menu_json_path)
    result = write_patch_payload(spec, source_apk, runtime_so, output_zip)
    if output_report:
        Path(output_report).write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    return json.dumps(result, ensure_ascii=False)

def menu_export_project(project_dir, menu_json_path, output_zip, cb=None):
    check(cb, "Menu Builder: упаковка проекта…")
    root = Path(project_dir)
    with zipfile.ZipFile(output_zip, "w", zipfile.ZIP_DEFLATED) as z:
        if Path(menu_json_path).is_file():
            z.write(menu_json_path, "modkit-menu.json")
        if root.is_dir():
            for p in sorted(root.rglob("*")):
                check(cb)
                if p.is_file():
                    z.write(p, p.relative_to(root).as_posix())
    return output_zip
