"""Cross-artifact correlation for APK/DEX/Unity/IL2CPP/native evidence.

This module does not claim that a string match is a working modification.  It
keeps provenance and promotes a finding only when independent evidence agrees.
"""
from __future__ import annotations

from collections import defaultdict
from bisect import bisect_right
from dataclasses import dataclass, asdict
import hashlib
import io
from pathlib import Path
import re
import zipfile

from modkit.elf.reader import ElfFile
from modkit.reworkspace.native import direct_bl_calls, arm64_address_xrefs

_PRINTABLE = re.compile(rb"[\x20-\x7e]{4,}")
_DEX_CLASS = re.compile(rb"L(?:[A-Za-z0-9_$]+/)+[A-Za-z0-9_$]+;")

CATEGORY_TERMS = {
    "menu_overlay": ("menu", "overlay", "floating", "windowmanager", "drawmenu", "modmenu"),
    "debug_console": ("console", "debug", "developer", "devmenu", "cheat"),
    "gameplay_controls": (
        "damage", "health", "stamina", "invincible", "godmode", "money", "gold",
        "level", "weather", "noclip", "critical", "crit", "mana", "speed",
    ),
    "monetization_surface": ("purchase", "receipt", "entitlement", "premium", "fullversion", "boughtgame"),
    "hook_framework": ("dobbyhook", "mshookfunction", "a64hook", "shadowhook", "inlinehook", "hookfunction"),
    "il2cpp_surface": ("il2cpp_", "global-metadata", "coderegistration", "metadataregistration"),
}


@dataclass(slots=True)
class Evidence:
    artifact: str
    kind: str
    value: str
    location: str = ""


@dataclass(slots=True)
class Finding:
    id: str
    title: str
    category: str
    status: str
    confidence: float
    evidence: list[Evidence]
    rationale: str

    def json(self) -> dict:
        d = asdict(self)
        return d


def _ascii_strings(blob: bytes, limit: int = 200_000):
    # Generator: do not materialize hundreds of thousands of decoded strings for
    # a 100+ MiB libil2cpp.so at once on a phone.
    count = 0
    for m in _PRINTABLE.finditer(blob):
        yield m.start(), m.group().decode("utf-8", "replace")
        count += 1
        if count >= limit:
            break


def _dex_classes(blob: bytes, limit: int = 200_000) -> set[str]:
    if not blob.startswith(b"dex\n"):
        return set()
    out = set()
    for m in _DEX_CLASS.finditer(blob):
        out.add(m.group().decode("ascii", "replace"))
        if len(out) >= limit:
            break
    return out


_COMPACT_TERMS = {"modmenu", "fullversion", "boughtgame", "dobbyhook", "mshookfunction", "a64hook", "shadowhook", "inlinehook", "hookfunction", "il2cpp_", "global-metadata", "coderegistration", "metadataregistration"}


def _matches(text: str) -> set[str]:
    # Token matching avoids classic false positives such as `mana` in
    # ActivityManager. CamelCase and underscore-separated native identifiers are
    # split first; a small allowlist of genuinely compound markers also matches
    # against the compact representation.
    camel = re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", text)
    words = re.findall(r"[a-z0-9]+", camel.casefold())
    wordset = set(words)
    compact = "".join(words)
    hit = set()
    for category, terms in CATEGORY_TERMS.items():
        for term in terms:
            norm_words = re.findall(r"[a-z0-9]+", term.casefold())
            norm = "".join(norm_words)
            if not norm:
                continue
            if len(norm_words) == 1 and norm in wordset:
                hit.add(category); break
            if term in _COMPACT_TERMS and norm in compact:
                hit.add(category); break
    return hit


def _scan_blob(name: str, blob: bytes, kind: str, *, max_strings: int = 200_000) -> tuple[list[Evidence], set[str]]:
    evidence: list[Evidence] = []
    cats: set[str] = set()
    seen: set[tuple[str, str]] = set()
    for off, text in _ascii_strings(blob, max_strings):
        for cat in _matches(text):
            key = (cat, text)
            if key in seen:
                continue
            seen.add(key); cats.add(cat)
            evidence.append(Evidence(name, kind, text[:240], f"file+0x{off:x}"))
            if len(evidence) >= 2000:
                return evidence, cats
    return evidence, cats


def _scan_elf(name: str, blob: bytes) -> tuple[dict, list[Evidence], set[str]]:
    meta = {"name": name, "size": len(blob), "sha256": hashlib.sha256(blob).hexdigest()}
    ev, cats = _scan_blob(name, blob, "native-string")
    try:
        elf = ElfFile(blob)
        meta.update(elf.info())
        dynamic_symbols = [sym for sym in elf.symbols() if sym.name]
        all_symbols = [sym for sym in elf.all_symbols() if sym.name]
        imports = sorted({sym.name for sym in dynamic_symbols if sym.shndx == 0})
        exports = sorted({sym.name for sym in dynamic_symbols if sym.shndx != 0 and sym.is_global})
        functions = [sym for sym in all_symbols if sym.is_function and sym.shndx != 0]
        jni_exports = [x for x in exports if x == "JNI_OnLoad" or x.startswith("Java_")]
        interesting_apis = (
            "JNI_OnLoad", "RegisterNatives", "dlopen", "android_dlopen_ext", "dlsym",
            "mprotect", "mmap", "eglSwapBuffers", "AMotionEvent_getAction",
            "ptrace", "fork", "execve",
        )
        api_markers = [api for api in interesting_apis if api in imports or api in exports]
        library_refs = sorted({m.group(0).decode("ascii", "replace") for m in re.finditer(rb"lib[A-Za-z0-9_.+\-]{1,80}\.so", blob)})
        # Only treat strings from allocated data sections as possible dlsym/input
        # strings. Symbol/debug string tables are excluded to avoid correlating
        # thousands of C++ symbol names merely because both libraries contain them.
        symbol_string_locations = []
        seen_symbol_strings = set()
        rx_identifier = re.compile(rb"(?<![A-Za-z0-9_])[A-Za-z_][A-Za-z0-9_]{2,79}(?![A-Za-z0-9_])")
        for sec in elf.sections:
            if sec.type != 1 or not sec.is_alloc or sec.is_exec or not sec.size:
                continue
            chunk = blob[sec.offset: sec.offset + sec.size]
            for m in rx_identifier.finditer(chunk):
                value = m.group(0).decode("ascii", "replace")
                if value in seen_symbol_strings:
                    continue
                seen_symbol_strings.add(value)
                file_off = sec.offset + m.start()
                rva = elf.off_to_rva(file_off)
                if rva is None:
                    continue
                symbol_string_locations.append({"value": value, "rva": rva, "fileOffset": file_off, "section": sec.name})
                if len(symbol_string_locations) >= 4000:
                    break
            if len(symbol_string_locations) >= 4000:
                break
        symbol_string_refs = sorted(seen_symbol_strings)
        meta["symbolSummary"] = {
            "total": len(all_symbols), "dynamicTotal": len(dynamic_symbols), "functions": len(functions),
            "imports": len(imports), "exports": len(exports),
            "importsSample": imports[:80], "exportsSample": exports[:80],
            "functionSample": [
                {"name": f.name, "rva": f.value, "size": f.size, "global": f.is_global}
                for f in sorted(functions, key=lambda x: (x.value, x.name))[:160]
            ],
        }
        # Bounded local direct-call graph. For very large libil2cpp binaries this
        # generic graph is intentionally skipped; targeted Rodroid xrefs are added
        # later after the IL2CPP report is loaded.
        text_size = int(meta.get("text_size") or 0)
        if text_size and text_size <= 32 * 1024 * 1024:
            meta["directFunctionCalls"] = direct_bl_calls(elf, limit=2500, max_scan_bytes=32 * 1024 * 1024)
            string_targets = {int(x["rva"]) for x in symbol_string_locations if isinstance(x.get("rva"), int)}
            meta["stringAddressXrefs"] = arm64_address_xrefs(elf, string_targets, limit=3000, max_scan_bytes=32 * 1024 * 1024)
        else:
            meta["directFunctionCalls"] = []
            meta["stringAddressXrefs"] = []
        meta["jni"] = {
            "exports": jni_exports[:80],
            "hasJniOnLoad": "JNI_OnLoad" in exports,
            "importsRegisterNatives": "RegisterNatives" in imports,
        }
        export_rvas = {}
        retained_exports = set(exports[:800])
        for sym in dynamic_symbols:
            if sym.name in retained_exports and sym.shndx != 0 and sym.is_global and sym.name not in export_rvas:
                export_rvas[sym.name] = sym.value
                if len(export_rvas) >= len(retained_exports):
                    break
        meta["linkingSymbols"] = {
            "imports": imports[:800],
            "exports": exports[:800],
            "exportRvas": export_rvas,
        }
        meta["nativeApiMarkers"] = api_markers
        meta["libraryStringRefs"] = library_refs[:120]
        meta["symbolStringRefs"] = symbol_string_refs
        meta["symbolStringLocations"] = symbol_string_locations
        for sym in all_symbols:
            for cat in _matches(sym.name):
                cats.add(cat)
                ev.append(Evidence(name, "native-symbol", sym.name, f"RVA 0x{sym.value:x}"))
        for needed in elf.needed():
            ev.append(Evidence(name, "DT_NEEDED", needed))
    except Exception as exc:
        meta["parseError"] = str(exc)
    return meta, ev, cats


def analyze_artifacts(artifacts) -> dict:
    inventories = {"dex": [], "native": [], "other": []}
    by_category: dict[str, list[Evidence]] = defaultdict(list)
    category_artifacts: dict[str, set[str]] = defaultdict(set)
    dex_classes: dict[str, list[str]] = {}
    dex_strings: dict[str, set[str]] = {}

    items = artifacts.items() if hasattr(artifacts, "items") else artifacts
    for name, blob in items:
        low = name.lower()
        if low.endswith(".dex") and blob.startswith(b"dex\n"):
            classes = sorted(_dex_classes(blob))
            dex_classes[name] = classes
            strings = {text for _off, text in _ascii_strings(blob, 100_000) if 1 <= len(text) <= 160}
            dex_strings[name] = strings
            inventories["dex"].append({"name": name, "size": len(blob), "classes": len(classes),
                                       "loadLibraryMarker": any(x in strings for x in ("loadLibrary", "System.loadLibrary"))})
            ev, cats = _scan_blob(name, blob, "dex-string")
            for cls in classes:
                for cat in _matches(cls):
                    cats.add(cat); ev.append(Evidence(name, "dex-class", cls))
        elif low.endswith(".so") and blob.startswith(b"\x7fELF"):
            meta, ev, cats = _scan_elf(name, blob)
            inventories["native"].append(meta)
        else:
            inventories["other"].append({"name": name, "size": len(blob)})
            ev, cats = _scan_blob(name, blob, "artifact-string", max_strings=50_000)

        for e in ev:
            for cat in _matches(e.value):
                by_category[cat].append(e)
                category_artifacts[cat].add(name)

    # Cross-artifact promotion.  A single string remains a candidate; two
    # independent files/kinds can establish a correlated/confirmed surface.
    findings: list[Finding] = []
    titles = {
        "menu_overlay": "Embedded Android overlay/menu framework",
        "debug_console": "Developer/debug control surface",
        "gameplay_controls": "Gameplay control surface",
        "monetization_surface": "Purchase/entitlement trust surface",
        "hook_framework": "Native hook framework",
        "il2cpp_surface": "IL2CPP native/metadata surface",
    }
    for cat, evs in by_category.items():
        artifacts_n = len(category_artifacts[cat])
        kinds = {e.kind for e in evs}
        if artifacts_n >= 2 and len(kinds) >= 2:
            status, confidence = "confirmed", min(0.98, 0.80 + 0.02 * min(len(evs), 9))
        elif artifacts_n >= 2 or len(kinds) >= 2:
            status, confidence = "correlated", 0.72
        else:
            status, confidence = "candidate", 0.48
        # Keep the report bounded but retain the strongest heterogeneous evidence.
        selected = []
        used = set()
        for e in evs:
            key = (e.artifact, e.kind, e.value)
            if key in used:
                continue
            used.add(key); selected.append(e)
            if len(selected) >= 40:
                break
        findings.append(Finding(
            f"re.{cat}", titles.get(cat, cat), cat, status, confidence, selected,
            f"{artifacts_n} artifact(s), {len(kinds)} evidence kind(s); status is evidence-strength, not proof of runtime behavior.",
        ))

    # Strong composition finding: menu + hooks + IL2CPP across the same pack.
    if {"menu_overlay", "hook_framework", "il2cpp_surface"} <= set(by_category):
        evs = []
        for cat in ("menu_overlay", "hook_framework", "il2cpp_surface"):
            evs.extend(by_category[cat][:12])
        findings.append(Finding(
            "re.native_menu_il2cpp", "Native menu/hook stack connected to IL2CPP",
            "cross_artifact", "confirmed", 0.94, evs,
            "Independent DEX/native menu, hook-framework and IL2CPP evidence are present in the analyzed artifact set.",
        ))

    if {"menu_overlay", "debug_console", "gameplay_controls"} <= set(by_category):
        evs = []
        for cat in ("menu_overlay", "debug_console", "gameplay_controls"):
            evs.extend(by_category[cat][:12])
        findings.append(Finding(
            "re.developer_gameplay_surface", "Developer/debug/gameplay control surface",
            "cross_artifact", "confirmed", 0.93, evs,
            "Overlay/menu evidence is correlated with explicit debug-console and gameplay-control markers. Review provenance to determine whether it is developer tooling, a bundled test menu, or a third-party overlay.",
        ))

    native_by_base: dict[str, list[dict]] = defaultdict(list)
    for row in inventories["native"]:
        native_by_base[Path(str(row.get("name", ""))).name].append(row)
    dependency_edges = []
    external_dependencies = []
    jni_surfaces = []
    dynamic_loaders = []
    render_surfaces = []
    native_string_edges = []
    native_symbol_edges = []
    dynamic_symbol_edges = []
    jni_direct_calls = []
    jni_call_chains = []
    dex_native_links = []
    for row in inventories["native"]:
        host = str(row.get("name", ""))
        for dep in row.get("needed", []) or []:
            targets = native_by_base.get(str(dep), [])
            if targets:
                for target in targets[:4]:
                    dependency_edges.append({"from": host, "to": str(target.get("name", dep)), "kind": "DT_NEEDED"})
            else:
                external_dependencies.append({"from": host, "dependency": str(dep)})
        for ref in row.get("libraryStringRefs", []) or []:
            targets = native_by_base.get(str(ref), [])
            for target in targets[:4]:
                target_name = str(target.get("name", ref))
                if target_name != host:
                    native_string_edges.append({"from": host, "to": target_name, "kind": "embedded-library-string", "value": ref})
        jni = row.get("jni") or {}
        if jni.get("hasJniOnLoad") or jni.get("exports") or jni.get("importsRegisterNatives"):
            jni_surfaces.append({"artifact": host, **jni})
        markers = set(row.get("nativeApiMarkers") or [])
        if markers & {"dlopen", "android_dlopen_ext", "dlsym"}:
            dynamic_loaders.append({"artifact": host, "apis": sorted(markers & {"dlopen", "android_dlopen_ext", "dlsym"})})
        if markers & {"eglSwapBuffers", "AMotionEvent_getAction"}:
            render_surfaces.append({"artifact": host, "apis": sorted(markers & {"eglSwapBuffers", "AMotionEvent_getAction"})})
        calls = row.get("directFunctionCalls", []) or []
        for call in calls:
            src = str(call.get("sourceFunction") or "")
            if src == "JNI_OnLoad" or src.startswith("Java_"):
                jni_direct_calls.append({"artifact": host, **call})
        # Follow only already-resolved named direct BL edges, max depth 4.
        by_source: dict[int, list[dict]] = defaultdict(list)
        roots = []
        for call in calls:
            sr = call.get("sourceRva")
            if isinstance(sr, int):
                by_source[sr].append(call)
            src = str(call.get("sourceFunction") or "")
            if (src == "JNI_OnLoad" or src.startswith("Java_")) and isinstance(sr, int):
                roots.append((sr, src))
        for root_rva, root_name in list(dict.fromkeys(roots))[:32]:
            queue = [(root_rva, root_name, [{"name": root_name, "rva": root_rva}], [], 0)]
            seen_paths = 0
            while queue and seen_paths < 80:
                current_rva, current_name, funcs_path, calls_path, depth = queue.pop(0)
                if depth >= 4:
                    continue
                for edge in by_source.get(current_rva, [])[:24]:
                    tr = edge.get("targetRva")
                    tn = str(edge.get("targetFunction") or "")
                    if not isinstance(tr, int) or not tn:
                        continue
                    if any(x.get("rva") == tr for x in funcs_path):
                        continue
                    new_funcs = funcs_path + [{"name": tn, "rva": tr}]
                    new_calls = calls_path + [int(edge.get("callRva") or 0)]
                    jni_call_chains.append({"artifact": host, "root": root_name, "functions": new_funcs, "callRvas": new_calls, "depth": depth + 1})
                    seen_paths += 1
                    if depth + 1 < 4:
                        queue.append((tr, tn, new_funcs, new_calls, depth + 1))
                    if seen_paths >= 80:
                        break

    # Function-level SO↔SO linkage from exact imported/exported dynamic symbols.
    export_index: dict[str, list[str]] = defaultdict(list)
    for row in inventories["native"]:
        host = str(row.get("name", ""))
        for symbol in (row.get("linkingSymbols") or {}).get("exports", []) or []:
            export_index[str(symbol)].append(host)
    for row in inventories["native"]:
        host = str(row.get("name", ""))
        for symbol in (row.get("linkingSymbols") or {}).get("imports", []) or []:
            for target in export_index.get(str(symbol), [])[:8]:
                if target == host:
                    continue
                target_row = next((x for x in inventories["native"] if str(x.get("name", "")) == target), None)
                target_rva = ((target_row or {}).get("linkingSymbols") or {}).get("exportRvas", {}).get(str(symbol))
                native_symbol_edges.append({
                    "from": host, "to": target, "kind": "import-export-symbol",
                    "symbol": str(symbol), "targetRva": target_rva, "confidence": 0.96,
                    "rationale": "Source ELF imports an exact dynamic symbol exported by the target ELF.",
                })

    # dlsym-based links are weaker: require both a packaged downstream-library
    # relation and a string equal to an exported target symbol. This does not claim
    # that the string reaches dlsym at runtime.
    string_edge_pairs = {(str(x.get("from", "")), str(x.get("to", ""))) for x in native_string_edges}
    for row in inventories["native"]:
        host = str(row.get("name", ""))
        if "dlsym" not in set(row.get("nativeApiMarkers") or []):
            continue
        refs = set(row.get("symbolStringRefs") or [])
        own = set((row.get("linkingSymbols") or {}).get("imports", []) or []) | set((row.get("linkingSymbols") or {}).get("exports", []) or [])
        refs -= own
        refs = {x for x in refs if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]{2,79}", x) and not x.startswith("_Z") and x not in {"JNI_OnLoad", "JNIEnv", "JavaVM"}}
        if not refs:
            continue
        for target_row in inventories["native"]:
            target = str(target_row.get("name", ""))
            if target == host or (host, target) not in string_edge_pairs:
                continue
            target_exports = set((target_row.get("linkingSymbols") or {}).get("exports", []) or [])
            for symbol in sorted(refs & target_exports)[:80]:
                target_rva = ((target_row.get("linkingSymbols") or {}).get("exportRvas") or {}).get(symbol)
                dynamic_symbol_edges.append({
                    "from": host, "to": target, "kind": "dlsym-string-export",
                    "symbol": symbol, "targetRva": target_rva, "confidence": 0.78,
                    "rationale": "Source contains dlsym, references the target library and embeds an exact exported symbol name; runtime data flow is not claimed.",
                })

    for edge in dynamic_symbol_edges:
        row = next((x for x in inventories["native"] if str(x.get("name", "")) == str(edge.get("from", ""))), None)
        if not row:
            continue
        loc = next((x for x in row.get("symbolStringLocations", []) or [] if str(x.get("value", "")) == str(edge.get("symbol", ""))), None)
        if loc:
            edge["stringRva"] = loc.get("rva")
            edge["stringFileOffset"] = loc.get("fileOffset")
            edge["stringSection"] = loc.get("section")
            xrefs = [x for x in row.get("stringAddressXrefs", []) or [] if x.get("targetRva") == loc.get("rva")]
            if xrefs:
                edge["staticStringXrefs"] = xrefs[:16]
                edge["confidence"] = max(float(edge.get("confidence", 0.0)), 0.88)
                edge["rationale"] = (str(edge.get("rationale", "")) + " ARM64 ADRP+ADD also materializes this exact string address in code; runtime dlsym data flow is still not claimed.")

    for dex_name, strings in dex_strings.items():
        lower = {x.casefold() for x in strings}
        has_loader = "loadlibrary" in lower or "system.loadlibrary" in lower
        for base, targets in native_by_base.items():
            if not (base.startswith("lib") and base.endswith(".so")):
                continue
            stem = base[3:-3]
            if base.casefold() not in lower and stem.casefold() not in lower:
                continue
            for target in targets[:4]:
                jni = target.get("jni") or {}
                dex_native_links.append({
                    "from": dex_name, "to": str(target.get("name", base)),
                    "kind": "dex-library-name", "library": base, "stem": stem,
                    "loadLibraryMarker": has_loader, "jniOnLoad": bool(jni.get("hasJniOnLoad")),
                    "confidence": 0.92 if has_loader and jni.get("hasJniOnLoad") else (0.84 if has_loader else 0.66),
                    "rationale": ("DEX contains a matching library-name string and loadLibrary marker; target ELF exports JNI_OnLoad."
                                  if has_loader and jni.get("hasJniOnLoad") else
                                  "Static name correlation only; call-site association is not claimed."),
                })

    native_relations = {
        "schema": "modkit-native-relations-1.2",
        "libraries": len(inventories["native"]),
        "dependencyEdges": dependency_edges[:400],
        "embeddedLibraryStringEdges": native_string_edges[:400],
        "symbolEdges": native_symbol_edges[:800],
        "dynamicSymbolEdges": dynamic_symbol_edges[:400],
        "dexNativeLinks": dex_native_links[:200],
        "externalDependencies": external_dependencies[:400],
        "jniSurfaces": jni_surfaces[:80],
        "jniDirectCallRefs": jni_direct_calls[:400],
        "jniCallChains": jni_call_chains[:800],
        "dynamicLoadingSurfaces": dynamic_loaders[:80],
        "renderInputSurfaces": render_surfaces[:80],
    }

    if native_symbol_edges:
        evs = [Evidence(str(x.get("from", "")), "native-import-export", str(x.get("symbol", "")), str(x.get("to", "")))
               for x in native_symbol_edges[:40]]
        findings.append(Finding(
            "re.native_import_export_bridge", "Cross-library native function linkage", "native_function_bridge",
            "confirmed", 0.96, evs,
            "One packaged ELF imports exact dynamic symbol names exported by another packaged ELF. This is static linker evidence, not runtime execution proof.",
        ))

    scoped_dynamic = [x for x in dynamic_symbol_edges if x.get("staticStringXrefs")]
    if scoped_dynamic:
        evs = []
        for edge in scoped_dynamic[:20]:
            for xref in (edge.get("staticStringXrefs") or [])[:2]:
                src = str(xref.get("sourceFunction") or f"sub_{int(xref.get('xrefRva') or 0):x}")
                evs.append(Evidence(str(edge.get("from", "")), "native-dlsym-string-xref",
                                    f"{src} -> {edge.get('symbol', '')}",
                                    f"{edge.get('to', '')}; string RVA 0x{int(edge.get('stringRva') or 0):x}"))
        findings.append(Finding(
            "re.native_dynamic_symbol_bridge", "Function-scoped dynamic native symbol bridge", "native_function_bridge",
            "correlated", 0.90, evs[:40],
            "A function statically materializes an exact symbol-name string while its ELF exposes dlsym and references a packaged library exporting that symbol. This narrows the loader path but does not prove the string is passed to dlsym at runtime.",
        ))

    strong_dex_native = [x for x in dex_native_links if x.get("loadLibraryMarker") and x.get("jniOnLoad")]
    if strong_dex_native:
        chain_evidence: list[Evidence] = []
        for link in strong_dex_native[:8]:
            chain_evidence.append(Evidence(str(link.get("from", "DEX")), "dex-native-link",
                                           str(link.get("library", "")), str(link.get("to", ""))))
        strong_targets = {str(x.get("to", "")) for x in strong_dex_native}
        for edge in native_string_edges[:24]:
            if str(edge.get("from", "")) in strong_targets:
                chain_evidence.append(Evidence(str(edge.get("from", "")), "embedded-library-reference",
                                               str(edge.get("value", "")), str(edge.get("to", ""))))
        for row in dynamic_loaders[:16]:
            if str(row.get("artifact", "")) in strong_targets:
                chain_evidence.append(Evidence(str(row.get("artifact", "")), "dynamic-loader-api",
                                               ", ".join(row.get("apis") or []), ""))
        extended = len(chain_evidence) > len(strong_dex_native)
        findings.append(Finding(
            "re.dex_native_loader_bridge", "DEX-to-native loader bridge", "dex_native_bridge",
            "confirmed" if extended else "correlated", 0.97 if extended else 0.91, chain_evidence[:40],
            ("DEX contains a matching library-name plus loadLibrary marker and the target ELF exports JNI_OnLoad; "
             + ("the native library also exposes a static downstream library/dynamic-loader link. " if extended else "")
             + "This confirms a packaged loader relationship, not execution of any specific native function."),
        ))

    return {
        "schema": "modkit-re-1.1",
        "inventory": inventories,
        "nativeRelations": native_relations,
        "dexClasses": dex_classes,
        "findings": [f.json() for f in sorted(findings, key=lambda x: (-x.confidence, x.id))],
    }


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            chunk = f.read(1024 * 1024)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def correlate_apk(apk_path: str | Path, extra_paths: list[str | Path] | None = None) -> dict:
    apk_path = Path(apk_path)

    skipped = []

    def iter_artifacts():
        # Analyze one archive entry at a time.  This is deliberate: production
        # Unity APKs can contain a 100-500 MiB libil2cpp plus many other .so files.
        # Keeping every native blob in a dict simultaneously recreates the OOM
        # problem which 0.8.1's bundle memory fix was meant to avoid.
        with zipfile.ZipFile(apk_path) as z:
            for info in z.infolist():
                low = info.filename.lower()
                if not (low.endswith(".dex") or low.endswith(".so") or "global-metadata" in low or low.endswith((".json", ".txt", ".xml"))):
                    continue
                cap = 512 * 1024 * 1024 if low.endswith(".so") else 128 * 1024 * 1024
                if info.file_size <= cap:
                    yield info.filename, z.read(info)
                else:
                    skipped.append({"artifact": info.filename, "size": info.file_size, "reason": f"bounded scanner cap {cap} bytes"})
        for path in extra_paths or []:
            p = Path(path)
            if p.is_file():
                cap = 512 * 1024 * 1024 if p.suffix.lower() == ".so" else 256 * 1024 * 1024
                if p.stat().st_size <= cap:
                    yield f"extra/{p.name}", p.read_bytes()
                else:
                    skipped.append({"artifact": str(p), "size": p.stat().st_size, "reason": f"bounded scanner cap {cap} bytes"})

    result = analyze_artifacts(iter_artifacts())
    result["apk"] = {"path": str(apk_path), "sha256": _sha256_file(apk_path)}
    result["memoryModel"] = "sequential-artifact-scan"
    result["skippedArtifacts"] = skipped
    return result



_CONTROL_MARKER = re.compile(
    r"(?i)(cheat|debug|console|god|invic|noclip|health|damage|stamina|mana|money|gold|level|weather|speed|crit|rva[_ -]|developer)"
)


def _candidate_title(value: str) -> str:
    text = str(value).strip().replace("\\", "/")
    if "/" in text:
        text = text.rsplit("/", 1)[-1]
    text = re.sub(r"\.(png|jpg|jpeg|asset|prefab|unity)$", "", text, flags=re.I)
    text = re.sub(r"^PPtr<\$|>$", "", text)
    text = re.sub(r"[_-]+", " ", text)
    text = re.sub(r"\s+", " ", text).strip(" +:-")
    return text[:120]


def _suggested_control(value: str) -> str:
    text = str(value)
    low = text.casefold()
    if re.search(r"(?i)::(?:\.ctor|\.cctor|update|lateupdate|awake|start|reset|onenable|ondisable|ondestroy|movenext|setstatemachine)\(", text):
        return "review"
    # A method-shaped action is safer to present as a button suggestion than as a
    # bool setter: Toggle*/Activate*/Enable* does not imply a bool parameter.
    if re.search(r"(?i)::(?:toggle|activate|deactivate|enable|disable|show|hide|spawn|give|teleport|port)[A-Za-z0-9_]*\(", text):
        return "button"
    if re.search(r"(?i)::(?:get_|get|is|has)[A-Za-z0-9_]*\(", text):
        return "review"
    if any(x in low for x in ("noclip", "invic", "god", "cheat mode", "infinite")):
        return "toggle"
    if any(x in low for x in ("action", "levelup", "weather", "equip", "console")):
        return "button"
    if any(x in low for x in ("damage", "health", "money", "mana", "stamina", "speed", "crit")):
        return "slider_or_toggle"
    return "review"


def derive_control_candidates(report: dict, limit: int = 200) -> list[dict]:
    """Extract reviewable menu/control candidates with provenance.

    This deliberately does *not* bind or call an address.  Even native symbols
    named like RVA_* may be configuration/storage symbols rather than the target
    function itself, so their address is retained only as evidenceRva.
    """
    out: list[dict] = []
    seen: dict[str, int] = {}

    def add(value: str, source: str, kind: str, location: str = "", confidence: float = 0.55, contract: dict | None = None, resolver: dict | None = None):
        if not value or not _CONTROL_MARKER.search(value):
            return
        # Keep collection bounded, but do not use the user-visible limit as an
        # early cutoff: stronger evidence sources are merged and globally ranked
        # before the final slice.
        if len(out) >= max(800, int(limit) * 8):
            return
        title = _candidate_title(value)
        if len(title) < 3:
            return
        key = re.sub(r"[^a-z0-9]+", "", title.casefold())
        if not key:
            return
        # Avoid ordinary game UI art unless it explicitly belongs to debug/cheat tooling.
        low = value.casefold()
        if low.startswith(".debug") or low in {"debug_abbrev", "debug_info", "debug_line", "debug_loc", "debug_ranges", "debug_str"}:
            return
        if (low.endswith((".png", ".jpg", ".jpeg")) or "/gui/" in low) and not any(x in low for x in ("cheat", "debug", "console")):
            return
        evidence_rva = None
        m = re.fullmatch(r"RVA\s+0x([0-9a-fA-F]+)", location.strip())
        if m:
            evidence_rva = int(m.group(1), 16)
        score = float(confidence)
        low_compact = re.sub(r"[^a-z0-9]+", "", low)
        if any(x in low for x in ("cheat_", "canvas_cheat", "rva_")):
            score += 0.24
        elif "cheat " in low or "cheatgamehandler" in low:
            score += 0.15
        elif "debug_" in low or "debugonkey" in low:
            score += 0.10
        elif "debug " in low:
            score += 0.05
        if any(x in low_compact for x in ("noclip", "invic", "godmode", "levelup", "weather", "cheatmode")):
            score += 0.10
        if not any(x in low for x in ("cheat", "debug", "console", "rva_")) and any(x in low for x in ("health", "damage", "money", "mana", "stamina")):
            score -= 0.12
        actionish = bool(re.search(r"(?i)::(?:toggle|activate|deactivate|enable|disable|show|hide|spawn|give|teleport|port|set)[A-Za-z0-9_]*\(", value))
        getterish = bool(re.search(r"(?i)::(?:get_|get|is|has)[A-Za-z0-9_]*\(", value))
        explicit_surface = any(x in low for x in ("cheatgamehandler", "cheat_", "cheat ", "noclip", "invic", "godmode", "consolewindow", "debugonkey"))
        if explicit_surface and actionish:
            score += 0.18
        elif getterish and ("debug" in low or "cheat" in low):
            score -= 0.16
        lifecycle_or_generated = bool(re.search(r"(?i)::(?:\.ctor|\.cctor|update|lateupdate|awake|start|reset|onenable|ondisable|ondestroy|movenext|setstatemachine)\(", value))
        if lifecycle_or_generated:
            score -= 0.24
        if "checkchunkperf" in low and not re.search(r"(?i)::(?:toggle|enable|disable|activate|deactivate)", value):
            score -= 0.22
        score = max(0.20, min(0.99, score))
        evidence_item = {"source": source, "kind": kind, "value": value[:240], "location": location,
                         "evidenceRva": evidence_rva, "signatureContract": contract}
        if key in seen:
            item = out[seen[key]]
            evs = item.setdefault("corroboratingEvidence", [])
            sig = (source, kind, value[:240], location)
            existing = {(e.get("source"), e.get("kind"), e.get("value"), e.get("location")) for e in evs}
            primary = (item.get("source"), item.get("kind"), item.get("value"), item.get("location"))
            if sig != primary and sig not in existing:
                evs.append(evidence_item)
                item["status"] = "correlated"
                item["confidence"] = round(min(0.99, max(float(item.get("confidence", 0.0)), score) + 0.06), 2)
            if contract and not item.get("signatureContract"):
                item["signatureContract"] = contract
                item["bindingSuggestion"] = contract.get("bindingSuggestion")
                item["bindingBlocker"] = contract.get("bindingBlocker")
                item["isStatic"] = contract.get("isStatic")
                item["suggestedType"] = contract.get("suggestedControlType") or {
                    "action": "button", "bool_setter": "toggle",
                    "number_setter": "slider_or_toggle",
                }.get(contract.get("bindingSuggestion"), item.get("suggestedType"))
            if resolver and not item.get("instanceResolver"):
                item["instanceResolver"] = resolver
                item["resolverRva"] = resolver.get("rva")
                item["resolverKind"] = resolver.get("kind")
                item["bindingBlocker"] = "instance-resolver-review-required"
            if item.get("evidenceRva") is None and evidence_rva is not None:
                # Prefer the address-bearing evidence as primary, but preserve the
                # previous primary source in corroboratingEvidence so provenance
                # is never lost during promotion.
                old_primary = {"source": item.get("source", ""), "kind": item.get("kind", ""),
                               "value": item.get("value", ""), "location": item.get("location", ""),
                               "evidenceRva": item.get("evidenceRva")}
                old_sig = (old_primary["source"], old_primary["kind"], old_primary["value"], old_primary["location"])
                # The new address-bearing evidence becomes primary, so remove its
                # duplicate from corroboratingEvidence if it was appended above.
                evs[:] = [e for e in evs if (e.get("source"), e.get("kind"), e.get("value"), e.get("location")) != sig]
                existing = {(e.get("source"), e.get("kind"), e.get("value"), e.get("location")) for e in evs}
                if old_sig != sig and old_sig not in existing:
                    evs.append(old_primary)
                item["evidenceRva"] = evidence_rva
                item["source"], item["kind"], item["value"], item["location"] = source, kind, value[:240], location
            item["evidenceCount"] = 1 + len(evs)
            return
        suggested_visual = _suggested_control(value)
        if contract:
            suggested_visual = contract.get("suggestedControlType") or {
                "action": "button",
                "bool_setter": "toggle",
                "number_setter": "slider_or_toggle",
            }.get(contract.get("bindingSuggestion"), suggested_visual)
        seen[key] = len(out)
        out.append({
            "id": "candidate." + key[:56],
            "title": title,
            "suggestedType": suggested_visual,
            "status": "review",
            "confidence": round(score, 2),
            "source": source,
            "kind": kind,
            "value": value[:240],
            "location": location,
            "evidenceRva": evidence_rva,
            "evidenceCount": 1,
            "corroboratingEvidence": [],
            "signatureContract": contract,
            "bindingSuggestion": contract.get("bindingSuggestion") if contract else None,
            "bindingBlocker": ("instance-resolver-review-required" if resolver else (contract.get("bindingBlocker") if contract else None)),
            "isStatic": contract.get("isStatic") if contract else None,
            "instanceResolver": resolver,
            "resolverRva": resolver.get("rva") if resolver else None,
            "resolverKind": resolver.get("kind") if resolver else None,
            "binding": None,
            "rationale": ("Instance method with same-class static resolver candidate; review method signature and resolver before binding."
                          if resolver else "Candidate extracted from static evidence; review signature/calling convention before binding."),
        })

    for finding in report.get("findings", []):
        conf = float(finding.get("confidence", 0.5))
        for ev in finding.get("evidence", []):
            add(str(ev.get("value", "")), str(ev.get("artifact", "")), str(ev.get("kind", "")),
                str(ev.get("location", "")), conf)

    unity = report.get("unity") or {}
    for catalog in unity.get("catalogs", []) or []:
        for f in catalog.get("findings", []) or []:
            value = str(f.get("primary_key") or f.get("asset") or "")
            add(value, str(catalog.get("apk_entry", "Addressables catalog")), "addressables", "", 0.65)
    for bundle in unity.get("bundles", []) or []:
        source = str(bundle.get("apk_entry") or bundle.get("sha256") or "UnityFS bundle")
        for value in bundle.get("matched_strings", []) or []:
            add(str(value), source, "unity-string", "", 0.58)

    il2cpp = report.get("il2cpp") or {}
    structured_rows = []
    for key in ("metadata_resolved_methods", "discoveries", "candidates"):
        structured_rows.extend(il2cpp.get(key, []) or [])
    resolver_candidates: dict[str, list[dict]] = defaultdict(list)
    for row in structured_rows:
        contract = row.get("signature_contract") or {}
        rva = row.get("rva")
        label = str(row.get("label", ""))
        if contract.get("resolverSuggestion") != "out_ptr_bool" or not isinstance(rva, int) or rva <= 0 or "::" not in label:
            continue
        owner, method = label.rsplit("::", 1)
        priority = 0
        ml = method.casefold()
        if ml.startswith("tryget"): priority += 4
        if "instance" in ml: priority += 3
        if ml.startswith("get"): priority += 1
        resolver_candidates[owner].append({
            "rva": rva, "kind": "out_ptr_bool", "label": label,
            "source": str(row.get("image", "Rodroid")), "contract": contract, "priority": priority,
        })
    resolvers = {}
    for owner, rows in resolver_candidates.items():
        rows.sort(key=lambda x: (-x["priority"], x["rva"]))
        if len(rows) == 1 or rows[0]["priority"] > rows[1]["priority"]:
            resolvers[owner] = rows[0]

    # Confirmed metadata mappings and semantic discoveries are processed before
    # the large generic getter list, so high-signal developer controls cannot be
    # displaced by thousands of ordinary gameplay properties.
    for row in il2cpp.get("metadata_resolved_methods", []) or []:
        label = str(row.get("label", ""))
        rva = row.get("rva")
        loc = f"RVA 0x{int(rva):x}" if isinstance(rva, int) and rva > 0 else ""
        conf = 0.90 if row.get("resolution") == "confirmed-unique" else 0.78
        owner = label.rsplit("::", 1)[0] if "::" in label else ""
        contract = row.get("signature_contract") or {}
        resolver = resolvers.get(owner) if contract.get("isStatic") is False else None
        add(label, str(row.get("image", "IL2CPP metadata")), "il2cpp-metadata-method", loc, conf, contract, resolver)
    for row in il2cpp.get("discoveries", []) or []:
        label = str(row.get("label", ""))
        rva = row.get("rva")
        loc = f"RVA 0x{int(rva):x}" if isinstance(rva, int) and rva > 0 else ""
        kind = "rodroid-field" if row.get("item_type") == "field" else "rodroid-discovery"
        owner = label.rsplit("::", 1)[0] if "::" in label else ""
        contract = row.get("signature_contract") or {}
        resolver = resolvers.get(owner) if contract.get("isStatic") is False else None
        add(label, str(row.get("image", "Rodroid")), kind, loc, 0.78 if rva else 0.64, contract, resolver)
    for row in il2cpp.get("candidates", []) or []:
        label = str(row.get("label", ""))
        rva = row.get("rva")
        loc = f"RVA 0x{int(rva):x}" if isinstance(rva, int) and rva > 0 else ""
        owner = label.rsplit("::", 1)[0] if "::" in label else ""
        contract = row.get("signature_contract") or {}
        resolver = resolvers.get(owner) if contract.get("isStatic") is False else None
        add(label, str(row.get("image", "Rodroid")), "rodroid-method", loc, 0.72, contract, resolver)

    out.sort(key=lambda x: (-x["confidence"], x["title"].casefold()))
    return out[:limit]


def augment_function_correlations(report: dict, apk_path: str | Path | None = None, library_path: str | Path | None = None, *, max_targets: int = 96) -> dict:
    """Add bounded static function/xref evidence after IL2CPP data is loaded.

    The scanner only decodes direct ARM64 ``BL`` instructions.  Results are static
    references inside the ELF image, not runtime traces, and indirect calls are
    deliberately not guessed.
    """
    il2cpp = report.get("il2cpp") or {}
    rows = []
    for key in ("metadata_resolved_methods", "discoveries", "candidates"):
        rows.extend(il2cpp.get(key, []) or [])

    method_rows_by_rva: dict[int, list[dict]] = defaultdict(list)
    for row in rows:
        rva = row.get("rva")
        if isinstance(rva, int) and rva > 0 and row.get("label"):
            method_rows_by_rva[rva].append(row)
    method_starts = sorted(method_rows_by_rva)

    targets: dict[int, list[dict]] = defaultdict(list)
    for row in rows:
        rva = row.get("rva")
        label = str(row.get("label") or "")
        if not isinstance(rva, int) or rva <= 0 or not label:
            continue
        # Prioritize the same high-signal surface used by Menu Builder.  Generic
        # methods remain available through the Native Workspace on demand.
        if not _CONTROL_MARKER.search(label):
            continue
        bucket = targets[rva]
        if not any(x.get("label") == label for x in bucket):
            bucket.append({"label": label, "image": str(row.get("image") or ""),
                           "signature": str((row.get("signature_contract") or {}).get("signature") or row.get("signature") or "")})
        if len(targets) >= max_targets:
            break
    if not targets:
        return report

    blob = None
    artifact_name = "libil2cpp.so"
    source = None
    if library_path:
        lp = Path(library_path)
        if lp.is_file() and lp.stat().st_size <= 512 * 1024 * 1024:
            blob = lp.read_bytes(); source = str(lp)
    if blob is None and apk_path:
        ap = Path(apk_path)
        if ap.is_file():
            with zipfile.ZipFile(ap) as z:
                choices = [i for i in z.infolist() if i.filename.lower().endswith("/libil2cpp.so") and i.file_size <= 512 * 1024 * 1024]
                choices.sort(key=lambda i: (0 if "arm64-v8a" in i.filename.lower() else 1, i.filename))
                if choices:
                    info = choices[0]
                    blob = z.read(info); source = info.filename; artifact_name = info.filename
    if not blob or not blob.startswith(b"\x7fELF"):
        return report

    try:
        elf = ElfFile(blob)
        calls = direct_bl_calls(elf, set(targets), limit=5000, max_scan_bytes=256 * 1024 * 1024)
    except Exception as exc:
        report.setdefault("nativeRelations", {}).setdefault("functionCorrelationErrors", []).append({
            "artifact": artifact_name, "error": str(exc)
        })
        return report

    refs = []
    for call in calls:
        labels = targets.get(int(call.get("targetRva") or 0), [])
        ref = {
            "artifact": artifact_name,
            "source": source,
            **call,
            "targetMethods": labels[:8],
            "confidence": 0.96,
            "rationale": "ARM64 direct BL resolves exactly to an address-bearing Rodroid/IL2CPP method RVA.",
        }
        call_rva = int(call.get("callRva") or 0)
        if method_starts and call_rva > 0:
            idx = bisect_right(method_starts, call_rva) - 1
            if idx >= 0:
                start = method_starts[idx]
                next_start = method_starts[idx + 1] if idx + 1 < len(method_starts) else None
                span = call_rva - start
                if 0 <= span <= 0x40000 and (next_start is None or call_rva < next_start):
                    candidates = method_rows_by_rva[start]
                    source_rows = [{
                        "label": str(x.get("label") or ""),
                        "image": str(x.get("image") or ""),
                        "rva": start,
                        "signature": str((x.get("signature_contract") or {}).get("signature") or x.get("signature") or ""),
                    } for x in candidates[:8]]
                    ref["sourceMethodCandidates"] = source_rows
                    ref["sourceInterval"] = {"startRva": start, "nextMethodRva": next_start, "callOffset": span}
                    # If only one managed method starts at this RVA, attribution is
                    # strong static interval evidence; duplicate/generic starts stay ambiguous.
                    ref["sourceAttribution"] = "unique-managed-interval" if len(candidates) == 1 else "ambiguous-shared-rva"
        refs.append(ref)
    relations = report.setdefault("nativeRelations", {})
    relations["il2cppDirectCallRefs"] = refs[:5000]
    relations["il2cppDirectCallTargets"] = len({x["targetRva"] for x in refs})

    if refs:
        evidence = []
        for ref in refs[:40]:
            target = (ref.get("targetMethods") or [{}])[0]
            src_methods = ref.get("sourceMethodCandidates") or []
            src_fn = str((src_methods[0].get("label") if src_methods else None) or ref.get("sourceFunction") or f"sub_{int(ref.get('callRva') or 0):x}")
            evidence.append({
                "artifact": artifact_name,
                "kind": "arm64-direct-bl-xref",
                "value": f"{src_fn} -> {target.get('label', 'IL2CPP method')}",
                "location": f"call RVA 0x{int(ref.get('callRva') or 0):x} -> 0x{int(ref.get('targetRva') or 0):x}",
            })
        finding = {
            "id": "re.il2cpp_static_call_references",
            "title": "Static call references to address-bearing IL2CPP controls",
            "category": "il2cpp_function_xrefs",
            "status": "correlated",
            "confidence": 0.96,
            "evidence": evidence,
            "rationale": (f"{len(refs)} ARM64 direct BL reference(s) resolve exactly to {relations['il2cppDirectCallTargets']} "
                          "address-bearing IL2CPP target(s). This is static xref evidence, not runtime execution proof."),
        }
        findings = report.setdefault("findings", [])
        findings[:] = [x for x in findings if x.get("id") != finding["id"]]
        findings.append(finding)
        findings.sort(key=lambda f: (-float(f.get("confidence", 0.0)), str(f.get("id", ""))))
    return report



def build_static_relationship_graph(report: dict, *, max_chains: int = 80) -> dict:
    """Build a bounded cross-artifact graph from already-collected static evidence.

    Edges deliberately preserve their evidence class.  A DEX library-name match,
    JNI direct BL, embedded-library string, dlsym string xref and IL2CPP direct BL
    are *not* treated as interchangeable execution proof.  Complete chains are
    emitted only when directed evidence connects a DEX loader root to a reviewable
    control candidate.  Otherwise the graph records partial chains and explicit
    gaps instead of inventing a missing hop.
    """
    relations = report.get("nativeRelations") or {}
    controls = report.get("controlCandidates") or []

    nodes: dict[str, dict] = {}
    edges: list[dict] = []
    edge_keys: set[tuple] = set()

    def nid(kind: str, artifact: str = "", label: str = "", rva=None) -> str:
        # Native dynamic/exported function names are unique enough inside one ELF
        # and often appear first without an RVA (JNI surface) and later with one
        # (direct-call/xref evidence). Keep one node and enrich it with the RVA.
        rva_part = "" if (rva is None or kind == "native-function") else f"{int(rva):x}"
        raw = f"{kind}|{artifact}|{label}|{rva_part}".encode("utf-8", "replace")
        return f"{kind}." + hashlib.sha1(raw).hexdigest()[:14]

    def add_node(kind: str, artifact: str = "", label: str = "", rva=None, **extra) -> str:
        node_id = nid(kind, artifact, label, rva)
        row = {"id": node_id, "type": kind, "artifact": artifact, "label": label or artifact}
        if isinstance(rva, int):
            row["rva"] = rva
        for k, v in extra.items():
            if v is not None and v != "":
                row[k] = v
        existing = nodes.get(node_id)
        if existing:
            for k, v in row.items():
                existing.setdefault(k, v)
        else:
            nodes[node_id] = row
        return node_id

    def add_edge(src: str, dst: str, kind: str, confidence: float, *, evidence_class: str,
                 rationale: str = "", structural: bool = False, **extra):
        key = (src, dst, kind, evidence_class)
        if src == dst or key in edge_keys:
            return
        edge_keys.add(key)
        row = {
            "from": src, "to": dst, "kind": kind,
            "confidence": round(float(confidence), 2),
            "evidenceClass": evidence_class,
            "structural": bool(structural),
        }
        if rationale:
            row["rationale"] = rationale
        for k, v in extra.items():
            if v is not None and v != "":
                row[k] = v
        edges.append(row)

    so_nodes: dict[str, str] = {}
    dex_nodes: dict[str, str] = {}

    def so_node(name: str) -> str:
        name = str(name or "")
        if name not in so_nodes:
            so_nodes[name] = add_node("native-library", name, Path(name).name)
        return so_nodes[name]

    def dex_node(name: str) -> str:
        name = str(name or "")
        if name not in dex_nodes:
            dex_nodes[name] = add_node("dex", name, Path(name).name)
        return dex_nodes[name]

    # DEX -> packaged native loader relation.
    for x in relations.get("dexNativeLinks", []) or []:
        d = dex_node(str(x.get("from", "")))
        s = so_node(str(x.get("to", "")))
        add_edge(d, s, "loads-library", float(x.get("confidence", 0.6)),
                 evidence_class="dex-library-name",
                 rationale=str(x.get("rationale", "")),
                 library=x.get("library"), loadLibraryMarker=bool(x.get("loadLibraryMarker")),
                 jniOnLoad=bool(x.get("jniOnLoad")))

    # Library-to-library static relations.  Keep DT_NEEDED distinct from weaker
    # embedded string evidence.
    for key, kind, conf, evc in (
        ("dependencyEdges", "depends-on", 0.99, "DT_NEEDED"),
        ("embeddedLibraryStringEdges", "references-library", 0.68, "embedded-library-string"),
    ):
        for x in relations.get(key, []) or []:
            src = so_node(str(x.get("from", "")))
            dst = so_node(str(x.get("to", "")))
            add_edge(src, dst, kind, conf, evidence_class=evc, rationale=str(x.get("rationale", "")), value=x.get("value"))

    # JNI entrypoints and direct native calls inside the same ELF.
    for x in relations.get("jniSurfaces", []) or []:
        art = str(x.get("artifact", ""))
        if not art:
            continue
        lib = so_node(art)
        for name in x.get("exports", []) or []:
            if name != "JNI_OnLoad" and not str(name).startswith("Java_"):
                continue
            fn = add_node("native-function", art, str(name))
            add_edge(lib, fn, "exports-jni-entry", 0.99, evidence_class="ELF-export", structural=True)
    for x in relations.get("jniDirectCallRefs", []) or []:
        art = str(x.get("artifact", ""))
        src_label = str(x.get("sourceFunction") or f"sub_{int(x.get('sourceRva') or x.get('callRva') or 0):x}")
        dst_label = str(x.get("targetFunction") or f"sub_{int(x.get('targetRva') or 0):x}")
        src = add_node("native-function", art, src_label, x.get("sourceRva"))
        dst = add_node("native-function", art, dst_label, x.get("targetRva"))
        add_edge(src, dst, "direct-call", 0.98, evidence_class="arm64-direct-bl",
                 callRva=x.get("callRva"), rationale="ARM64 BL resolves directly to the target RVA.")

    # Exact import/export linkage is linker evidence.  A caller function is not
    # known, so source is the importing ELF rather than an invented function.
    for x in relations.get("symbolEdges", []) or []:
        src = so_node(str(x.get("from", "")))
        target_art = str(x.get("to", ""))
        symbol = str(x.get("symbol", ""))
        dst = add_node("native-function", target_art, symbol, x.get("targetRva"))
        add_edge(src, dst, "imports-export", float(x.get("confidence", 0.96)),
                 evidence_class="ELF-import-export", rationale=str(x.get("rationale", "")), structural=True)

    # dlsym correlation can sometimes be function-scoped through ADRP+ADD xrefs.
    for x in relations.get("dynamicSymbolEdges", []) or []:
        target_art = str(x.get("to", ""))
        symbol = str(x.get("symbol", ""))
        dst = add_node("native-function", target_art, symbol, x.get("targetRva"))
        xrefs = x.get("staticStringXrefs") or []
        if xrefs:
            for xr in xrefs[:12]:
                host = str(x.get("from", ""))
                label = str(xr.get("sourceFunction") or f"sub_{int(xr.get('xrefRva') or 0):x}")
                src = add_node("native-function", host, label, xr.get("sourceRva"))
                add_edge(src, dst, "dynamic-symbol-candidate", float(x.get("confidence", 0.88)),
                         evidence_class="dlsym-string-address-xref",
                         rationale=str(x.get("rationale", "")), stringRva=x.get("stringRva"), xrefRva=xr.get("xrefRva"))
        else:
            src = so_node(str(x.get("from", "")))
            add_edge(src, dst, "dynamic-symbol-candidate", float(x.get("confidence", 0.78)),
                     evidence_class="dlsym-string-export", rationale=str(x.get("rationale", "")), structural=True)

    # Address-bearing IL2CPP method graph.  Source attribution remains explicit
    # about whether the managed interval is unique or ambiguous.
    managed_by_rva: dict[int, list[str]] = defaultdict(list)
    for ref in relations.get("il2cppDirectCallRefs", []) or []:
        art = str(ref.get("artifact", "libil2cpp.so"))
        target_rva = ref.get("targetRva")
        targets = ref.get("targetMethods") or []
        if not targets:
            targets = [{"label": f"IL2CPP RVA 0x{int(target_rva or 0):x}"}]
        target_ids = []
        for m in targets[:8]:
            label = str(m.get("label") or f"IL2CPP RVA 0x{int(target_rva or 0):x}")
            mid = add_node("managed-method", art, label, target_rva,
                           image=m.get("image"), signature=m.get("signature"))
            target_ids.append(mid)
            if isinstance(target_rva, int):
                managed_by_rva[target_rva].append(mid)
        sources = ref.get("sourceMethodCandidates") or []
        if sources:
            for m in sources[:8]:
                src_rva = m.get("rva")
                src = add_node("managed-method", art, str(m.get("label") or "managed source"), src_rva,
                               image=m.get("image"), signature=m.get("signature"),
                               attribution=ref.get("sourceAttribution"))
                for dst in target_ids:
                    add_edge(src, dst, "managed-direct-call", float(ref.get("confidence", 0.96)),
                             evidence_class="arm64-direct-bl+rodroid-interval",
                             rationale=str(ref.get("rationale", "")), callRva=ref.get("callRva"),
                             attribution=ref.get("sourceAttribution"))
        else:
            src_label = str(ref.get("sourceFunction") or f"sub_{int(ref.get('callRva') or 0):x}")
            src = add_node("native-function", art, src_label, ref.get("sourceRva"))
            for dst in target_ids:
                add_edge(src, dst, "direct-call-to-managed-rva", float(ref.get("confidence", 0.96)),
                         evidence_class="arm64-direct-bl", rationale=str(ref.get("rationale", "")), callRva=ref.get("callRva"))

    # Link reviewable controls to the exact address-bearing evidence that created
    # them.  This is an evidence edge, not execution proof.
    control_nodes = []
    for c in controls[:400]:
        cid = add_node("control-candidate", str(c.get("source", "")), str(c.get("title") or c.get("id") or "control"),
                       c.get("evidenceRva"), candidateId=c.get("id"), status=c.get("status"),
                       confidence=c.get("confidence"), suggestedType=c.get("suggestedType"), binding=c.get("binding"))
        control_nodes.append(cid)
        rva = c.get("evidenceRva")
        linked = False
        if isinstance(rva, int):
            for mid in managed_by_rva.get(rva, [])[:8]:
                add_edge(mid, cid, "evidence-for-control", float(c.get("confidence", 0.6)),
                         evidence_class="candidate-provenance", structural=True)
                linked = True
            if not linked and str(c.get("source", "")).replace("\\", "/").endswith(".so"):
                src = add_node("native-function", str(c.get("source", "")), str(c.get("value") or c.get("title") or "native evidence"), rva)
                add_edge(src, cid, "evidence-for-control", float(c.get("confidence", 0.6)),
                         evidence_class="candidate-provenance", structural=True)
        if not linked and str(c.get("source", "")).lower().endswith(".dex"):
            add_edge(dex_node(str(c.get("source", ""))), cid, "evidence-for-control", float(c.get("confidence", 0.5)),
                     evidence_class="candidate-provenance", structural=True)

    # Directed reachability.  Only actual directed edges are traversed; there is
    # no synthetic bridge between disconnected components.
    adjacency: dict[str, list[tuple[int, dict]]] = defaultdict(list)
    reverse: dict[str, list[tuple[int, dict]]] = defaultdict(list)
    for edge_index, e in enumerate(edges):
        adjacency[e["from"]].append((edge_index, e))
        reverse[e["to"]].append((edge_index, e))

    roots = [n for n in nodes.values() if n["type"] == "dex" and adjacency.get(n["id"])]
    control_set = {n["id"] for n in nodes.values() if n["type"] == "control-candidate"}
    complete = []
    partial = []
    reached_controls = set()

    for root in roots[:32]:
        queue = [(root["id"], [root["id"]], [])]
        seen_depth: dict[str, int] = {root["id"]: 0}
        emitted_partial = 0
        while queue and len(complete) < max_chains:
            current, path_nodes, path_edges = queue.pop(0)
            if current in control_set and len(path_nodes) > 1:
                reached_controls.add(current)
                complete.append({"root": root["id"], "target": current, "nodes": path_nodes, "edges": path_edges,
                                 "confidence": round(min((float(edges[i]["confidence"]) for i in path_edges), default=0.0), 2)})
                continue
            if len(path_edges) >= 8:
                continue
            outs = adjacency.get(current, [])[:32]
            if not outs and len(path_edges) >= 2 and emitted_partial < 6:
                partial.append({"root": root["id"], "leaf": current, "nodes": path_nodes, "edges": path_edges,
                                "reason": "static-evidence-chain-ends-here"})
                emitted_partial += 1
            for edge_index, e in outs:
                nxt = e["to"]
                if nxt in path_nodes:
                    continue
                depth = len(path_edges) + 1
                if seen_depth.get(nxt, 99) < depth:
                    continue
                seen_depth[nxt] = depth
                queue.append((nxt, path_nodes + [nxt], path_edges + [edge_index]))

    # Unlinked controls are useful diagnostics: they tell the analyst exactly
    # where a requested end-to-end chain still has a missing static hop.
    unlinked_controls = sorted(control_set - reached_controls)
    gaps = []
    if roots and unlinked_controls:
        for cid in unlinked_controls[:80]:
            c = nodes[cid]
            incoming = reverse.get(cid, [])
            gaps.append({
                "control": cid,
                "label": c.get("label"),
                "reason": "no-directed-static-path-from-dex-loader",
                "nearestEvidence": [e["from"] for _idx, e in incoming[:4]],
            })

    graph = {
        "schema": "modkit-static-relationship-graph-1.0",
        "nodes": list(nodes.values())[:3000],
        "edges": edges[:6000],
        "completeChains": complete[:max_chains],
        "partialLoaderChains": partial[:max_chains],
        "gaps": gaps,
        "summary": {
            "nodes": len(nodes), "edges": len(edges), "dexRoots": len(roots),
            "controls": len(control_set), "completeChains": len(complete),
            "controlsReachedFromDex": len(reached_controls), "unlinkedControls": len(unlinked_controls),
        },
        "semantics": "Static evidence graph only; structural and correlation edges are labeled and must not be read as runtime execution traces.",
    }
    report["relationshipGraph"] = graph
    return graph

def augment_structured_findings(report: dict) -> dict:
    """Add high-signal findings from address-bearing Rodroid calling contracts.

    This confirms the presence of a structured developer/debug API surface, not
    that any specific behavior has been exercised at runtime.
    """
    from modkit.reworkspace.signature import rodroid_signature_contract

    il2cpp = report.get("il2cpp") or {}
    rows = []
    for key in ("metadata_resolved_methods", "discoveries", "candidates"):
        rows.extend(il2cpp.get(key, []) or [])
    evidence = []
    seen = set()
    for row in rows:
        label = str(row.get("label", ""))
        low = label.casefold()
        rva = row.get("rva")
        if not isinstance(rva, int) or rva <= 0:
            continue
        if not any(x in low for x in (".cheat.", "cheatgamehandler", "cheat_", "debug", "console", "noclip", "invic")):
            continue
        contract = row.get("signature_contract") or {}
        signature = str(contract.get("signature") or row.get("signature") or "")
        verified = rodroid_signature_contract(signature) if signature else contract
        if not verified.get("autoBindingSafe") or not verified.get("bindingSuggestion"):
            continue
        key = (label, rva)
        if key in seen:
            continue
        seen.add(key)
        evidence.append({
            "artifact": str(row.get("image") or "Rodroid"),
            "kind": "rodroid-call-contract",
            "value": label[:240],
            "location": f"RVA 0x{rva:x}",
            "signatureContract": verified,
        })
        if len(evidence) >= 40:
            break

    if len(evidence) < 2:
        return report

    unity_evidence = []
    for bundle in (report.get("unity") or {}).get("bundles", []) or []:
        source = str(bundle.get("apk_entry") or bundle.get("sha256") or "UnityFS bundle")
        for value in bundle.get("matched_strings", []) or []:
            text = str(value)
            if any(x in text.casefold() for x in ("cheat", "debug", "console", "noclip", "invic")):
                unity_evidence.append({
                    "artifact": source, "kind": "unity-control-marker", "value": text[:240], "location": ""
                })
                if len(unity_evidence) >= 12:
                    break
        if len(unity_evidence) >= 12:
            break

    finding = {
        "id": "re.structured_developer_control_api",
        "title": "Structured developer cheat/debug control API",
        "category": "developer_control_api",
        "status": "confirmed",
        "confidence": 0.98 if unity_evidence else 0.95,
        "evidence": evidence + unity_evidence,
        "rationale": (
            f"{len(evidence)} unique address-bearing Rodroid methods have conservative callable signatures"
            + (" and Unity assets independently expose cheat/debug control markers." if unity_evidence
               else ". This confirms an addressable developer/debug API surface; runtime behavior is not claimed until exercised.")
        ),
    }
    findings = report.setdefault("findings", [])
    findings[:] = [f for f in findings if f.get("id") != finding["id"]]
    findings.append(finding)
    findings.sort(key=lambda f: (-float(f.get("confidence", 0.0)), str(f.get("id", ""))))
    return report
