package dev.modkit.mobile;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

public class ReWorkspaceActivity extends Activity {
    private App app;
    private LinearLayout root, findings;
    private TextView status, summary;
    private Button run, menu;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private long revision = -1;
    private final Runnable poll = new Runnable(){ public void run(){ refresh(); handler.postDelayed(this,400); }};
    private int dp(int n){ return (int)(n*getResources().getDisplayMetrics().density); }
    private TextView text(String s,int size){ TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(Color.rgb(25,40,62));t.setPadding(0,dp(6),0,dp(6));t.setTextIsSelectable(true);return t; }
    private Button button(String s,View.OnClickListener l){ Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setOnClickListener(l);root.addView(b);return b; }
    @Override public void onCreate(Bundle state){
        super.onCreate(state); app=(App)getApplication();
        ScrollView scroll=new ScrollView(this);root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(18),dp(20),dp(18),dp(24));scroll.addView(root);setContentView(scroll);
        TextView title=text("RE Workspace",28);title.setTypeface(null,Typeface.BOLD);root.addView(title);
        root.addView(text("DEX + global-metadata + Rodroid dump + все ELF/.so + Unity/Addressables. Находки получают provenance и статус candidate / correlated / confirmed.",14));
        run=button("Полный RE-анализ выбранного APK",v->startWork(new Intent().putExtra("op","re_analyze")));
        menu=button("Создать Menu Builder из подтверждённых находок",v->{
            if(!app.file("re-analysis.json").isFile()){toast("Сначала выполните RE-анализ");return;}
            startWork(new Intent().putExtra("op","menu_seed"));
        });
        button("Открыть Menu Builder",v->startActivity(new Intent(this,MenuBuilderActivity.class)));
        status=text("",14);root.addView(status);summary=text("",14);root.addView(summary);
        findings=new LinearLayout(this);findings.setOrientation(LinearLayout.VERTICAL);root.addView(findings);
    }
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    private void startWork(Intent i){
        if(app.busy.get()){toast("Сейчас выполняется другая операция");return;}
        if(!app.file("game.apk").isFile() && "re_analyze".equals(i.getStringExtra("op"))){toast("Сначала выберите исходный APK на главном экране");return;}
        app.cancelled.set(false);app.busy.set(true);app.progress("Подготовка…");i.setClass(this,WorkerService.class);startForegroundService(i);
    }
    private JSONObject read(String name){try{return new JSONObject(Files.readString(app.file(name).toPath(),StandardCharsets.UTF_8));}catch(Exception e){return null;}}
    private void refresh(){
        if(revision==app.revision)return;revision=app.revision;status.setText(app.status);
        run.setEnabled(!app.busy.get()&&app.file("game.apk").isFile());menu.setEnabled(!app.busy.get()&&app.file("re-analysis.json").isFile());
        JSONObject report=read("re-analysis.json");findings.removeAllViews();
        if(report==null){summary.setText("Отчёта пока нет. RE-анализ использует выбранный APK и, если доступны, текущие metadata/libil2cpp/Rodroid dump.");return;}
        JSONObject inv=report.optJSONObject("inventory");JSONArray arr=report.optJSONArray("findings"),candidates=report.optJSONArray("controlCandidates");
        int dex=0,nativeCount=0;if(inv!=null){JSONArray d=inv.optJSONArray("dex"),n=inv.optJSONArray("native");dex=d==null?0:d.length();nativeCount=n==null?0:n.length();}
        JSONObject relations=report.optJSONObject("nativeRelations"),graph=report.optJSONObject("relationshipGraph");int depEdges=0,dexLinks=0,stringLinks=0,symbolLinks=0,dynamicSymbols=0,jni=0,jniRefs=0,il2cppRefs=0,dyn=0,render=0;if(relations!=null){JSONArray de=relations.optJSONArray("dependencyEdges"),dx=relations.optJSONArray("dexNativeLinks"),sl=relations.optJSONArray("embeddedLibraryStringEdges"),sy=relations.optJSONArray("symbolEdges"),ds=relations.optJSONArray("dynamicSymbolEdges"),js=relations.optJSONArray("jniSurfaces"),jr=relations.optJSONArray("jniDirectCallRefs"),ir=relations.optJSONArray("il2cppDirectCallRefs"),dl=relations.optJSONArray("dynamicLoadingSurfaces"),rs=relations.optJSONArray("renderInputSurfaces");depEdges=de==null?0:de.length();dexLinks=dx==null?0:dx.length();stringLinks=sl==null?0:sl.length();symbolLinks=sy==null?0:sy.length();dynamicSymbols=ds==null?0:ds.length();jni=js==null?0:js.length();jniRefs=jr==null?0:jr.length();il2cppRefs=ir==null?0:ir.length();dyn=dl==null?0:dl.length();render=rs==null?0:rs.length();}
        JSONObject gs=graph==null?null:graph.optJSONObject("summary");int graphChains=gs==null?0:gs.optInt("completeChains"),graphGaps=gs==null?0:gs.optInt("unlinkedControls"),graphNodes=gs==null?0:gs.optInt("nodes"),graphEdges=gs==null?0:gs.optInt("edges");
        summary.setText("DEX: "+dex+" · native: "+nativeCount+" · DEX→SO: "+dexLinks+" · SO→SO refs: "+stringLinks+" · symbols: "+symbolLinks+"/"+dynamicSymbols+" · DT_NEEDED: "+depEdges+" · JNI: "+jni+" · JNI refs: "+jniRefs+" · IL2CPP xrefs: "+il2cppRefs+" · graph: "+graphNodes+"n/"+graphEdges+"e · chains: "+graphChains+" · gaps: "+graphGaps+" · dlopen/dlsym: "+dyn+" · render/input: "+render+" · находок: "+(arr==null?0:arr.length())+" · control candidates: "+(candidates==null?0:candidates.length()));
        if(graph!=null){
            JSONArray nodes=graph.optJSONArray("nodes"),edges=graph.optJSONArray("edges"),chains=graph.optJSONArray("completeChains"),partials=graph.optJSONArray("partialLoaderChains"),gaps=graph.optJSONArray("gaps");
            java.util.HashMap<String,JSONObject> nodeById=new java.util.HashMap<>();if(nodes!=null)for(int i=0;i<nodes.length();i++){JSONObject n=nodes.optJSONObject(i);if(n!=null)nodeById.put(n.optString("id"),n);}
            StringBuilder gb=new StringBuilder();
            if(chains!=null)for(int i=0;i<Math.min(8,chains.length());i++){JSONObject c=chains.optJSONObject(i);if(c==null)continue;JSONArray ns=c.optJSONArray("nodes");gb.append("CHAIN · ");if(ns!=null)for(int j=0;j<ns.length();j++){JSONObject n=nodeById.get(ns.optString(j));if(j>0)gb.append(" → ");gb.append(n==null?ns.optString(j):n.optString("label"));}gb.append(" · confidence ").append(String.format(java.util.Locale.ROOT,"%.2f",c.optDouble("confidence"))).append("\n");}
            if(partials!=null)for(int i=0;i<Math.min(8,partials.length());i++){JSONObject c=partials.optJSONObject(i);if(c==null)continue;JSONArray ns=c.optJSONArray("nodes");gb.append("PARTIAL · ");if(ns!=null)for(int j=0;j<ns.length();j++){JSONObject n=nodeById.get(ns.optString(j));if(j>0)gb.append(" → ");gb.append(n==null?ns.optString(j):n.optString("label"));}gb.append(" · static chain ends here\n");}
            if(gaps!=null)for(int i=0;i<Math.min(8,gaps.length());i++){JSONObject g=gaps.optJSONObject(i);if(g!=null)gb.append("GAP · ").append(g.optString("label")).append(" · ").append(g.optString("reason")).append("\n");}
            if(gb.length()>0){LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(10),dp(8),dp(10),dp(12));TextView h=text("Static relationship graph",17);h.setTypeface(null,Typeface.BOLD);card.addView(h);card.addView(text(gb.toString().trim(),12));findings.addView(card);}
        }
        if(relations!=null){
            StringBuilder links=new StringBuilder();
            JSONArray dx=relations.optJSONArray("dexNativeLinks");if(dx!=null)for(int i=0;i<Math.min(8,dx.length());i++){JSONObject x=dx.optJSONObject(i);if(x!=null)links.append("DEX→SO · ").append(x.optString("from")).append(" → ").append(x.optString("to")).append(" · ").append(x.optString("library")).append(" · confidence ").append(String.format(java.util.Locale.ROOT,"%.2f",x.optDouble("confidence"))).append("\n");}
            JSONArray sl=relations.optJSONArray("embeddedLibraryStringEdges");if(sl!=null)for(int i=0;i<Math.min(6,sl.length());i++){JSONObject x=sl.optJSONObject(i);if(x!=null)links.append("SO→SO · ").append(x.optString("from")).append(" → ").append(x.optString("to")).append(" · ").append(x.optString("value")).append("\n");}
            JSONArray sy=relations.optJSONArray("symbolEdges");if(sy!=null)for(int i=0;i<Math.min(6,sy.length());i++){JSONObject x=sy.optJSONObject(i);if(x!=null)links.append("IMPORT→EXPORT · ").append(x.optString("from")).append(" → ").append(x.optString("to")).append(" · ").append(x.optString("symbol")).append("\n");}
            JSONArray ds=relations.optJSONArray("dynamicSymbolEdges");if(ds!=null)for(int i=0;i<Math.min(6,ds.length());i++){JSONObject x=ds.optJSONObject(i);if(x!=null){links.append("DLSYM · ").append(x.optString("from")).append(" → ").append(x.optString("to")).append(" · ").append(x.optString("symbol"));JSONArray xs=x.optJSONArray("staticStringXrefs");if(xs!=null&&xs.length()>0){JSONObject xr=xs.optJSONObject(0);if(xr!=null)links.append(" · ").append(xr.optString("sourceFunction","sub_"+Long.toHexString(xr.optLong("xrefRva"))));}links.append("\n");}}
            JSONArray jr=relations.optJSONArray("jniDirectCallRefs");if(jr!=null)for(int i=0;i<Math.min(6,jr.length());i++){JSONObject x=jr.optJSONObject(i);if(x!=null)links.append("JNI BL · ").append(x.optString("sourceFunction")).append(" → ").append(x.optString("targetFunction")).append(" @ 0x").append(Long.toHexString(x.optLong("callRva"))).append("\n");}
            JSONArray ir=relations.optJSONArray("il2cppDirectCallRefs");if(ir!=null)for(int i=0;i<Math.min(8,ir.length());i++){JSONObject x=ir.optJSONObject(i);if(x!=null){String src=x.optString("sourceFunction");JSONArray sm=x.optJSONArray("sourceMethodCandidates");if(sm!=null&&sm.length()>0){JSONObject m=sm.optJSONObject(0);if(m!=null)src=m.optString("label",src);}String target="IL2CPP RVA 0x"+Long.toHexString(x.optLong("targetRva"));JSONArray tm=x.optJSONArray("targetMethods");if(tm!=null&&tm.length()>0){JSONObject m=tm.optJSONObject(0);if(m!=null)target=m.optString("label",target);}links.append("IL2CPP BL · ").append(src.isEmpty()?"sub_"+Long.toHexString(x.optLong("callRva")):src).append(" → ").append(target).append("\n");}}
            if(links.length()>0){LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(10),dp(8),dp(10),dp(12));TextView h=text("Native / JNI / IL2CPP relationships",17);h.setTypeface(null,Typeface.BOLD);card.addView(h);card.addView(text(links.toString().trim(),12));findings.addView(card);}
        }
        if(arr==null)return;
        for(int i=0;i<arr.length();i++){
            JSONObject f=arr.optJSONObject(i);if(f==null)continue;
            LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(10),dp(8),dp(10),dp(12));
            TextView h=text(f.optString("title"),17);h.setTypeface(null,Typeface.BOLD);card.addView(h);
            card.addView(text(f.optString("status").toUpperCase()+" · confidence "+String.format(java.util.Locale.ROOT,"%.2f",f.optDouble("confidence"))+"\n"+f.optString("rationale"),12));
            JSONArray ev=f.optJSONArray("evidence");StringBuilder b=new StringBuilder();
            if(ev!=null)for(int j=0;j<Math.min(12,ev.length());j++){JSONObject e=ev.optJSONObject(j);if(e!=null)b.append("• ").append(e.optString("artifact")).append(" · ").append(e.optString("kind")).append(" · ").append(e.optString("value")).append(" ").append(e.optString("location")).append("\n");}
            if(b.length()>0)card.addView(text(b.toString().trim(),12));findings.addView(card);
        }
    }
    @Override protected void onResume(){super.onResume();handler.post(poll);}
    @Override protected void onPause(){handler.removeCallbacks(poll);super.onPause();}
}
