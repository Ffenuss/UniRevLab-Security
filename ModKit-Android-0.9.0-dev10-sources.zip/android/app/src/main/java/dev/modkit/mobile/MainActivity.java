package dev.modkit.mobile;

import android.app.*;
import android.content.*;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.*;
import android.provider.OpenableColumns;
import android.text.*;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.util.*;

public class MainActivity extends Activity {
    private App app;
    private LinearLayout root,list;
    private TextView status,files,summary,pageLabel;
    private Button metadata,library,game,analyze,export,dumpExport,buildGame,report,cancel,prev,next;
    private EditText search;
    private ProgressBar progress;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private long revision=-1;
    private JSONObject shown;
    private final Map<Integer,String> selected=new LinkedHashMap<>();
    private int page=0;
    private final Runnable poll=new Runnable() { public void run() { refresh(); handler.postDelayed(this,350); } };
    private int dp(int n) { return (int)(n*getResources().getDisplayMetrics().density); }
    private TextView text(String s,int size) {
        TextView t=new TextView(this); t.setText(s);t.setTextSize(size);t.setTextColor(Color.rgb(25,40,62));
        t.setPadding(0,dp(6),0,dp(6)); return t;
    }
    private Button button(String s,LinearLayout target,View.OnClickListener action) {
        Button b=new Button(this);b.setText(s);b.setAllCaps(false);target.addView(b);b.setOnClickListener(action);return b;
    }
    @Override public void onCreate(Bundle state) {
        super.onCreate(state); app=(App)getApplication();
        ScrollView scroll=new ScrollView(this);root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(20),dp(24),dp(20),dp(24));
        root.setBackgroundColor(Color.rgb(244,247,251));scroll.addView(root);setContentView(scroll);
        TextView title=text("ModKit",30);title.setTypeface(null,Typeface.BOLD);root.addView(title);
        root.addView(text("Изменение IL2CPP-библиотеки на телефоне",16));
        button("Как это работает",root,v->new AlertDialog.Builder(this).setTitle("От файлов до результата")
            .setMessage("1. Выберите global-metadata.dat и libil2cpp.so из одной сборки. Для готовой игры также выберите исходный APK.\n2. Rodroid Il2CppDumper V7 создаст полный dump.cs и script.json.\n3. Найдите метод, включите его и укажите возвращаемое значение.\n4. Сохраните ZIP либо соберите готовый APK игры.\n\nВыбранный метод будет возвращать константу: исходное тело и его побочные действия выполняться не будут. Изменения нужно проверить в разрешённой тестовой копии.\n\nСобранный APK получает тестовую подпись ModKit, поэтому устанавливается отдельно от официально подписанной версии. Обработка локальная; компьютер и интернет не нужны.")
            .setPositiveButton("Понятно",null).show());
        root.addView(text("Рабочие пространства",20));
        button("RE Workspace · DEX / Unity / IL2CPP / все .so",root,v->startActivity(new Intent(this,ReWorkspaceActivity.class)));
        button("Native / SO Editor · ELF / HEX / ARM64",root,v->startActivity(new Intent(this,NativeWorkspaceActivity.class)));
        button("Patch Pack · classes*.dex + .so",root,v->startActivity(new Intent(this,PatchPackActivity.class)));
        button("Menu Builder",root,v->startActivity(new Intent(this,MenuBuilderActivity.class)));
        root.addView(text("1 · Исходные файлы",20));
        files=text("",14);root.addView(files);
        metadata=button("Выбрать global-metadata.dat",root,v->pick(10));
        library=button("Выбрать libil2cpp.so (ARM64)",root,v->pick(11));
        game=button("Выбрать исходный APK игры",root,v->pickApk());
        root.addView(text("2 · Анализ",20));
        analyze=button("Анализировать файлы",root,v->start(new Intent().putExtra("op","analyze")));
        progress=new ProgressBar(this);progress.setIndeterminate(true);root.addView(progress);
        status=text("",15);status.setTextIsSelectable(true);root.addView(status);
        cancel=button("Отменить операцию",root,v->{app.cancelled.set(true);app.progress("Отмена…");});
        summary=text("",14);root.addView(summary);
        report=button("Сохранить отчёт анализа",root,v->startActivityForResult(new Intent(Intent.ACTION_CREATE_DOCUMENT).setType("application/json").addCategory(Intent.CATEGORY_OPENABLE).putExtra(Intent.EXTRA_TITLE,"modkit-analysis.json"),21));
        dumpExport=button("Сохранить полный дамп Rodroid (ZIP)",root,v->startActivityForResult(new Intent(Intent.ACTION_CREATE_DOCUMENT).setType("application/zip").addCategory(Intent.CATEGORY_OPENABLE).putExtra(Intent.EXTRA_TITLE,"rodroid-full-dump.zip"),23));
        root.addView(text("3 · Изменения",20));
        search=new EditText(this);search.setSingleLine(true);search.setHint("Поиск: Health, Damage, Gold…");root.addView(search);
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int c,int f){} public void onTextChanged(CharSequence s,int a,int before,int count){page=0;renderRows();} public void afterTextChanged(Editable e){}});
        list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);root.addView(list);
        LinearLayout pages=new LinearLayout(this);pages.setGravity(Gravity.CENTER_VERTICAL);root.addView(pages);
        prev=button("Назад",pages,v->{page=Math.max(0,page-1);renderRows();});
        pageLabel=text("",14);pages.addView(pageLabel);
        next=button("Далее",pages,v->{page++;renderRows();});
        root.addView(text("4 · Результат",20));
        export=button("Сохранить мод (ZIP)",root,v->prepareExport());
        buildGame=button("Собрать игру (APK)",root,v->prepareGameBuild());
        root.addView(text("Для APK нужно выбрать исходный APK игры в разделе 1. Без него доступен только ZIP с изменённой библиотекой.",13));
        root.addView(text("В ZIP: libil2cpp.so, изменения и отчёт. Исходные файлы остаются нетронутыми.",13));
        if (Build.VERSION.SDK_INT>=33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=android.content.pm.PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},50);
    }
    private void pick(int code) {
        startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE),code);
    }
    private void pickApk() {startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("application/vnd.android.package-archive").addCategory(Intent.CATEGORY_OPENABLE),12);}
    private void start(Intent intent) {
        synchronized(app) {
            if(!app.busy.compareAndSet(false,true)) return;
            app.cancelled.set(false);app.progress("Подготовка…");
        }
        intent.setClass(this,WorkerService.class);
        try { startForegroundService(intent); }
        catch(Exception e) {app.busy.set(false);app.progress("Не удалось начать: "+e.getMessage());}
        refresh();
    }
    @Override protected void onActivityResult(int request,int result,Intent data) {
        super.onActivityResult(request,result,data);
        if(result!=RESULT_OK || data==null || data.getData()==null) return;
        Uri uri=data.getData();
        if(request==10 || request==11 || request==12) {
            String display=uri.getLastPathSegment();
            try(Cursor c=getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)) {
                if(c!=null && c.moveToFirst())display=c.getString(0);
            }catch(Exception ignored){}
            String local=request==10?"metadata.bin":request==11?"library.so":"game.apk";
            start(new Intent().putExtra("op","import").putExtra("uri",uri.toString()).putExtra("name",local).putExtra("display",display));
        } else if(request==21) {
            start(new Intent().putExtra("op","report").putExtra("uri",uri.toString()));
        } else if(request==20) {
            start(new Intent().putExtra("op","export").putExtra("uri",uri.toString()).putExtra("selections",selections().toString()));
        } else if(request==22) {
            start(new Intent().putExtra("op","build_apk").putExtra("uri",uri.toString()).putExtra("selections",selections().toString()));
        } else if(request==23) {
            start(new Intent().putExtra("op","dump").putExtra("uri",uri.toString()));
        }
    }
    private JSONArray selections() {
        JSONArray a=new JSONArray();
        for(Map.Entry<Integer,String> e:selected.entrySet())try {a.put(new JSONObject().put("id",e.getKey()).put("value",e.getValue()));}catch(JSONException ignored){}
        return a;
    }
    private void saveSelections() {export.setText("Сохранить мод (ZIP) · "+selected.size());getSharedPreferences("state",0).edit().putString("selections",selections().toString()).apply();}
    private void prepareExport() {
        if(selected.isEmpty()) {new AlertDialog.Builder(this).setMessage("Выберите хотя бы один метод.").setPositiveButton("Понятно",null).show();return;}
        for(String value:selected.values())if(value.trim().isEmpty()){new AlertDialog.Builder(this).setMessage("Укажите значения для всех выбранных методов.").setPositiveButton("Понятно",null).show();return;}
        startActivityForResult(new Intent(Intent.ACTION_CREATE_DOCUMENT).setType("application/zip").addCategory(Intent.CATEGORY_OPENABLE).putExtra(Intent.EXTRA_TITLE,"modkit-result.zip"),20);
    }
    private boolean validateSelections() {
        if(selected.isEmpty()) {new AlertDialog.Builder(this).setMessage("Выберите хотя бы один метод.").setPositiveButton("Понятно",null).show();return false;}
        for(String value:selected.values())if(value.trim().isEmpty()){new AlertDialog.Builder(this).setMessage("Укажите значения для всех выбранных методов.").setPositiveButton("Понятно",null).show();return false;}
        return true;
    }
    private void prepareGameBuild() {
        if(!app.file("game.apk").exists()){new AlertDialog.Builder(this).setMessage("Сначала выберите исходный APK игры.").setPositiveButton("Понятно",null).show();return;}
        if(!validateSelections())return;
        startActivityForResult(new Intent(Intent.ACTION_CREATE_DOCUMENT).setType("application/vnd.android.package-archive").addCategory(Intent.CATEGORY_OPENABLE).putExtra(Intent.EXTRA_TITLE,"modkit-game-test.apk"),22);
    }
    private void refresh() {
        if(revision==app.revision)return;revision=app.revision;
        boolean busy=app.busy.get();status.setText(app.status);progress.setVisibility(busy?View.VISIBLE:View.GONE);cancel.setVisibility(busy?View.VISIBLE:View.GONE);
        metadata.setEnabled(!busy);library.setEnabled(!busy);game.setEnabled(!busy);analyze.setEnabled(!busy&&app.file("metadata.bin").exists()&&app.file("library.so").exists());export.setEnabled(!busy&&app.result!=null);dumpExport.setEnabled(!busy&&app.result!=null);buildGame.setEnabled(!busy&&app.result!=null);report.setEnabled(!busy&&app.result!=null);
        files.setText("Метаданные: "+getSharedPreferences("state",0).getString("metadata.bin","не выбраны")+"\nБиблиотека: "+getSharedPreferences("state",0).getString("library.so","не выбрана")+"\nAPK игры: "+getSharedPreferences("state",0).getString("game.apk","не выбран"));
        if(shown!=app.result) {
            shown=app.result;selected.clear();page=0;
            try {JSONArray s=new JSONArray(getSharedPreferences("state",0).getString("selections","[]"));for(int i=0;i<s.length();i++)selected.put(s.getJSONObject(i).getInt("id"),s.getJSONObject(i).getString("value"));}catch(Exception ignored){}
            renderRows();
        }
        if(shown==null)summary.setText("Дамп: Rodroid Il2CppDumper V7 · источник истины dump.cs/script.json.");
        else {
            JSONArray a=shown.optJSONArray("candidates");
            summary.setText("Метаданные v"+shown.optInt("metadata_version")+" · классов: "+shown.optInt("types")+"\nМетодов: "+shown.optInt("methods")+" · с адресами: "+shown.optInt("resolved")+"\nДоступно изменений: "+(a==null?0:a.length())+
                (a!=null&&a.length()==0?"\nПричины: "+reasons(shown.optJSONObject("unavailable")):"\nНаличие адреса не подтверждает правильность изменения в игре."));
        }
    }
    private String reasons(JSONObject obj) {
        if(obj==null)return "Нет данных";StringBuilder b=new StringBuilder();
        for(Iterator<String> it=obj.keys();it.hasNext();){String key=it.next();b.append("\n• ").append(key).append(": ").append(obj.optInt(key));}return b.toString();
    }
    private void renderRows() {
        if(list==null || next==null)return;
        export.setText("Сохранить мод (ZIP) · "+selected.size());
        list.removeAllViews();JSONArray all=shown==null?null:shown.optJSONArray("candidates"),found=shown==null?null:shown.optJSONArray("discoveries");List<JSONObject> matches=new ArrayList<>();
        String query=search.getText().toString().trim().toLowerCase(Locale.ROOT);
        addMatches(all,query,matches);addMatches(found,query,matches);
        int total=Math.max(1,(matches.size()+29)/30);page=Math.min(page,total-1);pageLabel.setText(" "+(page+1)+" / "+total+" ");prev.setEnabled(page>0);next.setEnabled(page+1<total);
        if(matches.isEmpty())list.addView(text(shown==null?"После анализа здесь появятся доступные методы.":"Нет доступных методов по этому запросу.",14));
        for(int i=page*30;i<Math.min(matches.size(),page*30+30);i++) {
            JSONObject o=matches.get(i);int id=o.optInt("id");
            LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(8),dp(8),dp(8),dp(12));list.addView(card);
            boolean selectable=o.optBoolean("selectable",true);
            CheckBox check=new CheckBox(this);check.setText(o.optString("label"));check.setChecked(selectable&&selected.containsKey(id));check.setEnabled(selectable);card.addView(check);
            String address=o.isNull("rva")||!o.has("rva")?"без RVA":"RVA 0x"+Long.toHexString(o.optLong("rva"));
            card.addView(text(o.optString("image")+" · "+o.optString("kind")+" · "+address+(o.optJSONArray("semantic")!=null?" · "+o.optJSONArray("semantic").toString():"")+(!selectable?"\nНайдено анализом: "+o.optString("unavailable_reason"):""),12));
            EditText input=new EditText(this);input.setSingleLine(true);input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER|android.text.InputType.TYPE_NUMBER_FLAG_SIGNED|android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);input.setHint(o.optString("kind").equals("bool")?"0 = нет, 1 = да":"Постоянное возвращаемое число");input.setText(selected.getOrDefault(id,"1"));input.setEnabled(check.isChecked());card.addView(input);
            check.setOnCheckedChangeListener((b,on)->{input.setEnabled(on);if(on)selected.put(id,input.getText().toString());else selected.remove(id);saveSelections();});
            input.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int c,int f){}public void onTextChanged(CharSequence s,int a,int b,int c){if(check.isChecked()){selected.put(id,s.toString());saveSelections();}}public void afterTextChanged(Editable e){}});
        }
    }
    private void addMatches(JSONArray source,String query,List<JSONObject> out) {
        if(source==null)return;
        for(int i=0;i<source.length();i++){
            JSONObject o=source.optJSONObject(i);if(o==null)continue;
            if(query.isEmpty()||wordMatch(query,o))out.add(o);
        }
    }
    private boolean wordMatch(String query,JSONObject o) {
        Set<String> words=words(o.optString("label")+" "+o.optString("image"));
        JSONArray tags=o.optJSONArray("semantic");if(tags!=null)for(int i=0;i<tags.length();i++)words.add(tags.optString(i).toLowerCase(Locale.ROOT));
        JSONObject aliases=shown==null?null:shown.optJSONObject("semantic_categories");
        if(aliases!=null){for(Iterator<String> it=aliases.keys();it.hasNext();){String category=it.next();JSONArray a=aliases.optJSONArray(category);if(category.equals(query)&&words.contains(category))return !isSystem(o,query);if(a!=null)for(int i=0;i<a.length();i++)if(query.equals(a.optString(i).toLowerCase(Locale.ROOT))&&words.contains(category))return !isSystem(o,query);}}
        for(String part:query.split("\\s+"))if(!words.contains(part))return false;
        return !isSystem(o,query);
    }
    private boolean isSystem(JSONObject o,String query){String image=o.optString("image").toLowerCase(Locale.ROOT);return !query.contains("system")&&(image.startsWith("system")||image.startsWith("mscorlib")||image.startsWith("unityengine"));}
    private Set<String> words(String value) {
        String split=value.replaceAll("([a-z0-9])([A-Z])","$1 $2").toLowerCase(Locale.ROOT);
        Set<String> result=new HashSet<>();for(String x:split.split("[^a-z0-9]+"))if(!x.isEmpty())result.add(x);return result;
    }
    @Override protected void onResume(){super.onResume();handler.post(poll);}
    @Override protected void onPause(){handler.removeCallbacks(poll);super.onPause();}
}
