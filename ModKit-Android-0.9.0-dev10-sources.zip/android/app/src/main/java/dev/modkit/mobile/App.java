package dev.modkit.mobile;

import android.app.Application;
import org.json.JSONObject;
import java.io.File;
import java.nio.file.Files;
import java.util.concurrent.atomic.AtomicBoolean;

public class App extends Application {
    public final AtomicBoolean busy = new AtomicBoolean(false), cancelled = new AtomicBoolean(false);
    public volatile String status = "Выберите два файла из одной сборки игры.";
    public volatile JSONObject result;
    public volatile long revision = 0;
    public File file(String name) { return new File(getFilesDir(), name); }
    public void progress(String message) { status = message; revision++; }
    @Override public void onCreate() {
        super.onCreate();
        if (getSharedPreferences("state",0).getBoolean("running",false)) {
            status = "Предыдущая операция прервана системой. Можно запустить её заново.";
            getSharedPreferences("state",0).edit().putBoolean("running",false).apply();
        }
        new Thread(() -> {
            synchronized (this) {
                if (busy.get()) return;
                try {
                    File f = file("analysis.summary.json");
                    if (f.exists()) result = new JSONObject(new String(Files.readAllBytes(f.toPath()), java.nio.charset.StandardCharsets.UTF_8));
                } catch (Exception ignored) { }
                revision++;
            }
        }, "restore").start();
    }
}
