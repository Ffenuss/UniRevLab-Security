package dev.modkit.mobile;

import com.android.apksig.ApkSigner;
import com.android.apksig.ApkVerifier;
import java.io.*;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.cert.X509Certificate;
import java.util.*;

final class ApkSignerUtil {
    static void sign(File unsignedApk, File outputApk, File keystore, char[] password) throws Exception {
        KeyStore store=KeyStore.getInstance("PKCS12");
        try(InputStream in=new FileInputStream(keystore)){store.load(in,password);}
        String alias=store.aliases().nextElement();
        KeyStore.PrivateKeyEntry entry=(KeyStore.PrivateKeyEntry)store.getEntry(alias,new KeyStore.PasswordProtection(password));
        List<X509Certificate> certs=new ArrayList<>();
        for(java.security.cert.Certificate c:entry.getCertificateChain()) certs.add((X509Certificate)c);
        ApkSigner.SignerConfig signer=new ApkSigner.SignerConfig.Builder("ModKit test",(PrivateKey)entry.getPrivateKey(),certs).build();
        new ApkSigner.Builder(Collections.singletonList(signer)).setInputApk(unsignedApk).setOutputApk(outputApk)
                .setV1SigningEnabled(true).setV2SigningEnabled(true).setV3SigningEnabled(false).build().sign();
        ApkVerifier.Result result=new ApkVerifier.Builder(outputApk).build().verify();
        if(!result.isVerified()) throw new IOException("Проверка подписи собранного APK не пройдена: "+result.getErrors());
    }
}
