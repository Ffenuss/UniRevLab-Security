package dev.modkit.mobile;

import android.app.*;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.provider.DocumentsContract;
import com.chaquo.python.*;
import com.chaquo.python.android.AndroidPlatform;
import org.json.JSONObject;
import org.json.JSONArray;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

public class WorkerService extends Service {
    private App app;
    private PowerManager.WakeLock wake;
    private volatile long lastNotification;
    public class Progress {
        public boolean isCancelled() { return app.cancelled.get(); }
        public void progress(String text) {
            app.progress(text);
            if (System.currentTimeMillis()-lastNotification > 1500) {
                lastNotification = System.currentTimeMillis();
                ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(1, notification(text));
            }
        }
    }
    private Notification notification(String text) {
        Intent stop = new Intent(this, WorkerService.class).setAction("cancel");
        PendingIntent cancel = PendingIntent.getService(this,2,stop,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        PendingIntent open = PendingIntent.getActivity(this,1,new Intent(this,MainActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = new Notification.Builder(this,"work");
        return b.setSmallIcon(dev.modkit.mobile.R.drawable.ic_modkit).setContentTitle("ModKit — обработка файлов")
            .setContentText(text).setContentIntent(open).setOngoing(true).addAction(0,"Отмена",cancel).build();
    }
    @Override public void onCreate() {
        super.onCreate(); app = (App)getApplication();
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE))
            .createNotificationChannel(new NotificationChannel("work","Обработка файлов",NotificationManager.IMPORTANCE_LOW));
    }
    @Override public int onStartCommand(Intent intent,int flags,int id) {
        if (intent == null) { stopSelf(); return START_NOT_STICKY; }
        if ("cancel".equals(intent.getAction())) {
            app.cancelled.set(true); app.progress("Отмена…");
            if (!app.busy.get()) stopSelf();
            return START_NOT_STICKY;
        }
        startForeground(1,notification(app.status));
        wake = ((PowerManager)getSystemService(POWER_SERVICE)).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"ModKit:work");
        wake.acquire(60*60*1000L);
        getSharedPreferences("state",0).edit().putBoolean("running",true).apply();
        new Thread(() -> {
            try {
                String op=intent.getStringExtra("op");
                if ("import".equals(op)) importFile(Uri.parse(intent.getStringExtra("uri")),intent.getStringExtra("name"),intent.getStringExtra("display"));
                else if ("analyze".equals(op)) analyze();
                else if ("report".equals(op)) reportFile(Uri.parse(intent.getStringExtra("uri")));
                else if ("export".equals(op)) exportFile(Uri.parse(intent.getStringExtra("uri")),intent.getStringExtra("selections"));
                else if ("build_apk".equals(op)) buildApk(Uri.parse(intent.getStringExtra("uri")),intent.getStringExtra("selections"));
                else if ("dump".equals(op)) dumpFile(Uri.parse(intent.getStringExtra("uri")));
                else if ("re_analyze".equals(op)) reAnalyze();
                else if ("native_import".equals(op)) nativeImport(Uri.parse(intent.getStringExtra("uri")),intent.getStringExtra("display"));
                else if ("native_search".equals(op)) nativeSearch(intent.getStringExtra("query"));
                else if ("native_disasm".equals(op)) nativeDisasm(intent.getStringExtra("rva"));
                else if ("native_xrefs".equals(op)) nativeXrefs(intent.getStringExtra("rva"));
                else if ("native_patch".equals(op)) nativePatch(intent.getStringExtra("rva"),intent.getStringExtra("mode"),intent.getStringExtra("payload"));
                else if ("native_undo".equals(op)) nativeUndo();
                else if ("native_save_uri".equals(op)) nativeSaveUri(Uri.parse(intent.getStringExtra("uri")));
                else if ("patchpack_import".equals(op)) patchPackImport(Uri.parse(intent.getStringExtra("uri")),intent.getStringExtra("display"));
                else if ("patchpack_inspect".equals(op)) patchPackInspect();
                else if ("patchpack_build".equals(op)) patchPackBuild(Uri.parse(intent.getStringExtra("uri")));
                else if ("menu_seed".equals(op)) menuSeed();
                else if ("menu_auto_prepare".equals(op)) menuAutoPrepare();
                else if ("menu_project".equals(op)) menuProject();
                else if ("menu_validate".equals(op)) menuValidate();
                else if ("menu_auto_confirm".equals(op)) menuAutoConfirm();
                else if ("menu_preflight".equals(op)) menuPreflight();
                else if ("menu_export".equals(op)) menuExport(Uri.parse(intent.getStringExtra("uri")));
                else if ("menu_runtime_import".equals(op)) menuRuntimeImport(Uri.parse(intent.getStringExtra("uri")),intent.getStringExtra("display"));
                else if ("menu_payload_export".equals(op)) menuPayloadExport(Uri.parse(intent.getStringExtra("uri")));
                else if ("menu_build_apk".equals(op)) menuBuildApk(Uri.parse(intent.getStringExtra("uri")));
                else if ("menu_auto_build_apk".equals(op)) menuAutoBuildApk(Uri.parse(intent.getStringExtra("uri")));
            } catch (Exception e) {
                app.progress(app.cancelled.get() ? "Операция отменена. Исходные файлы сохранены." : "Ошибка: " + e.getMessage());
            } finally {
                if (wake != null && wake.isHeld()) wake.release();
                getSharedPreferences("state",0).edit().putBoolean("running",false).apply();
                app.busy.set(false); app.revision++;
                stopForeground(true); stopSelf();
            }
        },"modkit-work").start();
        return START_NOT_STICKY;
    }
    private void check() throws IOException { if (app.cancelled.get()) throw new IOException("Операция отменена"); }
    private void deleteTree(File f) throws IOException {
        if(f==null||!f.exists())return;
        if(f.isDirectory()){File[] children=f.listFiles();if(children!=null)for(File c:children)deleteTree(c);}
        if(!f.delete()&&f.exists())throw new IOException("Не удалось очистить старый RE-артефакт: "+f.getName());
    }
    private void importFile(Uri uri,String name,String display) throws Exception {
        File temp=app.file(name+".tmp");
        try {
            try (InputStream in=getContentResolver().openInputStream(uri); OutputStream out=new FileOutputStream(temp)) {
                if (in==null) throw new IOException("Не удалось открыть выбранный файл");
                byte[] bytes=new byte[1024*1024]; int n; long total=0;
                while ((n=in.read(bytes))!=-1) {
                    check(); out.write(bytes,0,n); total+=n;
                    new Progress().progress("Импорт: "+(total/1024/1024)+" МБ — "+display);
                }
                if (total==0) throw new IOException("Выбран пустой файл");
            }
            check();
            Files.move(temp.toPath(),app.file(name).toPath(),StandardCopyOption.REPLACE_EXISTING);
            synchronized(app) {
                app.result=null;
                Files.deleteIfExists(app.file("analysis.json").toPath());
                Files.deleteIfExists(app.file("analysis.summary.json").toPath());
                getSharedPreferences("state",0).edit().putString(name,display).remove("selections").apply();
            }
            app.progress("Файл выбран: "+display);
        } finally { temp.delete(); }
    }
    private PyObject engine() {
        if (!Python.isStarted()) Python.start(new AndroidPlatform(this));
        return Python.getInstance().getModule("modkit.mobile.engine");
    }
    private void analyze() throws Exception {
        app.progress("Запуск Rodroid Il2CppDumper V7…");
        File dump=RodroidRunner.run(this,app.file("library.so"),app.file("metadata.bin"),app.file("rodroid"),app.cancelled,new Progress()::progress);
        app.progress("Построение списка изменений из script.json…");
        PyObject result=engine().callAttr("analyze_rodroid",dump.getPath(),app.file("metadata.bin").getPath(),app.file("library.so").getPath(),app.file("analysis.json").getPath(),new Progress());
        app.result=new JSONObject(result.toString());
        Files.write(app.file("analysis.summary.json").toPath(),result.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8));
        getSharedPreferences("state",0).edit().remove("selections").apply();
        app.progress("Готово. Методов с адресами: "+app.result.getInt("resolved")+". Доступно для изменения: "+app.result.getJSONArray("candidates").length()+".");
    }
    private void reportFile(Uri uri) throws Exception {
        boolean saved=false;
        try (InputStream in=new FileInputStream(app.file("analysis.json")); OutputStream out=getContentResolver().openOutputStream(uri,"wt")) {
            if(out==null)throw new IOException("Не удалось открыть файл для записи");
            byte[] bytes=new byte[1024*1024];int n;while((n=in.read(bytes))!=-1){check();out.write(bytes,0,n);}
            out.flush();saved=true;app.progress("Отчёт анализа сохранён.");
        } finally {if(!saved)try{DocumentsContract.deleteDocument(getContentResolver(),uri);}catch(Exception ignored){}}
    }
    private void exportFile(Uri uri,String selections) throws Exception {
        File zip=app.file("modkit-result.zip");
        boolean saved=false;
        try {
            engine().callAttr("export",app.file("analysis.json").getPath(),app.file("library.so").getPath(),selections,zip.getPath(),new Progress());
            try (InputStream in=new FileInputStream(zip); OutputStream out=getContentResolver().openOutputStream(uri,"wt")) {
                if(out==null) throw new IOException("Не удалось открыть файл для записи");
                byte[] bytes=new byte[1024*1024]; int n; long total=0;
                while ((n=in.read(bytes))!=-1) {
                    check(); out.write(bytes,0,n); total+=n;
                    new Progress().progress("Сохранение ZIP: "+total*100/Math.max(1,zip.length())+"%");
                }
                out.flush();
            }
            saved=true;
            app.progress("ZIP сохранён: изменённая libil2cpp.so, список изменений и отчёт. Оригиналы не изменены.");
        } finally {
            zip.delete();
            if (!saved) try { DocumentsContract.deleteDocument(getContentResolver(),uri); } catch(Exception ignored) { }
        }
    }
    private void buildApk(Uri uri,String selections) throws Exception {
        File unsigned=app.file("game-unsigned.apk"), signed=app.file("game-signed.apk"), key=app.file("modkit-test-signing.p12");
        boolean saved=false;
        try {
            app.progress("Замена ARM64 libil2cpp.so и выравнивание APK…");
            engine().callAttr("export_apk_unsigned",app.file("analysis.json").getPath(),app.file("library.so").getPath(),selections,app.file("game.apk").getPath(),unsigned.getPath(),new Progress());
            if(!key.isFile())try(InputStream in=getAssets().open("modkit-test-signing.p12")){Files.copy(in,key.toPath(),StandardCopyOption.REPLACE_EXISTING);}
            app.progress("Подпись и проверка собранного APK…");
            ApkSignerUtil.sign(unsigned,signed,key,"modkit-test".toCharArray());
            try(InputStream in=new FileInputStream(signed);OutputStream out=getContentResolver().openOutputStream(uri,"wt")){
                if(out==null)throw new IOException("Не удалось открыть APK для записи");
                byte[] bytes=new byte[1024*1024];int n;long total=0;
                while((n=in.read(bytes))!=-1){check();out.write(bytes,0,n);total+=n;new Progress().progress("Сохранение APK: "+total*100/Math.max(1,signed.length())+"%");}
                out.flush();
            }
            saved=true;app.progress("Готово: APK игры собран, выровнен, подписан и проверен.");
        } finally {
            unsigned.delete();signed.delete();key.delete();
            if(!saved)try{DocumentsContract.deleteDocument(getContentResolver(),uri);}catch(Exception ignored){}
        }
    }
    private void dumpFile(Uri uri) throws Exception {
        File zip=app.file("rodroid-full-dump.zip");boolean saved=false;
        try {
            engine().callAttr("export_dump",app.file("rodroid").getPath(),app.file("analysis.json").getPath(),zip.getPath(),new Progress());
            try(InputStream in=new FileInputStream(zip);OutputStream out=getContentResolver().openOutputStream(uri,"wt")){
                if(out==null)throw new IOException("Не удалось открыть ZIP для записи");
                byte[] bytes=new byte[1024*1024];int n;long total=0;
                while((n=in.read(bytes))!=-1){check();out.write(bytes,0,n);total+=n;new Progress().progress("Сохранение полного дампа: "+total*100/Math.max(1,zip.length())+"%");}
                out.flush();
            }
            saved=true;app.progress("Полный дамп Rodroid сохранён.");
        } finally {
            zip.delete();
            if(!saved)try{DocumentsContract.deleteDocument(getContentResolver(),uri);}catch(Exception ignored){}
        }
    }

    private void copyUri(Uri uri,File dest,String label) throws Exception {
        File temp=new File(dest.getParentFile(),dest.getName()+".tmp");
        try(InputStream in=getContentResolver().openInputStream(uri);OutputStream out=new FileOutputStream(temp)){
            if(in==null)throw new IOException("Не удалось открыть выбранный файл");
            byte[] bytes=new byte[1024*1024];int n;long total=0;
            while((n=in.read(bytes))!=-1){check();out.write(bytes,0,n);total+=n;new Progress().progress(label+": "+(total/1024/1024)+" МБ");}
            if(total==0)throw new IOException("Выбран пустой файл");
        }
        Files.move(temp.toPath(),dest.toPath(),StandardCopyOption.REPLACE_EXISTING);
    }
    private void writeResult(File dest,PyObject result) throws Exception {
        Files.write(dest.toPath(),result.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8));
    }
    private void reAnalyze() throws Exception {
        if(!app.file("game.apk").isFile())throw new IOException("Сначала выберите исходный APK");
        File meta=app.file("re-metadata.bin"),lib=app.file("re-library.so"),rod=app.file("re-rodroid");
        File unityReport=app.file("re-unity.json"),il2cppReport=app.file("re-il2cpp-analysis.json");
        Files.deleteIfExists(meta.toPath());Files.deleteIfExists(lib.toPath());Files.deleteIfExists(unityReport.toPath());Files.deleteIfExists(il2cppReport.toPath());
        deleteTree(rod);
        app.progress("RE Workspace: Unity/Addressables и автоматическое извлечение IL2CPP…");
        if (!Python.isStarted()) Python.start(new AndroidPlatform(this));
        PyObject unity=Python.getInstance().getModule("modkit.mobile.unityscan");
        unity.callAttr("inspect_apk",app.file("game.apk").getPath(),meta.getPath(),lib.getPath(),unityReport.getPath(),new Progress());
        String rodPath=null, il2cppPath=null;
        if(meta.isFile()&&lib.isFile()){
            try{
                app.progress("RE Workspace: Rodroid dump из файлов, извлечённых из этого же APK…");
                File dump=RodroidRunner.run(this,lib,meta,rod,app.cancelled,new Progress()::progress);
                rodPath=dump.getPath();
                engine().callAttr("analyze_rodroid",dump.getPath(),meta.getPath(),lib.getPath(),il2cppReport.getPath(),new Progress());
                il2cppPath=il2cppReport.getPath();
            }catch(Exception dumpError){app.progress("Rodroid не завершён, продолжаю статическую корреляцию: "+dumpError.getMessage());}
        }
        app.progress("RE Workspace: корреляция DEX + metadata + dump + всех .so…");
        PyObject result=engine().callAttr("re_analyze_apk",app.file("game.apk").getPath(),app.file("re-analysis.json").getPath(),meta.isFile()?meta.getPath():null,lib.isFile()?lib.getPath():null,rodPath,unityReport.isFile()?unityReport.getPath():null,il2cppPath,new Progress());
        JSONObject obj=new JSONObject(result.toString());JSONArray fs=obj.optJSONArray("findings");
        app.progress("RE-анализ готов. Находок: "+(fs==null?0:fs.length())+".");
    }
    private void nativeImport(Uri uri,String display) throws Exception {
        copyUri(uri,app.file("native-source.so"),"Импорт .so");
        Files.deleteIfExists(app.file("native-search.json").toPath());Files.deleteIfExists(app.file("native-disasm.json").toPath());
        PyObject result=engine().callAttr("native_workspace_create",app.file("native-source.so").getPath(),app.file("native-working.so").getPath(),app.file("native-state.json").getPath(),new Progress());
        writeResult(app.file("native-info.json"),result);getSharedPreferences("state",0).edit().putString("native-source.so",display).apply();
        app.progress("Native Workspace открыт: "+display);
    }
    private void refreshNativeInfo() throws Exception {writeResult(app.file("native-info.json"),engine().callAttr("native_workspace_info",app.file("native-working.so").getPath(),app.file("native-state.json").getPath()));}
    private void nativeSearch(String query) throws Exception {app.progress("Поиск в native symbols/strings…");writeResult(app.file("native-search.json"),engine().callAttr("native_workspace_search",app.file("native-working.so").getPath(),query==null?"":query,200));app.progress("Поиск завершён.");}
    private void nativeDisasm(String rva) throws Exception {if(rva==null||rva.trim().isEmpty())throw new IOException("Укажите RVA");app.progress("ARM64 disassembly…");writeResult(app.file("native-disasm.json"),engine().callAttr("native_workspace_disasm",app.file("native-working.so").getPath(),rva,512));app.progress("Дизассемблирование готово.");}
    private void nativeXrefs(String rva) throws Exception {if(rva==null||rva.trim().isEmpty())throw new IOException("Укажите RVA");app.progress("Поиск прямых ARM64 BL-ссылок…");writeResult(app.file("native-xrefs.json"),engine().callAttr("native_workspace_xrefs",app.file("native-working.so").getPath(),rva,400));app.progress("Static xrefs готовы; это не runtime trace.");}
    private void nativePatch(String rva,String mode,String payload) throws Exception {if(rva==null||rva.trim().isEmpty())throw new IOException("Укажите RVA");if(payload==null||payload.trim().isEmpty())throw new IOException("Укажите HEX/ASM");engine().callAttr("native_workspace_patch",app.file("native-working.so").getPath(),app.file("native-state.json").getPath(),rva,mode,payload,"Android editor",new Progress());refreshNativeInfo();app.progress("Изменение применено к рабочей копии .so.");}
    private void nativeUndo() throws Exception {engine().callAttr("native_workspace_undo",app.file("native-working.so").getPath(),app.file("native-state.json").getPath());refreshNativeInfo();app.progress("Последнее изменение отменено.");}
    private void nativeSaveUri(Uri uri) throws Exception {boolean saved=false;try(InputStream in=new FileInputStream(app.file("native-working.so"));OutputStream out=getContentResolver().openOutputStream(uri,"wt")){if(out==null)throw new IOException("Не удалось открыть файл для записи");byte[] b=new byte[1024*1024];int n;while((n=in.read(b))!=-1){check();out.write(b,0,n);}out.flush();saved=true;app.progress("Изменённая .so сохранена.");}finally{if(!saved)try{DocumentsContract.deleteDocument(getContentResolver(),uri);}catch(Exception ignored){}}}
    private void patchPackImport(Uri uri,String display) throws Exception {copyUri(uri,app.file("patchpack.zip"),"Импорт Patch Pack");getSharedPreferences("state",0).edit().putString("patchpack.zip",display).apply();patchPackInspect();}
    private void patchPackInspect() throws Exception {if(!app.file("game.apk").isFile()||!app.file("patchpack.zip").isFile())throw new IOException("Нужны исходный APK и Patch Pack ZIP");PyObject result=engine().callAttr("patchpack_inspect",app.file("game.apk").getPath(),app.file("patchpack.zip").getPath(),app.file("patchpack-report.json").getPath(),new Progress());JSONObject obj=new JSONObject(result.toString());app.progress(obj.optBoolean("blocked")?"Patch Pack заблокирован проверками совместимости.":"Patch Pack совместим с выбранным APK.");}
    private void patchPackBuild(Uri uri) throws Exception {
        File unsigned=app.file("patchpack-unsigned.apk"),signed=app.file("patchpack-signed.apk"),key=app.file("modkit-test-signing.p12");boolean saved=false;
        try{engine().callAttr("patchpack_apply_unsigned",app.file("game.apk").getPath(),app.file("patchpack.zip").getPath(),unsigned.getPath(),app.file("patchpack-report.json").getPath(),new Progress());if(!key.isFile())try(InputStream in=getAssets().open("modkit-test-signing.p12")){Files.copy(in,key.toPath(),StandardCopyOption.REPLACE_EXISTING);}app.progress("Подпись Patch Pack APK…");ApkSignerUtil.sign(unsigned,signed,key,"modkit-test".toCharArray());try(InputStream in=new FileInputStream(signed);OutputStream out=getContentResolver().openOutputStream(uri,"wt")){if(out==null)throw new IOException("Не удалось открыть APK для записи");byte[] b=new byte[1024*1024];int n;while((n=in.read(b))!=-1){check();out.write(b,0,n);}out.flush();}saved=true;app.progress("Patch Pack APK собран и подписан.");}finally{unsigned.delete();signed.delete();key.delete();if(!saved)try{DocumentsContract.deleteDocument(getContentResolver(),uri);}catch(Exception ignored){}}
    }
    private void invalidateMenuChecks() throws IOException {Files.deleteIfExists(app.file("menu-validation.json").toPath());Files.deleteIfExists(app.file("menu-preflight.json").toPath());}
    private void menuSeed() throws Exception {if(!app.file("re-analysis.json").isFile())throw new IOException("Сначала выполните RE-анализ");PyObject result=engine().callAttr("menu_seed_from_re",app.file("re-analysis.json").getPath(),app.file("menu-spec.json").getPath(),app.file("menu-project").getPath(),"ModKit Menu",new Progress());Files.write(app.file("menu-result.json").toPath(),result.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8));invalidateMenuChecks();app.progress("Menu Builder создан из RE-находок; evidence RVA сохранены отдельно до подтверждения.");}
    private void menuAutoPrepare() throws Exception {if(!app.file("re-analysis.json").isFile())throw new IOException("Сначала выполните RE-анализ");if(!app.file("game.apk").isFile())throw new IOException("Сначала выберите исходный APK");Files.deleteIfExists(app.file("menu-validation.json").toPath());PyObject result=engine().callAttr("menu_auto_prepare_from_re",app.file("re-analysis.json").getPath(),app.file("menu-spec.json").getPath(),app.file("game.apk").getPath(),app.file("menu-project").getPath(),app.file("menu-auto-prepare.json").getPath(),app.file("menu-preflight.json").getPath(),"ModKit Menu",new Progress());JSONObject obj=new JSONObject(result.toString()),confirm=obj.optJSONObject("confirm"),pre=obj.optJSONObject("preflight");JSONArray promoted=confirm==null?null:confirm.optJSONArray("promoted"),rejected=confirm==null?null:confirm.optJSONArray("rejected");app.progress("RE → Menu: confirmed "+(promoted==null?0:promoted.length())+", rejected "+(rejected==null?0:rejected.length())+", payload "+(pre!=null&&pre.optBoolean("readyForPayload")?"READY":"REVIEW")+".");}
    private void menuProject() throws Exception {if(!app.file("menu-spec.json").isFile())throw new IOException("Menu spec отсутствует");engine().callAttr("menu_project_from_spec",app.file("menu-spec.json").getPath(),app.file("menu-project").getPath(),new Progress());invalidateMenuChecks();app.progress("Проект меню обновлён.");}
    private void menuValidate() throws Exception {if(!app.file("menu-spec.json").isFile())throw new IOException("Menu spec отсутствует");if(!app.file("game.apk").isFile())throw new IOException("Сначала выберите исходный APK");PyObject result=engine().callAttr("menu_validate_spec",app.file("menu-spec.json").getPath(),app.file("game.apk").getPath(),app.file("menu-validation.json").getPath(),new Progress());JSONObject obj=new JSONObject(result.toString());app.progress(obj.optBoolean("blocked")?"Привязки меню: есть BLOCK-ошибки, генерация требует исправления RVA/.so.":"Привязки меню проверены по исходному APK.");}
    private void menuAutoConfirm() throws Exception {if(!app.file("menu-spec.json").isFile())throw new IOException("Menu spec отсутствует");if(!app.file("game.apk").isFile())throw new IOException("Сначала выберите исходный APK");PyObject result=engine().callAttr("menu_auto_confirm",app.file("menu-spec.json").getPath(),app.file("game.apk").getPath(),app.file("menu-project").getPath(),app.file("menu-auto-confirm.json").getPath(),new Progress());JSONObject obj=new JSONObject(result.toString());invalidateMenuChecks();JSONArray promoted=obj.optJSONArray("promoted"),rejected=obj.optJSONArray("rejected");app.progress("Автоподтверждение: promoted "+(promoted==null?0:promoted.length())+", rejected "+(rejected==null?0:rejected.length())+". Проверьте карточки перед payload.");}
    private JSONObject menuPreflightReport() throws Exception {if(!app.file("menu-spec.json").isFile())throw new IOException("Menu spec отсутствует");if(!app.file("game.apk").isFile())throw new IOException("Сначала выберите исходный APK");PyObject result=engine().callAttr("menu_review_preflight",app.file("menu-spec.json").getPath(),app.file("game.apk").getPath(),app.file("menu-preflight.json").getPath(),new Progress());return new JSONObject(result.toString());}
    private void menuPreflight() throws Exception {JSONObject obj=menuPreflightReport();JSONObject c=obj.optJSONObject("counts");int bound=c==null?0:c.optInt("bound"),review=c==null?0:c.optInt("evidenceOnly"),unresolved=c==null?0:c.optInt("unresolved");app.progress(obj.optBoolean("readyForPayload")?"Menu Builder готов к payload: bindings "+bound+", review "+review+", unresolved "+unresolved+".":"Menu Builder ещё не готов к payload: bindings "+bound+", review "+review+", unresolved "+unresolved+".");}
    private void menuExport(Uri uri) throws Exception {File zip=app.file("menu-project.zip");boolean saved=false;try{engine().callAttr("menu_export_project",app.file("menu-project").getPath(),app.file("menu-spec.json").getPath(),zip.getPath(),new Progress());try(InputStream in=new FileInputStream(zip);OutputStream out=getContentResolver().openOutputStream(uri,"wt")){if(out==null)throw new IOException("Не удалось открыть ZIP для записи");byte[] b=new byte[1024*1024];int n;while((n=in.read(b))!=-1){check();out.write(b,0,n);}out.flush();}saved=true;app.progress("Проект Menu Builder сохранён.");}finally{zip.delete();if(!saved)try{DocumentsContract.deleteDocument(getContentResolver(),uri);}catch(Exception ignored){}}}
    private void menuRuntimeImport(Uri uri,String display) throws Exception {copyUri(uri,app.file("menu-runtime.so"),"Импорт compiled menu runtime");getSharedPreferences("state",0).edit().putString("menu-runtime.so",display).apply();app.progress("Runtime Menu Builder импортирован: "+display);}
    private void menuPayloadExport(Uri uri) throws Exception {if(!app.file("menu-spec.json").isFile())throw new IOException("Menu spec отсутствует");if(!app.file("game.apk").isFile())throw new IOException("Сначала выберите исходный APK");JSONObject preflight=menuPreflightReport();if(!preflight.optBoolean("readyForPayload"))throw new IOException("Menu Builder не готов: подтвердите хотя бы одну привязку и исправьте BLOCK-ошибки");File runtime=app.file("menu-runtime.so");if(!runtime.isFile())runtime=new File(getApplicationInfo().nativeLibraryDir,"libmk.so");if(!runtime.isFile())throw new IOException("В этой сборке ModKit нет встроенного libmk.so; пересоберите приложение с NDK или выберите runtime вручную");File zip=app.file("menu-payload.zip");boolean saved=false;try{PyObject result=engine().callAttr("menu_payload_from_runtime",app.file("menu-spec.json").getPath(),app.file("game.apk").getPath(),runtime.getPath(),zip.getPath(),app.file("menu-payload-report.json").getPath(),new Progress());try(InputStream in=new FileInputStream(zip);OutputStream out=getContentResolver().openOutputStream(uri,"wt")){if(out==null)throw new IOException("Не удалось открыть ZIP для записи");byte[] b=new byte[1024*1024];int n;while((n=in.read(b))!=-1){check();out.write(b,0,n);}out.flush();}saved=true;app.progress("DEX-free Menu Patch Pack готов. Можно открыть его в Patch Pack.");}finally{zip.delete();if(!saved)try{DocumentsContract.deleteDocument(getContentResolver(),uri);}catch(Exception ignored){}}}
    private File menuRuntimeFile() throws IOException {File runtime=app.file("menu-runtime.so");if(!runtime.isFile())runtime=new File(getApplicationInfo().nativeLibraryDir,"libmk.so");if(!runtime.isFile())throw new IOException("В этой сборке ModKit нет встроенного libmk.so; пересоберите приложение с NDK или выберите runtime вручную");return runtime;}
    private void menuBuildApk(Uri uri) throws Exception {if(!app.file("menu-spec.json").isFile())throw new IOException("Menu spec отсутствует");if(!app.file("game.apk").isFile())throw new IOException("Сначала выберите исходный APK");JSONObject preflight=menuPreflightReport();if(!preflight.optBoolean("readyForPayload"))throw new IOException("Menu Builder не готов: подтвердите bindings/RVA и устраните BLOCK-ошибки");File payload=app.file("menu-payload-build.zip"),unsigned=app.file("menu-unsigned.apk"),signed=app.file("menu-signed.apk"),key=app.file("modkit-test-signing.p12");boolean saved=false;try{File runtime=menuRuntimeFile();app.progress("Menu Builder: создание DEX-free payload…");engine().callAttr("menu_payload_from_runtime",app.file("menu-spec.json").getPath(),app.file("game.apk").getPath(),runtime.getPath(),payload.getPath(),app.file("menu-payload-report.json").getPath(),new Progress());app.progress("Menu Builder: применение payload к копии APK…");engine().callAttr("patchpack_apply_unsigned",app.file("game.apk").getPath(),payload.getPath(),unsigned.getPath(),app.file("menu-apk-report.json").getPath(),new Progress());if(!key.isFile())try(InputStream in=getAssets().open("modkit-test-signing.p12")){Files.copy(in,key.toPath(),StandardCopyOption.REPLACE_EXISTING);}app.progress("Menu Builder: подпись APK тестовым ключом ModKit…");ApkSignerUtil.sign(unsigned,signed,key,"modkit-test".toCharArray());try(InputStream in=new FileInputStream(signed);OutputStream out=getContentResolver().openOutputStream(uri,"wt")){if(out==null)throw new IOException("Не удалось открыть APK для записи");byte[] b=new byte[1024*1024];int n;while((n=in.read(b))!=-1){check();out.write(b,0,n);}out.flush();}saved=true;app.progress("APK с Menu Builder собран и подписан. Подпись тестовая и отличается от оригинала.");}finally{payload.delete();unsigned.delete();signed.delete();key.delete();if(!saved)try{DocumentsContract.deleteDocument(getContentResolver(),uri);}catch(Exception ignored){}}}
    private void menuAutoBuildApk(Uri uri) throws Exception {if(!app.file("re-analysis.json").isFile())throw new IOException("Сначала выполните RE-анализ");if(!app.file("game.apk").isFile())throw new IOException("Сначала выберите исходный APK");app.progress("Авто APK: RE → подтверждение bindings…");menuAutoPrepare();JSONObject preflight=menuPreflightReport();if(!preflight.optBoolean("readyForAutoBuild"))throw new IOException("Автосборка остановлена: остались сильные controls для review, нет безопасно подтверждённых bindings или есть BLOCK; откройте Menu Builder. Ручная сборка подтверждённых bindings остаётся доступна отдельно.");app.progress("Авто APK: все сильные candidates разобраны, bindings подтверждены, сборка payload/APK…");menuBuildApk(uri);}

    @Override public IBinder onBind(Intent intent) { return null; }
}
